-- MySQL dump 10.13  Distrib 5.7.16, for Linux (x86_64)
--
-- Host: mysql    Database: itop
-- ------------------------------------------------------
-- Server version	5.7.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicationsolution`
--

DROP TABLE IF EXISTS `applicationsolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applicationsolution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicationsolution`
--

LOCK TABLES `applicationsolution` WRITE;
/*!40000 ALTER TABLE `applicationsolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicationsolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expire` datetime DEFAULT NULL,
  `temp_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_org_id` int(11) DEFAULT NULL,
  `contents_data` longblob NOT NULL,
  `contents_mimetype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contents_filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `temp_id` (`temp_id`),
  KEY `item_class_item_id` (`item_class`,`item_id`),
  KEY `item_org_id` (`item_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brand`
--

DROP TABLE IF EXISTS `brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brand`
--

LOCK TABLES `brand` WRITE;
/*!40000 ALTER TABLE `brand` DISABLE KEYS */;
/*!40000 ALTER TABLE `brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `businessprocess`
--

DROP TABLE IF EXISTS `businessprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `businessprocess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `businessprocess`
--

LOCK TABLES `businessprocess` WRITE;
/*!40000 ALTER TABLE `businessprocess` DISABLE KEYS */;
/*!40000 ALTER TABLE `businessprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change`
--

DROP TABLE IF EXISTS `change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('approved','assigned','closed','implemented','monitored','new','notapproved','plannedscheduled','rejected','validated') COLLATE utf8_unicode_ci DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `requestor_id` int(11) DEFAULT NULL,
  `creation_date` datetime DEFAULT NULL,
  `impact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `supervisor_group_id` int(11) DEFAULT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `manager_group_id` int(11) DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `outage` enum('no','yes') COLLATE utf8_unicode_ci NOT NULL,
  `fallback` text COLLATE utf8_unicode_ci,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `requestor_id` (`requestor_id`),
  KEY `supervisor_group_id` (`supervisor_group_id`),
  KEY `supervisor_id` (`supervisor_id`),
  KEY `manager_group_id` (`manager_group_id`),
  KEY `manager_id` (`manager_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change`
--

LOCK TABLES `change` WRITE;
/*!40000 ALTER TABLE `change` DISABLE KEYS */;
/*!40000 ALTER TABLE `change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change_approved`
--

DROP TABLE IF EXISTS `change_approved`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `change_approved` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `approval_date` datetime DEFAULT NULL,
  `approval_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_approved`
--

LOCK TABLES `change_approved` WRITE;
/*!40000 ALTER TABLE `change_approved` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_approved` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change_emergency`
--

DROP TABLE IF EXISTS `change_emergency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `change_emergency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_emergency`
--

LOCK TABLES `change_emergency` WRITE;
/*!40000 ALTER TABLE `change_emergency` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_emergency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change_normal`
--

DROP TABLE IF EXISTS `change_normal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `change_normal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_normal`
--

LOCK TABLES `change_normal` WRITE;
/*!40000 ALTER TABLE `change_normal` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_normal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `change_routine`
--

DROP TABLE IF EXISTS `change_routine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `change_routine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_routine`
--

LOCK TABLES `change_routine` WRITE;
/*!40000 ALTER TABLE `change_routine` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_routine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `connectableci`
--

DROP TABLE IF EXISTS `connectableci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connectableci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `connectableci`
--

LOCK TABLES `connectableci` WRITE;
/*!40000 ALTER TABLE `connectableci` DISABLE KEYS */;
/*!40000 ALTER TABLE `connectableci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL,
  `org_id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notify` enum('no','yes') COLLATE utf8_unicode_ci DEFAULT NULL,
  `function` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,'My last name','active',1,'my.email@foo.org','+00 000 000 000','yes','','Person');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacttype`
--

DROP TABLE IF EXISTS `contacttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacttype`
--

LOCK TABLES `contacttype` WRITE;
/*!40000 ALTER TABLE `contacttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `org_id` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cost_currency` enum('dollars','euros') COLLATE utf8_unicode_ci DEFAULT NULL,
  `contracttype_id` int(11) DEFAULT NULL,
  `billing_frequency` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cost_unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider_id` int(11) NOT NULL,
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `contracttype_id` (`contracttype_id`),
  KEY `provider_id` (`provider_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracttype`
--

DROP TABLE IF EXISTS `contracttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contracttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracttype`
--

LOCK TABLES `contracttype` WRITE;
/*!40000 ALTER TABLE `contracttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customercontract`
--

DROP TABLE IF EXISTS `customercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customercontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customercontract`
--

LOCK TABLES `customercontract` WRITE;
/*!40000 ALTER TABLE `customercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `customercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `databaseschema`
--

DROP TABLE IF EXISTS `databaseschema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `databaseschema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbserver_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dbserver_id` (`dbserver_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `databaseschema`
--

LOCK TABLES `databaseschema` WRITE;
/*!40000 ALTER TABLE `databaseschema` DISABLE KEYS */;
/*!40000 ALTER TABLE `databaseschema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datacenterdevice`
--

DROP TABLE IF EXISTS `datacenterdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datacenterdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rack_id` int(11) DEFAULT NULL,
  `enclosure_id` int(11) DEFAULT NULL,
  `nb_u` int(11) DEFAULT NULL,
  `managementip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `powera_id` int(11) DEFAULT NULL,
  `powerB_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`),
  KEY `enclosure_id` (`enclosure_id`),
  KEY `powera_id` (`powera_id`),
  KEY `powerB_id` (`powerB_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datacenterdevice`
--

LOCK TABLES `datacenterdevice` WRITE;
/*!40000 ALTER TABLE `datacenterdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `datacenterdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbserver`
--

DROP TABLE IF EXISTS `dbserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbserver` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbserver`
--

LOCK TABLES `dbserver` WRITE;
/*!40000 ALTER TABLE `dbserver` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbserver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliverymodel`
--

DROP TABLE IF EXISTS `deliverymodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliverymodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `org_id` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliverymodel`
--

LOCK TABLES `deliverymodel` WRITE;
/*!40000 ALTER TABLE `deliverymodel` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliverymodel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `org_id` int(11) NOT NULL,
  `documenttype_id` int(11) DEFAULT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` enum('draft','obsolete','published') COLLATE utf8_unicode_ci DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `documenttype_id` (`documenttype_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentfile`
--

DROP TABLE IF EXISTS `documentfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentfile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_data` longblob NOT NULL,
  `file_mimetype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentfile`
--

LOCK TABLES `documentfile` WRITE;
/*!40000 ALTER TABLE `documentfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentnote`
--

DROP TABLE IF EXISTS `documentnote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentnote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentnote`
--

LOCK TABLES `documentnote` WRITE;
/*!40000 ALTER TABLE `documentnote` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentnote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documenttype`
--

DROP TABLE IF EXISTS `documenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documenttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documenttype`
--

LOCK TABLES `documenttype` WRITE;
/*!40000 ALTER TABLE `documenttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `documenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentweb`
--

DROP TABLE IF EXISTS `documentweb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentweb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentweb`
--

LOCK TABLES `documentweb` WRITE;
/*!40000 ALTER TABLE `documentweb` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentweb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enclosure`
--

DROP TABLE IF EXISTS `enclosure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enclosure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rack_id` int(11) NOT NULL,
  `nb_u` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enclosure`
--

LOCK TABLES `enclosure` WRITE;
/*!40000 ALTER TABLE `enclosure` DISABLE KEYS */;
/*!40000 ALTER TABLE `enclosure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `description` longtext COLLATE utf8_unicode_ci,
  `category_id` int(11) NOT NULL,
  `error_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key_words` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqcategory`
--

DROP TABLE IF EXISTS `faqcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nam` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqcategory`
--

LOCK TABLES `faqcategory` WRITE;
/*!40000 ALTER TABLE `faqcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `faqcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `farm`
--

DROP TABLE IF EXISTS `farm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `farm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `farm`
--

LOCK TABLES `farm` WRITE;
/*!40000 ALTER TABLE `farm` DISABLE KEYS */;
/*!40000 ALTER TABLE `farm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fiberchannelinterface`
--

DROP TABLE IF EXISTS `fiberchannelinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fiberchannelinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `speed` decimal(6,2) DEFAULT NULL,
  `topology` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `wwn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datacenterdevice_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `datacenterdevice_id` (`datacenterdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fiberchannelinterface`
--

LOCK TABLES `fiberchannelinterface` WRITE;
/*!40000 ALTER TABLE `fiberchannelinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `fiberchannelinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `functionalci`
--

DROP TABLE IF EXISTS `functionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `functionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `org_id` int(11) NOT NULL,
  `business_criticity` enum('high','low','medium') COLLATE utf8_unicode_ci DEFAULT NULL,
  `move2production` date DEFAULT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `functionalci`
--

LOCK TABLES `functionalci` WRITE;
/*!40000 ALTER TABLE `functionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `functionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci NOT NULL,
  `org_id` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `parent_id_left` int(11) DEFAULT NULL,
  `parent_id_right` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hypervisor`
--

DROP TABLE IF EXISTS `hypervisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hypervisor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `farm_id` int(11) DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `farm_id` (`farm_id`),
  KEY `server_id` (`server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hypervisor`
--

LOCK TABLES `hypervisor` WRITE;
/*!40000 ALTER TABLE `hypervisor` DISABLE KEYS */;
/*!40000 ALTER TABLE `hypervisor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iosversion`
--

DROP TABLE IF EXISTS `iosversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iosversion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iosversion`
--

LOCK TABLES `iosversion` WRITE;
/*!40000 ALTER TABLE `iosversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `iosversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipinterface`
--

DROP TABLE IF EXISTS `ipinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `macaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `ipgateway` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ipmask` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `speed` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipinterface`
--

LOCK TABLES `ipinterface` WRITE;
/*!40000 ALTER TABLE `ipinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipphone`
--

DROP TABLE IF EXISTS `ipphone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipphone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipphone`
--

LOCK TABLES `ipphone` WRITE;
/*!40000 ALTER TABLE `ipphone` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipphone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knownerror`
--

DROP TABLE IF EXISTS `knownerror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knownerror` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cust_id` int(11) NOT NULL,
  `problem_id` int(11) DEFAULT NULL,
  `symptom` text COLLATE utf8_unicode_ci NOT NULL,
  `rootcause` text COLLATE utf8_unicode_ci,
  `workaround` text COLLATE utf8_unicode_ci,
  `solution` text COLLATE utf8_unicode_ci,
  `error_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `domain` enum('Application','Desktop','Network','Server') COLLATE utf8_unicode_ci NOT NULL,
  `vendor` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cust_id` (`cust_id`),
  KEY `problem_id` (`problem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knownerror`
--

LOCK TABLES `knownerror` WRITE;
/*!40000 ALTER TABLE `knownerror` DISABLE KEYS */;
/*!40000 ALTER TABLE `knownerror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licence`
--

DROP TABLE IF EXISTS `licence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `org_id` int(11) NOT NULL,
  `usage_limit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `licence_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `perpetual` enum('no','yes') COLLATE utf8_unicode_ci NOT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licence`
--

LOCK TABLES `licence` WRITE;
/*!40000 ALTER TABLE `licence` DISABLE KEYS */;
/*!40000 ALTER TABLE `licence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkapplicationsolutiontobusinessprocess`
--

DROP TABLE IF EXISTS `lnkapplicationsolutiontobusinessprocess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkapplicationsolutiontobusinessprocess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `businessprocess_id` int(11) NOT NULL,
  `applicationsolution_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `businessprocess_id` (`businessprocess_id`),
  KEY `applicationsolution_id` (`applicationsolution_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkapplicationsolutiontobusinessprocess`
--

LOCK TABLES `lnkapplicationsolutiontobusinessprocess` WRITE;
/*!40000 ALTER TABLE `lnkapplicationsolutiontobusinessprocess` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkapplicationsolutiontobusinessprocess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkapplicationsolutiontofunctionalci`
--

DROP TABLE IF EXISTS `lnkapplicationsolutiontofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkapplicationsolutiontofunctionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `applicationsolution_id` int(11) NOT NULL,
  `functionalci_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `applicationsolution_id` (`applicationsolution_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkapplicationsolutiontofunctionalci`
--

LOCK TABLES `lnkapplicationsolutiontofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkapplicationsolutiontofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkapplicationsolutiontofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkconnectablecitonetworkdevice`
--

DROP TABLE IF EXISTS `lnkconnectablecitonetworkdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkconnectablecitonetworkdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkdevice_id` int(11) NOT NULL,
  `connectableci_id` int(11) NOT NULL,
  `network_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` enum('downlink','uplink') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `networkdevice_id` (`networkdevice_id`),
  KEY `connectableci_id` (`connectableci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkconnectablecitonetworkdevice`
--

LOCK TABLES `lnkconnectablecitonetworkdevice` WRITE;
/*!40000 ALTER TABLE `lnkconnectablecitonetworkdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkconnectablecitonetworkdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttocontract`
--

DROP TABLE IF EXISTS `lnkcontacttocontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttocontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_id` (`contract_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttocontract`
--

LOCK TABLES `lnkcontacttocontract` WRITE;
/*!40000 ALTER TABLE `lnkcontacttocontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttocontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttofunctionalci`
--

DROP TABLE IF EXISTS `lnkcontacttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttofunctionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `functionalci_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttofunctionalci`
--

LOCK TABLES `lnkcontacttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkcontacttofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttoservice`
--

DROP TABLE IF EXISTS `lnkcontacttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttoservice`
--

LOCK TABLES `lnkcontacttoservice` WRITE;
/*!40000 ALTER TABLE `lnkcontacttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontacttoticket`
--

DROP TABLE IF EXISTS `lnkcontacttoticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontacttoticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  `role` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontacttoticket`
--

LOCK TABLES `lnkcontacttoticket` WRITE;
/*!40000 ALTER TABLE `lnkcontacttoticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontacttoticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcontracttodocument`
--

DROP TABLE IF EXISTS `lnkcontracttodocument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcontracttodocument` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_id` (`contract_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcontracttodocument`
--

LOCK TABLES `lnkcontracttodocument` WRITE;
/*!40000 ALTER TABLE `lnkcontracttodocument` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcontracttodocument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcustomercontracttofunctionalci`
--

DROP TABLE IF EXISTS `lnkcustomercontracttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcustomercontracttofunctionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customercontract_id` int(11) NOT NULL,
  `functionalci_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customercontract_id` (`customercontract_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcustomercontracttofunctionalci`
--

LOCK TABLES `lnkcustomercontracttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkcustomercontracttofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcustomercontracttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcustomercontracttoprovidercontract`
--

DROP TABLE IF EXISTS `lnkcustomercontracttoprovidercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcustomercontracttoprovidercontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customercontract_id` int(11) NOT NULL,
  `providercontract_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customercontract_id` (`customercontract_id`),
  KEY `providercontract_id` (`providercontract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcustomercontracttoprovidercontract`
--

LOCK TABLES `lnkcustomercontracttoprovidercontract` WRITE;
/*!40000 ALTER TABLE `lnkcustomercontracttoprovidercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcustomercontracttoprovidercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkcustomercontracttoservice`
--

DROP TABLE IF EXISTS `lnkcustomercontracttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkcustomercontracttoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customercontract_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `sla_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customercontract_id` (`customercontract_id`),
  KEY `service_id` (`service_id`),
  KEY `sla_id` (`sla_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkcustomercontracttoservice`
--

LOCK TABLES `lnkcustomercontracttoservice` WRITE;
/*!40000 ALTER TABLE `lnkcustomercontracttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkcustomercontracttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdatacenterdevicetosan`
--

DROP TABLE IF EXISTS `lnkdatacenterdevicetosan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdatacenterdevicetosan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `san_id` int(11) NOT NULL,
  `datacenterdevice_id` int(11) NOT NULL,
  `san_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datacenterdevice_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `san_id` (`san_id`),
  KEY `datacenterdevice_id` (`datacenterdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdatacenterdevicetosan`
--

LOCK TABLES `lnkdatacenterdevicetosan` WRITE;
/*!40000 ALTER TABLE `lnkdatacenterdevicetosan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdatacenterdevicetosan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdeliverymodeltocontact`
--

DROP TABLE IF EXISTS `lnkdeliverymodeltocontact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdeliverymodeltocontact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deliverymodel_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deliverymodel_id` (`deliverymodel_id`),
  KEY `contact_id` (`contact_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdeliverymodeltocontact`
--

LOCK TABLES `lnkdeliverymodeltocontact` WRITE;
/*!40000 ALTER TABLE `lnkdeliverymodeltocontact` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdeliverymodeltocontact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttoerror`
--

DROP TABLE IF EXISTS `lnkdocumenttoerror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttoerror` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `error_id` int(11) NOT NULL,
  `link_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`link_id`),
  KEY `document_id` (`document_id`),
  KEY `error_id` (`error_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttoerror`
--

LOCK TABLES `lnkdocumenttoerror` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttoerror` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttoerror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttofunctionalci`
--

DROP TABLE IF EXISTS `lnkdocumenttofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttofunctionalci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `functionalci_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttofunctionalci`
--

LOCK TABLES `lnkdocumenttofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttolicence`
--

DROP TABLE IF EXISTS `lnkdocumenttolicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttolicence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `licence_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `licence_id` (`licence_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttolicence`
--

LOCK TABLES `lnkdocumenttolicence` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttolicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttolicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttopatch`
--

DROP TABLE IF EXISTS `lnkdocumenttopatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttopatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patch_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `patch_id` (`patch_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttopatch`
--

LOCK TABLES `lnkdocumenttopatch` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttopatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttopatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttoservice`
--

DROP TABLE IF EXISTS `lnkdocumenttoservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttoservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttoservice`
--

LOCK TABLES `lnkdocumenttoservice` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttoservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttoservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkdocumenttosoftware`
--

DROP TABLE IF EXISTS `lnkdocumenttosoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkdocumenttosoftware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`),
  KEY `document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkdocumenttosoftware`
--

LOCK TABLES `lnkdocumenttosoftware` WRITE;
/*!40000 ALTER TABLE `lnkdocumenttosoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkdocumenttosoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkerrortofunctionalci`
--

DROP TABLE IF EXISTS `lnkerrortofunctionalci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkerrortofunctionalci` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `functionalci_id` int(11) NOT NULL,
  `error_id` int(11) NOT NULL,
  `dummy` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`link_id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `error_id` (`error_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkerrortofunctionalci`
--

LOCK TABLES `lnkerrortofunctionalci` WRITE;
/*!40000 ALTER TABLE `lnkerrortofunctionalci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkerrortofunctionalci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoospatch`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoospatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkfunctionalcitoospatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ospatch_id` int(11) NOT NULL,
  `functionalci_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ospatch_id` (`ospatch_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoospatch`
--

LOCK TABLES `lnkfunctionalcitoospatch` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoospatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoospatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoprovidercontract`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoprovidercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkfunctionalcitoprovidercontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `providercontract_id` int(11) NOT NULL,
  `functionalci_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `providercontract_id` (`providercontract_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoprovidercontract`
--

LOCK TABLES `lnkfunctionalcitoprovidercontract` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoprovidercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoprovidercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkfunctionalcitoticket`
--

DROP TABLE IF EXISTS `lnkfunctionalcitoticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkfunctionalcitoticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `functionalci_id` int(11) NOT NULL,
  `impact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `functionalci_id` (`functionalci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkfunctionalcitoticket`
--

LOCK TABLES `lnkfunctionalcitoticket` WRITE;
/*!40000 ALTER TABLE `lnkfunctionalcitoticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkfunctionalcitoticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkgrouptoci`
--

DROP TABLE IF EXISTS `lnkgrouptoci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkgrouptoci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `ci_id` int(11) NOT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `ci_id` (`ci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkgrouptoci`
--

LOCK TABLES `lnkgrouptoci` WRITE;
/*!40000 ALTER TABLE `lnkgrouptoci` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkgrouptoci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkpersontoteam`
--

DROP TABLE IF EXISTS `lnkpersontoteam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkpersontoteam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `team_id` (`team_id`),
  KEY `person_id` (`person_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkpersontoteam`
--

LOCK TABLES `lnkpersontoteam` WRITE;
/*!40000 ALTER TABLE `lnkpersontoteam` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkpersontoteam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkphysicalinterfacetovlan`
--

DROP TABLE IF EXISTS `lnkphysicalinterfacetovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkphysicalinterfacetovlan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `physicalinterface_id` int(11) NOT NULL,
  `vlan_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `physicalinterface_id` (`physicalinterface_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkphysicalinterfacetovlan`
--

LOCK TABLES `lnkphysicalinterfacetovlan` WRITE;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkphysicalinterfacetovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkservertovolume`
--

DROP TABLE IF EXISTS `lnkservertovolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkservertovolume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `size_used` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `volume_id` (`volume_id`),
  KEY `server_id` (`server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkservertovolume`
--

LOCK TABLES `lnkservertovolume` WRITE;
/*!40000 ALTER TABLE `lnkservertovolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkservertovolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkslatoslt`
--

DROP TABLE IF EXISTS `lnkslatoslt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkslatoslt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sla_id` int(11) NOT NULL,
  `slt_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sla_id` (`sla_id`),
  KEY `slt_id` (`slt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkslatoslt`
--

LOCK TABLES `lnkslatoslt` WRITE;
/*!40000 ALTER TABLE `lnkslatoslt` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkslatoslt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnksoftwareinstancetosoftwarepatch`
--

DROP TABLE IF EXISTS `lnksoftwareinstancetosoftwarepatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnksoftwareinstancetosoftwarepatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `softwarepatch_id` int(11) NOT NULL,
  `softwareinstance_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `softwarepatch_id` (`softwarepatch_id`),
  KEY `softwareinstance_id` (`softwareinstance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnksoftwareinstancetosoftwarepatch`
--

LOCK TABLES `lnksoftwareinstancetosoftwarepatch` WRITE;
/*!40000 ALTER TABLE `lnksoftwareinstancetosoftwarepatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnksoftwareinstancetosoftwarepatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnksubnettovlan`
--

DROP TABLE IF EXISTS `lnksubnettovlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnksubnettovlan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subnet_id` int(11) NOT NULL,
  `vlan_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`),
  KEY `vlan_id` (`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnksubnettovlan`
--

LOCK TABLES `lnksubnettovlan` WRITE;
/*!40000 ALTER TABLE `lnksubnettovlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnksubnettovlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lnkvirtualdevicetovolume`
--

DROP TABLE IF EXISTS `lnkvirtualdevicetovolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lnkvirtualdevicetovolume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volume_id` int(11) NOT NULL,
  `virtualdevice_id` int(11) NOT NULL,
  `size_used` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `volume_id` (`volume_id`),
  KEY `virtualdevice_id` (`virtualdevice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lnkvirtualdevicetovolume`
--

LOCK TABLES `lnkvirtualdevicetovolume` WRITE;
/*!40000 ALTER TABLE `lnkvirtualdevicetovolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `lnkvirtualdevicetovolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT NULL,
  `org_id` int(11) NOT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `postal_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logicalinterface`
--

DROP TABLE IF EXISTS `logicalinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logicalinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `virtualmachine_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `virtualmachine_id` (`virtualmachine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logicalinterface`
--

LOCK TABLES `logicalinterface` WRITE;
/*!40000 ALTER TABLE `logicalinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `logicalinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logicalvolume`
--

DROP TABLE IF EXISTS `logicalvolume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logicalvolume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lun_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `raid_level` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `storagesystem_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `storagesystem_id` (`storagesystem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logicalvolume`
--

LOCK TABLES `logicalvolume` WRITE;
/*!40000 ALTER TABLE `logicalvolume` DISABLE KEYS */;
/*!40000 ALTER TABLE `logicalvolume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `middleware`
--

DROP TABLE IF EXISTS `middleware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `middleware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `middleware`
--

LOCK TABLES `middleware` WRITE;
/*!40000 ALTER TABLE `middleware` DISABLE KEYS */;
/*!40000 ALTER TABLE `middleware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `middlewareinstance`
--

DROP TABLE IF EXISTS `middlewareinstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `middlewareinstance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `middleware_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `middleware_id` (`middleware_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `middlewareinstance`
--

LOCK TABLES `middlewareinstance` WRITE;
/*!40000 ALTER TABLE `middlewareinstance` DISABLE KEYS */;
/*!40000 ALTER TABLE `middlewareinstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobilephone`
--

DROP TABLE IF EXISTS `mobilephone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobilephone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imei` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hw_pin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobilephone`
--

LOCK TABLES `mobilephone` WRITE;
/*!40000 ALTER TABLE `mobilephone` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobilephone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model`
--

DROP TABLE IF EXISTS `model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) NOT NULL,
  `type` enum('DiskArray','Enclosure','IPPhone','MobilePhone','NAS','NetworkDevice','PC','PDU','Peripheral','Phone','PowerSource','Printer','Rack','SANSwitch','Server','StorageSystem','Tablet','TapeLibrary') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model`
--

LOCK TABLES `model` WRITE;
/*!40000 ALTER TABLE `model` DISABLE KEYS */;
/*!40000 ALTER TABLE `model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas`
--

DROP TABLE IF EXISTS `nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas`
--

LOCK TABLES `nas` WRITE;
/*!40000 ALTER TABLE `nas` DISABLE KEYS */;
/*!40000 ALTER TABLE `nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nasfilesystem`
--

DROP TABLE IF EXISTS `nasfilesystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nasfilesystem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `raid_level` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nas_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nas_id` (`nas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nasfilesystem`
--

LOCK TABLES `nasfilesystem` WRITE;
/*!40000 ALTER TABLE `nasfilesystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `nasfilesystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkdevice`
--

DROP TABLE IF EXISTS `networkdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networkdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkdevicetype_id` int(11) NOT NULL,
  `iosversion_id` int(11) DEFAULT NULL,
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `networkdevicetype_id` (`networkdevicetype_id`),
  KEY `iosversion_id` (`iosversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkdevice`
--

LOCK TABLES `networkdevice` WRITE;
/*!40000 ALTER TABLE `networkdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkdevicetype`
--

DROP TABLE IF EXISTS `networkdevicetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networkdevicetype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkdevicetype`
--

LOCK TABLES `networkdevicetype` WRITE;
/*!40000 ALTER TABLE `networkdevicetype` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkdevicetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkinterface`
--

DROP TABLE IF EXISTS `networkinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networkinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkinterface`
--

LOCK TABLES `networkinterface` WRITE;
/*!40000 ALTER TABLE `networkinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization`
--

DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `parent_id_left` int(11) DEFAULT NULL,
  `parent_id_right` int(11) DEFAULT NULL,
  `deliverymodel_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `parent_id_left` (`parent_id_left`),
  KEY `parent_id_right` (`parent_id_right`),
  KEY `deliverymodel_id` (`deliverymodel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization`
--

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
INSERT INTO `organization` VALUES (1,'My Company/Department','SOMECODE','active',0,1,2,0);
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `osfamily`
--

DROP TABLE IF EXISTS `osfamily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `osfamily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `osfamily`
--

LOCK TABLES `osfamily` WRITE;
/*!40000 ALTER TABLE `osfamily` DISABLE KEYS */;
/*!40000 ALTER TABLE `osfamily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oslicence`
--

DROP TABLE IF EXISTS `oslicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oslicence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osversion_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oslicence`
--

LOCK TABLES `oslicence` WRITE;
/*!40000 ALTER TABLE `oslicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `oslicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospatch`
--

DROP TABLE IF EXISTS `ospatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ospatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osversion_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospatch`
--

LOCK TABLES `ospatch` WRITE;
/*!40000 ALTER TABLE `ospatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `osversion`
--

DROP TABLE IF EXISTS `osversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `osversion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osfamily_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `osversion`
--

LOCK TABLES `osversion` WRITE;
/*!40000 ALTER TABLE `osversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `osversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `othersoftware`
--

DROP TABLE IF EXISTS `othersoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `othersoftware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `othersoftware`
--

LOCK TABLES `othersoftware` WRITE;
/*!40000 ALTER TABLE `othersoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `othersoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patch`
--

DROP TABLE IF EXISTS `patch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patch`
--

LOCK TABLES `patch` WRITE;
/*!40000 ALTER TABLE `patch` DISABLE KEYS */;
/*!40000 ALTER TABLE `patch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pc`
--

DROP TABLE IF EXISTS `pc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osfamily_id` int(11) DEFAULT NULL,
  `osversion_id` int(11) DEFAULT NULL,
  `cpu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` enum('desktop','laptop') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pc`
--

LOCK TABLES `pc` WRITE;
/*!40000 ALTER TABLE `pc` DISABLE KEYS */;
/*!40000 ALTER TABLE `pc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pcsoftware`
--

DROP TABLE IF EXISTS `pcsoftware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pcsoftware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pcsoftware`
--

LOCK TABLES `pcsoftware` WRITE;
/*!40000 ALTER TABLE `pcsoftware` DISABLE KEYS */;
/*!40000 ALTER TABLE `pcsoftware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdu`
--

DROP TABLE IF EXISTS `pdu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rack_id` int(11) NOT NULL,
  `powerstart_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rack_id` (`rack_id`),
  KEY `powerstart_id` (`powerstart_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdu`
--

LOCK TABLES `pdu` WRITE;
/*!40000 ALTER TABLE `pdu` DISABLE KEYS */;
/*!40000 ALTER TABLE `pdu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peripheral`
--

DROP TABLE IF EXISTS `peripheral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `peripheral` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peripheral`
--

LOCK TABLES `peripheral` WRITE;
/*!40000 ALTER TABLE `peripheral` DISABLE KEYS */;
/*!40000 ALTER TABLE `peripheral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employee_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `manager_id` (`manager_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,'My first name','','',0,0);
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone`
--

DROP TABLE IF EXISTS `phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone`
--

LOCK TABLES `phone` WRITE;
/*!40000 ALTER TABLE `phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physicaldevice`
--

DROP TABLE IF EXISTS `physicaldevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `physicaldevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serialnumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `status` enum('implementation','obsolete','production','stock') COLLATE utf8_unicode_ci DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `asset_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `end_of_warranty` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `brand_id` (`brand_id`),
  KEY `model_id` (`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physicaldevice`
--

LOCK TABLES `physicaldevice` WRITE;
/*!40000 ALTER TABLE `physicaldevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `physicaldevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physicalinterface`
--

DROP TABLE IF EXISTS `physicalinterface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `physicalinterface` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `connectableci_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `connectableci_id` (`connectableci_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physicalinterface`
--

LOCK TABLES `physicalinterface` WRITE;
/*!40000 ALTER TABLE `physicalinterface` DISABLE KEYS */;
/*!40000 ALTER TABLE `physicalinterface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powerconnection`
--

DROP TABLE IF EXISTS `powerconnection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `powerconnection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powerconnection`
--

LOCK TABLES `powerconnection` WRITE;
/*!40000 ALTER TABLE `powerconnection` DISABLE KEYS */;
/*!40000 ALTER TABLE `powerconnection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powersource`
--

DROP TABLE IF EXISTS `powersource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `powersource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powersource`
--

LOCK TABLES `powersource` WRITE;
/*!40000 ALTER TABLE `powersource` DISABLE KEYS */;
/*!40000 ALTER TABLE `powersource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printer`
--

DROP TABLE IF EXISTS `printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `printer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printer`
--

LOCK TABLES `printer` WRITE;
/*!40000 ALTER TABLE `printer` DISABLE KEYS */;
/*!40000 ALTER TABLE `printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action`
--

DROP TABLE IF EXISTS `priv_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('test','enabled','disabled') COLLATE utf8_unicode_ci NOT NULL,
  `realclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action`
--

LOCK TABLES `priv_action` WRITE;
/*!40000 ALTER TABLE `priv_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_email`
--

DROP TABLE IF EXISTS `priv_action_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_action_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test_recipient` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `reply_to` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to` text COLLATE utf8_unicode_ci,
  `cc` text COLLATE utf8_unicode_ci,
  `bcc` text COLLATE utf8_unicode_ci,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `importance` enum('high','low','normal') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_email`
--

LOCK TABLES `priv_action_email` WRITE;
/*!40000 ALTER TABLE `priv_action_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_action_notification`
--

DROP TABLE IF EXISTS `priv_action_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_action_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_action_notification`
--

LOCK TABLES `priv_action_notification` WRITE;
/*!40000 ALTER TABLE `priv_action_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_action_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_app_dashboards`
--

DROP TABLE IF EXISTS `priv_app_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_app_dashboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `menu_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contents` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_app_dashboards`
--

LOCK TABLES `priv_app_dashboards` WRITE;
/*!40000 ALTER TABLE `priv_app_dashboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_app_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_app_preferences`
--

DROP TABLE IF EXISTS `priv_app_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_app_preferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `preferences` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_app_preferences`
--

LOCK TABLES `priv_app_preferences` WRITE;
/*!40000 ALTER TABLE `priv_app_preferences` DISABLE KEYS */;
INSERT INTO `priv_app_preferences` VALUES (1,1,'a:1:{s:13:\"welcome_popup\";s:1:\"0\";}');
/*!40000 ALTER TABLE `priv_app_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_send_email`
--

DROP TABLE IF EXISTS `priv_async_send_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_async_send_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` int(11) NOT NULL,
  `to` text COLLATE utf8_unicode_ci,
  `subject` text COLLATE utf8_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_send_email`
--

LOCK TABLES `priv_async_send_email` WRITE;
/*!40000 ALTER TABLE `priv_async_send_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_send_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_async_task`
--

DROP TABLE IF EXISTS `priv_async_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_async_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('error','idle','planned','running') COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `started` datetime DEFAULT NULL,
  `planned` datetime DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `remaining_retries` int(11) DEFAULT NULL,
  `last_error_code` int(11) DEFAULT NULL,
  `last_error` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_attempt` datetime DEFAULT NULL,
  `realclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_async_task`
--

LOCK TABLES `priv_async_task` WRITE;
/*!40000 ALTER TABLE `priv_async_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_async_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_auditcategory`
--

DROP TABLE IF EXISTS `priv_auditcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_auditcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `definition_set` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_auditcategory`
--

LOCK TABLES `priv_auditcategory` WRITE;
/*!40000 ALTER TABLE `priv_auditcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_auditcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_auditrule`
--

DROP TABLE IF EXISTS `priv_auditrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_auditrule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `query` text COLLATE utf8_unicode_ci NOT NULL,
  `valid_flag` enum('false','true') COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_auditrule`
--

LOCK TABLES `priv_auditrule` WRITE;
/*!40000 ALTER TABLE `priv_auditrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_auditrule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_backgroundtask`
--

DROP TABLE IF EXISTS `priv_backgroundtask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_backgroundtask` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_run_date` datetime DEFAULT NULL,
  `latest_run_date` datetime DEFAULT NULL,
  `next_run_date` datetime DEFAULT NULL,
  `total_exec_count` int(11) DEFAULT NULL,
  `latest_run_duration` decimal(8,3) DEFAULT NULL,
  `min_run_duration` decimal(8,3) DEFAULT NULL,
  `max_run_duration` decimal(8,3) DEFAULT NULL,
  `average_run_duration` decimal(8,3) DEFAULT NULL,
  `running` tinyint(1) NOT NULL,
  `status` enum('active','paused') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_backgroundtask`
--

LOCK TABLES `priv_backgroundtask` WRITE;
/*!40000 ALTER TABLE `priv_backgroundtask` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_backgroundtask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_change`
--

DROP TABLE IF EXISTS `priv_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `userinfo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `origin` enum('csv-import.php','csv-interactive','custom-extension','email-processing','interactive','synchro-data-source','webservice-rest','webservice-soap') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `origin` (`origin`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_change`
--

LOCK TABLES `priv_change` WRITE;
/*!40000 ALTER TABLE `priv_change` DISABLE KEYS */;
INSERT INTO `priv_change` VALUES (1,'2016-10-31 09:54:52','','interactive'),(2,'2016-10-31 09:54:55','Initialization','interactive'),(3,'2016-10-31 09:54:56','','interactive');
/*!40000 ALTER TABLE `priv_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop`
--

DROP TABLE IF EXISTS `priv_changeop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changeid` int(11) NOT NULL,
  `objclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `objkey` int(11) NOT NULL,
  `optype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `changeid` (`changeid`),
  KEY `optype` (`optype`),
  KEY `objclass_objkey` (`objclass`,`objkey`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop`
--

LOCK TABLES `priv_changeop` WRITE;
/*!40000 ALTER TABLE `priv_changeop` DISABLE KEYS */;
INSERT INTO `priv_changeop` VALUES (1,1,'URP_Profiles',1,'CMDBChangeOpCreate'),(2,1,'URP_Profiles',3,'CMDBChangeOpCreate'),(3,1,'URP_Profiles',4,'CMDBChangeOpCreate'),(4,1,'URP_Profiles',5,'CMDBChangeOpCreate'),(5,1,'URP_Profiles',6,'CMDBChangeOpCreate'),(6,1,'URP_Profiles',7,'CMDBChangeOpCreate'),(7,1,'URP_Profiles',8,'CMDBChangeOpCreate'),(8,1,'URP_Profiles',9,'CMDBChangeOpCreate'),(9,1,'URP_Profiles',10,'CMDBChangeOpCreate'),(10,1,'URP_Profiles',11,'CMDBChangeOpCreate'),(11,1,'URP_Profiles',2,'CMDBChangeOpCreate'),(12,1,'URP_Profiles',12,'CMDBChangeOpCreate'),(13,1,'Organization',1,'CMDBChangeOpCreate'),(14,1,'Person',1,'CMDBChangeOpCreate'),(16,1,'URP_Profiles',1,'CMDBChangeOpSetAttributeLinksAddRemove'),(17,1,'URP_UserProfile',1,'CMDBChangeOpCreate'),(18,1,'UserLocal',1,'CMDBChangeOpCreate'),(19,3,'ModuleInstallation',1,'CMDBChangeOpCreate'),(20,3,'ModuleInstallation',2,'CMDBChangeOpCreate'),(21,3,'ModuleInstallation',3,'CMDBChangeOpCreate'),(22,3,'ModuleInstallation',4,'CMDBChangeOpCreate'),(23,3,'ModuleInstallation',5,'CMDBChangeOpCreate'),(24,3,'ModuleInstallation',6,'CMDBChangeOpCreate'),(25,3,'ModuleInstallation',7,'CMDBChangeOpCreate'),(26,3,'ModuleInstallation',8,'CMDBChangeOpCreate'),(27,3,'ModuleInstallation',9,'CMDBChangeOpCreate'),(28,3,'ModuleInstallation',10,'CMDBChangeOpCreate'),(29,3,'ModuleInstallation',11,'CMDBChangeOpCreate'),(30,3,'ModuleInstallation',12,'CMDBChangeOpCreate'),(31,3,'ModuleInstallation',13,'CMDBChangeOpCreate'),(32,3,'ModuleInstallation',14,'CMDBChangeOpCreate'),(33,3,'ModuleInstallation',15,'CMDBChangeOpCreate'),(34,3,'ModuleInstallation',16,'CMDBChangeOpCreate'),(35,3,'ModuleInstallation',17,'CMDBChangeOpCreate'),(36,3,'ModuleInstallation',18,'CMDBChangeOpCreate'),(37,3,'ModuleInstallation',19,'CMDBChangeOpCreate'),(38,3,'ModuleInstallation',20,'CMDBChangeOpCreate'),(39,3,'ModuleInstallation',21,'CMDBChangeOpCreate'),(40,3,'ModuleInstallation',22,'CMDBChangeOpCreate'),(41,3,'ModuleInstallation',23,'CMDBChangeOpCreate'),(42,3,'ModuleInstallation',24,'CMDBChangeOpCreate');
/*!40000 ALTER TABLE `priv_changeop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_create`
--

DROP TABLE IF EXISTS `priv_changeop_create`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_create` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_create`
--

LOCK TABLES `priv_changeop_create` WRITE;
/*!40000 ALTER TABLE `priv_changeop_create` DISABLE KEYS */;
INSERT INTO `priv_changeop_create` VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13),(14),(17),(18),(19),(20),(21),(22),(23),(24),(25),(26),(27),(28),(29),(30),(31),(32),(33),(34),(35),(36),(37),(38),(39),(40),(41),(42);
/*!40000 ALTER TABLE `priv_changeop_create` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_delete`
--

DROP TABLE IF EXISTS `priv_changeop_delete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_delete` (
  `id` int(11) NOT NULL,
  `fclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_delete`
--

LOCK TABLES `priv_changeop_delete` WRITE;
/*!40000 ALTER TABLE `priv_changeop_delete` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_delete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links`
--

DROP TABLE IF EXISTS `priv_changeop_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_links` (
  `id` int(11) NOT NULL,
  `item_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links`
--

LOCK TABLES `priv_changeop_links` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links` DISABLE KEYS */;
INSERT INTO `priv_changeop_links` VALUES (16,'User',1);
/*!40000 ALTER TABLE `priv_changeop_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links_addremove`
--

DROP TABLE IF EXISTS `priv_changeop_links_addremove`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_links_addremove` (
  `id` int(11) NOT NULL,
  `type` enum('added','removed') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links_addremove`
--

LOCK TABLES `priv_changeop_links_addremove` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links_addremove` DISABLE KEYS */;
INSERT INTO `priv_changeop_links_addremove` VALUES (16,'added');
/*!40000 ALTER TABLE `priv_changeop_links_addremove` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_links_tune`
--

DROP TABLE IF EXISTS `priv_changeop_links_tune`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_links_tune` (
  `id` int(11) NOT NULL,
  `link_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_links_tune`
--

LOCK TABLES `priv_changeop_links_tune` WRITE;
/*!40000 ALTER TABLE `priv_changeop_links_tune` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_links_tune` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_plugin`
--

DROP TABLE IF EXISTS `priv_changeop_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_plugin` (
  `id` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_plugin`
--

LOCK TABLES `priv_changeop_plugin` WRITE;
/*!40000 ALTER TABLE `priv_changeop_plugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt`
--

DROP TABLE IF EXISTS `priv_changeop_setatt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt` (
  `id` int(11) NOT NULL,
  `attcode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt`
--

LOCK TABLES `priv_changeop_setatt` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt` DISABLE KEYS */;
INSERT INTO `priv_changeop_setatt` VALUES (16,'user_list');
/*!40000 ALTER TABLE `priv_changeop_setatt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_data`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_data` (
  `id` int(11) NOT NULL,
  `prevdata_data` longblob NOT NULL,
  `prevdata_mimetype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prevdata_filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_data`
--

LOCK TABLES `priv_changeop_setatt_data` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_encrypted`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_encrypted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_encrypted` (
  `id` int(11) NOT NULL,
  `data` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_encrypted`
--

LOCK TABLES `priv_changeop_setatt_encrypted` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_encrypted` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_encrypted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_log`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_log` (
  `id` int(11) NOT NULL,
  `lastentry` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_log`
--

LOCK TABLES `priv_changeop_setatt_log` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_longtext`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_longtext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_longtext` (
  `id` int(11) NOT NULL,
  `prevdata` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_longtext`
--

LOCK TABLES `priv_changeop_setatt_longtext` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_longtext` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_longtext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_pwd`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_pwd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_pwd` (
  `id` int(11) NOT NULL,
  `prev_pwd_hash` tinyblob,
  `prev_pwd_salt` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_pwd`
--

LOCK TABLES `priv_changeop_setatt_pwd` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_pwd` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_pwd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_scalar`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_scalar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_scalar` (
  `id` int(11) NOT NULL,
  `oldvalue` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `newvalue` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_scalar`
--

LOCK TABLES `priv_changeop_setatt_scalar` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_scalar` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_scalar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_changeop_setatt_text`
--

DROP TABLE IF EXISTS `priv_changeop_setatt_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_changeop_setatt_text` (
  `id` int(11) NOT NULL,
  `prevdata` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_changeop_setatt_text`
--

LOCK TABLES `priv_changeop_setatt_text` WRITE;
/*!40000 ALTER TABLE `priv_changeop_setatt_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_changeop_setatt_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_db_properties`
--

DROP TABLE IF EXISTS `priv_db_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_db_properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `change_date` datetime DEFAULT NULL,
  `change_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_db_properties`
--

LOCK TABLES `priv_db_properties` WRITE;
/*!40000 ALTER TABLE `priv_db_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_db_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event`
--

DROP TABLE IF EXISTS `priv_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime DEFAULT NULL,
  `userinfo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event`
--

LOCK TABLES `priv_event` WRITE;
/*!40000 ALTER TABLE `priv_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_email`
--

DROP TABLE IF EXISTS `priv_event_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to` text COLLATE utf8_unicode_ci,
  `cc` text COLLATE utf8_unicode_ci,
  `bcc` text COLLATE utf8_unicode_ci,
  `from` text COLLATE utf8_unicode_ci,
  `subject` text COLLATE utf8_unicode_ci,
  `body` longtext COLLATE utf8_unicode_ci,
  `attachments` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_email`
--

LOCK TABLES `priv_event_email` WRITE;
/*!40000 ALTER TABLE `priv_event_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_issue`
--

DROP TABLE IF EXISTS `priv_event_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_issue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `impact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `page` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `arguments_post` longtext COLLATE utf8_unicode_ci,
  `arguments_get` longtext COLLATE utf8_unicode_ci,
  `callstack` longtext COLLATE utf8_unicode_ci,
  `data` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_issue`
--

LOCK TABLES `priv_event_issue` WRITE;
/*!40000 ALTER TABLE `priv_event_issue` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_loginusage`
--

DROP TABLE IF EXISTS `priv_event_loginusage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_loginusage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_loginusage`
--

LOCK TABLES `priv_event_loginusage` WRITE;
/*!40000 ALTER TABLE `priv_event_loginusage` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_loginusage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_notification`
--

DROP TABLE IF EXISTS `priv_event_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trigger_id` int(11) NOT NULL,
  `action_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `trigger_id` (`trigger_id`),
  KEY `action_id` (`action_id`),
  KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_notification`
--

LOCK TABLES `priv_event_notification` WRITE;
/*!40000 ALTER TABLE `priv_event_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_event_webservice`
--

DROP TABLE IF EXISTS `priv_event_webservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_event_webservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `verb` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `result` tinyint(1) DEFAULT NULL,
  `log_info` text COLLATE utf8_unicode_ci,
  `log_warning` text COLLATE utf8_unicode_ci,
  `log_error` text COLLATE utf8_unicode_ci,
  `data` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_event_webservice`
--

LOCK TABLES `priv_event_webservice` WRITE;
/*!40000 ALTER TABLE `priv_event_webservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_event_webservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_internaluser`
--

DROP TABLE IF EXISTS `priv_internaluser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_internaluser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reset_pwd_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_internaluser`
--

LOCK TABLES `priv_internaluser` WRITE;
/*!40000 ALTER TABLE `priv_internaluser` DISABLE KEYS */;
INSERT INTO `priv_internaluser` VALUES (1,'');
/*!40000 ALTER TABLE `priv_internaluser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_link_action_trigger`
--

DROP TABLE IF EXISTS `priv_link_action_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_link_action_trigger` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `action_id` int(11) NOT NULL,
  `trigger_id` int(11) NOT NULL,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`link_id`),
  KEY `action_id` (`action_id`),
  KEY `trigger_id` (`trigger_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_link_action_trigger`
--

LOCK TABLES `priv_link_action_trigger` WRITE;
/*!40000 ALTER TABLE `priv_link_action_trigger` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_link_action_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_module_install`
--

DROP TABLE IF EXISTS `priv_module_install`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_module_install` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `installed` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_module_install`
--

LOCK TABLES `priv_module_install` WRITE;
/*!40000 ALTER TABLE `priv_module_install` DISABLE KEYS */;
INSERT INTO `priv_module_install` VALUES (1,'datamodel','2.1.0','2016-10-31 09:54:56','{\"source_dir\":\"datamodels\\/2.x\\/\"}',0),(2,'iTop','2.1.0.2127','2016-10-31 09:54:56','Done by the setup program\nBuilt on 2014-12-17 20:26:15',0),(3,'authent-external','1.0.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)',2),(4,'authent-ldap','1.0.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)',2),(5,'authent-local','1.0.0','2016-10-31 09:54:56','Done by the setup program\nMandatory\nVisible (during the setup)',2),(6,'itop-backup','2.1.1','2016-10-31 09:54:56','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(7,'itop-config','1.0.2','2016-10-31 09:54:56','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(8,'itop-profiles-itil','2.1.0','2016-10-31 09:54:56','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(9,'itop-sla-computation','1.0.0','2016-10-31 09:54:56','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(10,'itop-tickets','2.1.0','2016-10-31 09:54:56','Done by the setup program\nMandatory\nHidden (selected automatically)\nDepends on module: itop-config-mgmt/2.0.0',2),(11,'itop-welcome-itil','2.1.0','2016-10-31 09:54:56','Done by the setup program\nMandatory\nHidden (selected automatically)',2),(12,'itop-config-mgmt','2.1.0','2016-10-31 09:54:56','Done by the setup program\nMandatory\nVisible (during the setup)',2),(13,'itop-attachments','2.1.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)',2),(14,'itop-datacenter-mgmt','2.1.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0',2),(15,'itop-endusers-devices','2.1.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0',2),(16,'itop-storage-mgmt','2.1.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0',2),(17,'itop-virtualization-mgmt','2.1.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0',2),(18,'itop-bridge-virtualization-storage','2.1.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)',2),(19,'itop-service-mgmt-provider','2.1.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0\nDepends on module: itop-tickets/2.0.0',2),(20,'itop-request-mgmt-itil','2.1.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0\nDepends on module: itop-tickets/2.0.0',2),(21,'itop-incident-mgmt-itil','2.1.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0\nDepends on module: itop-tickets/2.0.0\nDepends on module: itop-profiles-itil/1.0.0',2),(22,'itop-change-mgmt-itil','2.1.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0\nDepends on module: itop-tickets/2.0.0',2),(23,'itop-knownerror-mgmt','2.1.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0\nDepends on module: itop-tickets/2.0.0',2),(24,'itop-problem-mgmt','2.1.0','2016-10-31 09:54:56','Done by the setup program\nOptional\nVisible (during the setup)\nDepends on module: itop-config-mgmt/2.0.0\nDepends on module: itop-tickets/2.0.0',2);
/*!40000 ALTER TABLE `priv_module_install` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_query`
--

DROP TABLE IF EXISTS `priv_query`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_query` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `fields` text COLLATE utf8_unicode_ci,
  `realclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_query`
--

LOCK TABLES `priv_query` WRITE;
/*!40000 ALTER TABLE `priv_query` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_query` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_query_oql`
--

DROP TABLE IF EXISTS `priv_query_oql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_query_oql` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oql` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_query_oql`
--

LOCK TABLES `priv_query_oql` WRITE;
/*!40000 ALTER TABLE `priv_query_oql` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_query_oql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_shortcut`
--

DROP TABLE IF EXISTS `priv_shortcut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_shortcut` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `context` text COLLATE utf8_unicode_ci NOT NULL,
  `realclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_shortcut`
--

LOCK TABLES `priv_shortcut` WRITE;
/*!40000 ALTER TABLE `priv_shortcut` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_shortcut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_shortcut_oql`
--

DROP TABLE IF EXISTS `priv_shortcut_oql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_shortcut_oql` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oql` text COLLATE utf8_unicode_ci NOT NULL,
  `auto_reload` enum('custom','none') COLLATE utf8_unicode_ci NOT NULL,
  `auto_reload_sec` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_shortcut_oql`
--

LOCK TABLES `priv_shortcut_oql` WRITE;
/*!40000 ALTER TABLE `priv_shortcut_oql` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_shortcut_oql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att`
--

DROP TABLE IF EXISTS `priv_sync_att`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_att` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_source_id` int(11) NOT NULL,
  `attcode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `update` tinyint(1) NOT NULL,
  `reconcile` tinyint(1) NOT NULL,
  `update_policy` enum('master_locked','master_unlocked','write_if_empty') COLLATE utf8_unicode_ci NOT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att`
--

LOCK TABLES `priv_sync_att` WRITE;
/*!40000 ALTER TABLE `priv_sync_att` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att_extkey`
--

DROP TABLE IF EXISTS `priv_sync_att_extkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_att_extkey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reconciliation_attcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att_extkey`
--

LOCK TABLES `priv_sync_att_extkey` WRITE;
/*!40000 ALTER TABLE `priv_sync_att_extkey` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att_extkey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_att_linkset`
--

DROP TABLE IF EXISTS `priv_sync_att_linkset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_att_linkset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `row_separator` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attribute_separator` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value_separator` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attribute_qualifier` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_att_linkset`
--

LOCK TABLES `priv_sync_att_linkset` WRITE;
/*!40000 ALTER TABLE `priv_sync_att_linkset` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_att_linkset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_datasource`
--

DROP TABLE IF EXISTS `priv_sync_datasource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_datasource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `notify_contact_id` int(11) DEFAULT NULL,
  `scope_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `database_table_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `scope_restriction` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `full_load_periodicity` int(11) unsigned DEFAULT NULL,
  `reconciliation_policy` enum('use_attributes','use_primary_key') COLLATE utf8_unicode_ci NOT NULL,
  `action_on_zero` enum('create','error') COLLATE utf8_unicode_ci NOT NULL,
  `action_on_one` enum('error','update') COLLATE utf8_unicode_ci NOT NULL,
  `action_on_multiple` enum('create','error','take_first') COLLATE utf8_unicode_ci NOT NULL,
  `delete_policy` enum('delete','ignore','update','update_then_delete') COLLATE utf8_unicode_ci NOT NULL,
  `delete_policy_update` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delete_policy_retention` int(11) unsigned DEFAULT NULL,
  `user_delete_policy` enum('administrators','everybody','nobody') COLLATE utf8_unicode_ci DEFAULT NULL,
  `url_icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url_application` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `notify_contact_id` (`notify_contact_id`),
  KEY `scope_class` (`scope_class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_datasource`
--

LOCK TABLES `priv_sync_datasource` WRITE;
/*!40000 ALTER TABLE `priv_sync_datasource` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_datasource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_log`
--

DROP TABLE IF EXISTS `priv_sync_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_source_id` int(11) NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `status` enum('completed','error','running') COLLATE utf8_unicode_ci NOT NULL,
  `status_curr_job` int(11) DEFAULT NULL,
  `status_curr_pos` int(11) DEFAULT NULL,
  `stats_nb_replica_seen` int(11) NOT NULL,
  `stats_nb_replica_total` int(11) NOT NULL,
  `stats_nb_obj_deleted` int(11) NOT NULL,
  `stats_deleted_errors` int(11) NOT NULL,
  `stats_nb_obj_obsoleted` int(11) NOT NULL,
  `stats_nb_obj_obsoleted_errors` int(11) NOT NULL,
  `stats_nb_obj_created` int(11) NOT NULL,
  `stats_nb_obj_created_errors` int(11) NOT NULL,
  `stats_nb_obj_created_warnings` int(11) NOT NULL,
  `stats_nb_obj_updated` int(11) NOT NULL,
  `stats_nb_obj_updated_errors` int(11) NOT NULL,
  `stats_nb_obj_updated_warnings` int(11) NOT NULL,
  `stats_nb_obj_unchanged_warnings` int(11) NOT NULL,
  `stats_nb_replica_reconciled_errors` int(11) NOT NULL,
  `stats_nb_replica_disappeared_no_action` int(11) NOT NULL,
  `stats_nb_obj_new_updated` int(11) NOT NULL,
  `stats_nb_obj_new_updated_warnings` int(11) NOT NULL,
  `stats_nb_obj_new_unchanged` int(11) NOT NULL,
  `stats_nb_obj_new_unchanged_warnings` int(11) NOT NULL,
  `last_error` text COLLATE utf8_unicode_ci,
  `traces` longtext COLLATE utf8_unicode_ci,
  `memory_usage_peak` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_log`
--

LOCK TABLES `priv_sync_log` WRITE;
/*!40000 ALTER TABLE `priv_sync_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_sync_replica`
--

DROP TABLE IF EXISTS `priv_sync_replica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_sync_replica` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_source_id` int(11) NOT NULL,
  `dest_id` int(11) DEFAULT NULL,
  `dest_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status_last_seen` datetime DEFAULT NULL,
  `status` enum('modified','new','obsolete','orphan','synchronized') COLLATE utf8_unicode_ci NOT NULL,
  `status_dest_creator` tinyint(1) DEFAULT NULL,
  `status_last_error` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status_last_warning` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `info_creation_date` datetime DEFAULT NULL,
  `info_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sync_source_id` (`sync_source_id`),
  KEY `dest_class` (`dest_class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_sync_replica`
--

LOCK TABLES `priv_sync_replica` WRITE;
/*!40000 ALTER TABLE `priv_sync_replica` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_sync_replica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger`
--

DROP TABLE IF EXISTS `priv_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `realclass` (`realclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger`
--

LOCK TABLES `priv_trigger` WRITE;
/*!40000 ALTER TABLE `priv_trigger` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobjcreate`
--

DROP TABLE IF EXISTS `priv_trigger_onobjcreate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onobjcreate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobjcreate`
--

LOCK TABLES `priv_trigger_onobjcreate` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobjcreate` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onobjcreate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onobject`
--

DROP TABLE IF EXISTS `priv_trigger_onobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onobject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filter` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `target_class` (`target_class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onobject`
--

LOCK TABLES `priv_trigger_onobject` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onobject` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onobject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onportalupdate`
--

DROP TABLE IF EXISTS `priv_trigger_onportalupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onportalupdate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onportalupdate`
--

LOCK TABLES `priv_trigger_onportalupdate` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onportalupdate` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onportalupdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstatechange`
--

DROP TABLE IF EXISTS `priv_trigger_onstatechange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onstatechange` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstatechange`
--

LOCK TABLES `priv_trigger_onstatechange` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstatechange` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstatechange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstateenter`
--

DROP TABLE IF EXISTS `priv_trigger_onstateenter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onstateenter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstateenter`
--

LOCK TABLES `priv_trigger_onstateenter` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstateenter` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstateenter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_onstateleave`
--

DROP TABLE IF EXISTS `priv_trigger_onstateleave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_onstateleave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_onstateleave`
--

LOCK TABLES `priv_trigger_onstateleave` WRITE;
/*!40000 ALTER TABLE `priv_trigger_onstateleave` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_onstateleave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_trigger_threshold`
--

DROP TABLE IF EXISTS `priv_trigger_threshold`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_trigger_threshold` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stop_watch_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `threshold_index` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_trigger_threshold`
--

LOCK TABLES `priv_trigger_threshold` WRITE;
/*!40000 ALTER TABLE `priv_trigger_threshold` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_trigger_threshold` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_profiles`
--

DROP TABLE IF EXISTS `priv_urp_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_urp_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_profiles`
--

LOCK TABLES `priv_urp_profiles` WRITE;
/*!40000 ALTER TABLE `priv_urp_profiles` DISABLE KEYS */;
INSERT INTO `priv_urp_profiles` VALUES (1,'Administrator','Has the rights on everything (bypassing any control)'),(2,'Portal user','Has the rights to access to the user portal. People having this profile will not be allowed to access the standard application, they will be automatically redirected to the user portal.'),(3,'Configuration Manager','Person in charge of the documentation of the managed CIs'),(4,'Service Desk Agent','Person in charge of creating incident reports'),(5,'Support Agent','Person analyzing and solving the current incidents'),(6,'Problem Manager','Person analyzing and solving the current problems'),(7,'Change Implementor','Person executing the changes'),(8,'Change Supervisor','Person responsible for the overall change execution'),(9,'Change Approver','Person who could be impacted by some changes'),(10,'Service Manager','Person responsible for the service delivered to the [internal] customer'),(11,'Document author','Any person who could contribute to documentation'),(12,'Portal power user','Users having this profile will have the rights to see all the tickets for a customer in the portal. Must be used in conjunction with other profiles (e.g. Portal User).');
/*!40000 ALTER TABLE `priv_urp_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_userorg`
--

DROP TABLE IF EXISTS `priv_urp_userorg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_urp_userorg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `allowed_org_id` int(11) NOT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `allowed_org_id` (`allowed_org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_userorg`
--

LOCK TABLES `priv_urp_userorg` WRITE;
/*!40000 ALTER TABLE `priv_urp_userorg` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv_urp_userorg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_urp_userprofile`
--

DROP TABLE IF EXISTS `priv_urp_userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_urp_userprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `profileid` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `profileid` (`profileid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_urp_userprofile`
--

LOCK TABLES `priv_urp_userprofile` WRITE;
/*!40000 ALTER TABLE `priv_urp_userprofile` DISABLE KEYS */;
INSERT INTO `priv_urp_userprofile` VALUES (1,1,1,'By definition, the administrator must have the administrator profile');
/*!40000 ALTER TABLE `priv_urp_userprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user`
--

DROP TABLE IF EXISTS `priv_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contactid` int(11) DEFAULT NULL,
  `login` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `contactid` (`contactid`),
  KEY `language` (`language`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user`
--

LOCK TABLES `priv_user` WRITE;
/*!40000 ALTER TABLE `priv_user` DISABLE KEYS */;
INSERT INTO `priv_user` VALUES (1,1,'itop','EN US','UserLocal');
/*!40000 ALTER TABLE `priv_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv_user_local`
--

DROP TABLE IF EXISTS `priv_user_local`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv_user_local` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password_hash` tinyblob NOT NULL,
  `password_salt` tinyblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv_user_local`
--

LOCK TABLES `priv_user_local` WRITE;
/*!40000 ALTER TABLE `priv_user_local` DISABLE KEYS */;
INSERT INTO `priv_user_local` VALUES (1,'10214822ad52a7d49b2cf117aa34da468bb69ad4363f820be8b84bf553788108','W\�3\��\"�^\�k�Ҵ5�');
/*!40000 ALTER TABLE `priv_user_local` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providercontract`
--

DROP TABLE IF EXISTS `providercontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providercontract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sla` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `coverage` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providercontract`
--

LOCK TABLES `providercontract` WRITE;
/*!40000 ALTER TABLE `providercontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `providercontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rack`
--

DROP TABLE IF EXISTS `rack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nb_u` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rack`
--

LOCK TABLES `rack` WRITE;
/*!40000 ALTER TABLE `rack` DISABLE KEYS */;
/*!40000 ALTER TABLE `rack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sanswitch`
--

DROP TABLE IF EXISTS `sanswitch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sanswitch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sanswitch`
--

LOCK TABLES `sanswitch` WRITE;
/*!40000 ALTER TABLE `sanswitch` DISABLE KEYS */;
/*!40000 ALTER TABLE `sanswitch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `osfamily_id` int(11) DEFAULT NULL,
  `osversion_id` int(11) DEFAULT NULL,
  `oslicence_id` int(11) DEFAULT NULL,
  `cpu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`),
  KEY `oslicence_id` (`oslicence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server`
--

LOCK TABLES `server` WRITE;
/*!40000 ALTER TABLE `server` DISABLE KEYS */;
/*!40000 ALTER TABLE `server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `org_id` int(11) NOT NULL,
  `servicefamily_id` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `servicefamily_id` (`servicefamily_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicefamilly`
--

DROP TABLE IF EXISTS `servicefamilly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicefamilly` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicefamilly`
--

LOCK TABLES `servicefamilly` WRITE;
/*!40000 ALTER TABLE `servicefamilly` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicefamilly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicesubcategory`
--

DROP TABLE IF EXISTS `servicesubcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicesubcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `service_id` int(11) NOT NULL,
  `request_type` enum('incident','service_request') COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('implementation','obsolete','production') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicesubcategory`
--

LOCK TABLES `servicesubcategory` WRITE;
/*!40000 ALTER TABLE `servicesubcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicesubcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sla`
--

DROP TABLE IF EXISTS `sla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sla` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `org_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sla`
--

LOCK TABLES `sla` WRITE;
/*!40000 ALTER TABLE `sla` DISABLE KEYS */;
/*!40000 ALTER TABLE `sla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slt`
--

DROP TABLE IF EXISTS `slt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `priority` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT NULL,
  `request_type` enum('incident','service_request') COLLATE utf8_unicode_ci DEFAULT NULL,
  `metric` enum('tto','ttr') COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `unit` enum('hours','minutes') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slt`
--

LOCK TABLES `slt` WRITE;
/*!40000 ALTER TABLE `slt` DISABLE KEYS */;
/*!40000 ALTER TABLE `slt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `software`
--

DROP TABLE IF EXISTS `software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `software` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `vendor` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('DBServer','Middleware','OtherSoftware','PCSoftware','WebServer') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `software`
--

LOCK TABLES `software` WRITE;
/*!40000 ALTER TABLE `software` DISABLE KEYS */;
/*!40000 ALTER TABLE `software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwareinstance`
--

DROP TABLE IF EXISTS `softwareinstance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `softwareinstance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `functionalci_id` int(11) NOT NULL,
  `software_id` int(11) DEFAULT NULL,
  `softwarelicence_id` int(11) DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `functionalci_id` (`functionalci_id`),
  KEY `software_id` (`software_id`),
  KEY `softwarelicence_id` (`softwarelicence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwareinstance`
--

LOCK TABLES `softwareinstance` WRITE;
/*!40000 ALTER TABLE `softwareinstance` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwareinstance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwarelicence`
--

DROP TABLE IF EXISTS `softwarelicence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `softwarelicence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwarelicence`
--

LOCK TABLES `softwarelicence` WRITE;
/*!40000 ALTER TABLE `softwarelicence` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwarelicence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `softwarepatch`
--

DROP TABLE IF EXISTS `softwarepatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `softwarepatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `softwarepatch`
--

LOCK TABLES `softwarepatch` WRITE;
/*!40000 ALTER TABLE `softwarepatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwarepatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storagesystem`
--

DROP TABLE IF EXISTS `storagesystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storagesystem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storagesystem`
--

LOCK TABLES `storagesystem` WRITE;
/*!40000 ALTER TABLE `storagesystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `storagesystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subnet`
--

DROP TABLE IF EXISTS `subnet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subnet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text COLLATE utf8_unicode_ci,
  `subnet_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `org_id` int(11) NOT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_mask` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subnet`
--

LOCK TABLES `subnet` WRITE;
/*!40000 ALTER TABLE `subnet` DISABLE KEYS */;
/*!40000 ALTER TABLE `subnet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tablet`
--

DROP TABLE IF EXISTS `tablet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tablet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tablet`
--

LOCK TABLES `tablet` WRITE;
/*!40000 ALTER TABLE `tablet` DISABLE KEYS */;
/*!40000 ALTER TABLE `tablet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tape`
--

DROP TABLE IF EXISTS `tape`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tape` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tapelibrary_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tapelibrary_id` (`tapelibrary_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tape`
--

LOCK TABLES `tape` WRITE;
/*!40000 ALTER TABLE `tape` DISABLE KEYS */;
/*!40000 ALTER TABLE `tape` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tapelibrary`
--

DROP TABLE IF EXISTS `tapelibrary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tapelibrary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tapelibrary`
--

LOCK TABLES `tapelibrary` WRITE;
/*!40000 ALTER TABLE `tapelibrary` DISABLE KEYS */;
/*!40000 ALTER TABLE `tapelibrary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telephonyci`
--

DROP TABLE IF EXISTS `telephonyci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telephonyci` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telephonyci`
--

LOCK TABLES `telephonyci` WRITE;
/*!40000 ALTER TABLE `telephonyci` DISABLE KEYS */;
/*!40000 ALTER TABLE `telephonyci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `org_id` int(11) NOT NULL,
  `caller_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `close_date` datetime DEFAULT NULL,
  `private_log` longtext COLLATE utf8_unicode_ci,
  `private_log_index` blob,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `caller_id` (`caller_id`),
  KEY `team_id` (`team_id`),
  KEY `agent_id` (`agent_id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_incident`
--

DROP TABLE IF EXISTS `ticket_incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_incident` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('assigned','closed','escalated_tto','escalated_ttr','new','pending','resolved') COLLATE utf8_unicode_ci NOT NULL,
  `impact` enum('1','2','3') COLLATE utf8_unicode_ci NOT NULL,
  `priority` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL,
  `urgency` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL,
  `origin` enum('mail','monitoring','phone','portal') COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `servicesubcategory_id` int(11) DEFAULT NULL,
  `escalation_flag` enum('no','yes') COLLATE utf8_unicode_ci DEFAULT NULL,
  `escalation_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  `last_pending_date` datetime DEFAULT NULL,
  `cumulatedpending_timespent` int(11) unsigned DEFAULT NULL,
  `cumulatedpending_started` datetime DEFAULT NULL,
  `cumulatedpending_laststart` datetime DEFAULT NULL,
  `cumulatedpending_stopped` datetime DEFAULT NULL,
  `tto_timespent` int(11) unsigned DEFAULT NULL,
  `tto_started` datetime DEFAULT NULL,
  `tto_laststart` datetime DEFAULT NULL,
  `tto_stopped` datetime DEFAULT NULL,
  `tto_75_deadline` datetime DEFAULT NULL,
  `tto_75_passed` tinyint(1) unsigned DEFAULT NULL,
  `tto_75_triggered` tinyint(1) DEFAULT NULL,
  `tto_75_overrun` int(11) unsigned DEFAULT NULL,
  `tto_100_deadline` datetime DEFAULT NULL,
  `tto_100_passed` tinyint(1) unsigned DEFAULT NULL,
  `tto_100_triggered` tinyint(1) DEFAULT NULL,
  `tto_100_overrun` int(11) unsigned DEFAULT NULL,
  `ttr_timespent` int(11) unsigned DEFAULT NULL,
  `ttr_started` datetime DEFAULT NULL,
  `ttr_laststart` datetime DEFAULT NULL,
  `ttr_stopped` datetime DEFAULT NULL,
  `ttr_75_deadline` datetime DEFAULT NULL,
  `ttr_75_passed` tinyint(1) unsigned DEFAULT NULL,
  `ttr_75_triggered` tinyint(1) DEFAULT NULL,
  `ttr_75_overrun` int(11) unsigned DEFAULT NULL,
  `ttr_100_deadline` datetime DEFAULT NULL,
  `ttr_100_passed` tinyint(1) unsigned DEFAULT NULL,
  `ttr_100_triggered` tinyint(1) DEFAULT NULL,
  `ttr_100_overrun` int(11) unsigned DEFAULT NULL,
  `time_spent` int(11) unsigned DEFAULT NULL,
  `resolution_code` enum('assistance','bug fixed','hardware repair','other','software patch','system update','training') COLLATE utf8_unicode_ci DEFAULT NULL,
  `solution` text COLLATE utf8_unicode_ci,
  `pending_reason` text COLLATE utf8_unicode_ci,
  `parent_incident_id` int(11) DEFAULT NULL,
  `parent_problem_id` int(11) DEFAULT NULL,
  `parent_change_id` int(11) DEFAULT NULL,
  `public_log` longtext COLLATE utf8_unicode_ci,
  `public_log_index` blob,
  `user_satisfaction` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_commment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `servicesubcategory_id` (`servicesubcategory_id`),
  KEY `parent_incident_id` (`parent_incident_id`),
  KEY `parent_problem_id` (`parent_problem_id`),
  KEY `parent_change_id` (`parent_change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_incident`
--

LOCK TABLES `ticket_incident` WRITE;
/*!40000 ALTER TABLE `ticket_incident` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_incident` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_problem`
--

DROP TABLE IF EXISTS `ticket_problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_problem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('assigned','closed','new','resolved') COLLATE utf8_unicode_ci NOT NULL,
  `service_id` int(11) DEFAULT NULL,
  `servicesubcategory_id` int(11) DEFAULT NULL,
  `product` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `impact` enum('1','2','3') COLLATE utf8_unicode_ci NOT NULL,
  `urgency` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL,
  `priority` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL,
  `related_change_id` int(11) DEFAULT NULL,
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `servicesubcategory_id` (`servicesubcategory_id`),
  KEY `related_change_id` (`related_change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_problem`
--

LOCK TABLES `ticket_problem` WRITE;
/*!40000 ALTER TABLE `ticket_problem` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_problem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_request`
--

DROP TABLE IF EXISTS `ticket_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('approved','assigned','closed','escalated_tto','escalated_ttr','new','pending','rejected','resolved','waiting_for_approval') COLLATE utf8_unicode_ci NOT NULL,
  `request_type` enum('service_request') COLLATE utf8_unicode_ci DEFAULT NULL,
  `impact` enum('1','2','3') COLLATE utf8_unicode_ci NOT NULL,
  `priority` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL,
  `urgency` enum('1','2','3','4') COLLATE utf8_unicode_ci NOT NULL,
  `origin` enum('mail','phone','portal') COLLATE utf8_unicode_ci DEFAULT NULL,
  `approver_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `servicesubcategory_id` int(11) DEFAULT NULL,
  `escalation_flag` enum('no','yes') COLLATE utf8_unicode_ci DEFAULT NULL,
  `escalation_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assignment_date` datetime DEFAULT NULL,
  `resolution_date` datetime DEFAULT NULL,
  `last_pending_date` datetime DEFAULT NULL,
  `cumulatedpending_timespent` int(11) unsigned DEFAULT NULL,
  `cumulatedpending_started` datetime DEFAULT NULL,
  `cumulatedpending_laststart` datetime DEFAULT NULL,
  `cumulatedpending_stopped` datetime DEFAULT NULL,
  `tto_timespent` int(11) unsigned DEFAULT NULL,
  `tto_started` datetime DEFAULT NULL,
  `tto_laststart` datetime DEFAULT NULL,
  `tto_stopped` datetime DEFAULT NULL,
  `tto_75_deadline` datetime DEFAULT NULL,
  `tto_75_passed` tinyint(1) unsigned DEFAULT NULL,
  `tto_75_triggered` tinyint(1) DEFAULT NULL,
  `tto_75_overrun` int(11) unsigned DEFAULT NULL,
  `tto_100_deadline` datetime DEFAULT NULL,
  `tto_100_passed` tinyint(1) unsigned DEFAULT NULL,
  `tto_100_triggered` tinyint(1) DEFAULT NULL,
  `tto_100_overrun` int(11) unsigned DEFAULT NULL,
  `ttr_timespent` int(11) unsigned DEFAULT NULL,
  `ttr_started` datetime DEFAULT NULL,
  `ttr_laststart` datetime DEFAULT NULL,
  `ttr_stopped` datetime DEFAULT NULL,
  `ttr_75_deadline` datetime DEFAULT NULL,
  `ttr_75_passed` tinyint(1) unsigned DEFAULT NULL,
  `ttr_75_triggered` tinyint(1) DEFAULT NULL,
  `ttr_75_overrun` int(11) unsigned DEFAULT NULL,
  `ttr_100_deadline` datetime DEFAULT NULL,
  `ttr_100_passed` tinyint(1) unsigned DEFAULT NULL,
  `ttr_100_triggered` tinyint(1) DEFAULT NULL,
  `ttr_100_overrun` int(11) unsigned DEFAULT NULL,
  `time_spent` int(11) unsigned DEFAULT NULL,
  `resolution_code` enum('assistance','bug fixed','hardware repair','other','software patch','system update','training') COLLATE utf8_unicode_ci DEFAULT NULL,
  `solution` text COLLATE utf8_unicode_ci,
  `pending_reason` text COLLATE utf8_unicode_ci,
  `parent_request_id` int(11) DEFAULT NULL,
  `parent_incident_id` int(11) DEFAULT NULL,
  `parent_problem_id` int(11) DEFAULT NULL,
  `parent_change_id` int(11) DEFAULT NULL,
  `public_log` longtext COLLATE utf8_unicode_ci,
  `public_log_index` blob,
  `user_satisfaction` enum('1','2','3','4') COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_commment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `approver_id` (`approver_id`),
  KEY `service_id` (`service_id`),
  KEY `servicesubcategory_id` (`servicesubcategory_id`),
  KEY `parent_request_id` (`parent_request_id`),
  KEY `parent_incident_id` (`parent_incident_id`),
  KEY `parent_problem_id` (`parent_problem_id`),
  KEY `parent_change_id` (`parent_change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_request`
--

LOCK TABLES `ticket_request` WRITE;
/*!40000 ALTER TABLE `ticket_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typology`
--

DROP TABLE IF EXISTS `typology`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typology` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `finalclass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `finalclass` (`finalclass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typology`
--

LOCK TABLES `typology` WRITE;
/*!40000 ALTER TABLE `typology` DISABLE KEYS */;
/*!40000 ALTER TABLE `typology` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_ActionEmail`
--

DROP TABLE IF EXISTS `view_ActionEmail`;
/*!50001 DROP VIEW IF EXISTS `view_ActionEmail`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ActionEmail` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `status`,
 1 AS `test_recipient`,
 1 AS `from`,
 1 AS `reply_to`,
 1 AS `to`,
 1 AS `cc`,
 1 AS `bcc`,
 1 AS `subject`,
 1 AS `body`,
 1 AS `importance`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_ApplicationSolution`
--

DROP TABLE IF EXISTS `view_ApplicationSolution`;
/*!50001 DROP VIEW IF EXISTS `view_ApplicationSolution`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ApplicationSolution` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_ApprovedChange`
--

DROP TABLE IF EXISTS `view_ApprovedChange`;
/*!50001 DROP VIEW IF EXISTS `view_ApprovedChange`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ApprovedChange` AS SELECT 
 1 AS `id`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `status`,
 1 AS `reason`,
 1 AS `requestor_id`,
 1 AS `requestor_email`,
 1 AS `creation_date`,
 1 AS `impact`,
 1 AS `supervisor_group_id`,
 1 AS `supervisor_group_name`,
 1 AS `supervisor_id`,
 1 AS `supervisor_email`,
 1 AS `manager_group_id`,
 1 AS `manager_group_name`,
 1 AS `manager_id`,
 1 AS `manager_email`,
 1 AS `outage`,
 1 AS `fallback`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `approval_date`,
 1 AS `approval_comment`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `requestor_id_friendlyname`,
 1 AS `supervisor_group_id_friendlyname`,
 1 AS `supervisor_id_friendlyname`,
 1 AS `manager_group_id_friendlyname`,
 1 AS `manager_id_friendlyname`,
 1 AS `parent_id_friendlyname`,
 1 AS `parent_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Attachment`
--

DROP TABLE IF EXISTS `view_Attachment`;
/*!50001 DROP VIEW IF EXISTS `view_Attachment`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Attachment` AS SELECT 
 1 AS `id`,
 1 AS `expire`,
 1 AS `temp_id`,
 1 AS `item_class`,
 1 AS `item_id`,
 1 AS `item_org_id`,
 1 AS `contents`,
 1 AS `contents_data`,
 1 AS `contents_filename`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Brand`
--

DROP TABLE IF EXISTS `view_Brand`;
/*!50001 DROP VIEW IF EXISTS `view_Brand`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Brand` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_BusinessProcess`
--

DROP TABLE IF EXISTS `view_BusinessProcess`;
/*!50001 DROP VIEW IF EXISTS `view_BusinessProcess`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_BusinessProcess` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Change`
--

DROP TABLE IF EXISTS `view_Change`;
/*!50001 DROP VIEW IF EXISTS `view_Change`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Change` AS SELECT 
 1 AS `id`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `status`,
 1 AS `reason`,
 1 AS `requestor_id`,
 1 AS `requestor_email`,
 1 AS `creation_date`,
 1 AS `impact`,
 1 AS `supervisor_group_id`,
 1 AS `supervisor_group_name`,
 1 AS `supervisor_id`,
 1 AS `supervisor_email`,
 1 AS `manager_group_id`,
 1 AS `manager_group_name`,
 1 AS `manager_id`,
 1 AS `manager_email`,
 1 AS `outage`,
 1 AS `fallback`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `requestor_id_friendlyname`,
 1 AS `supervisor_group_id_friendlyname`,
 1 AS `supervisor_id_friendlyname`,
 1 AS `manager_group_id_friendlyname`,
 1 AS `manager_id_friendlyname`,
 1 AS `parent_id_friendlyname`,
 1 AS `parent_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_ConnectableCI`
--

DROP TABLE IF EXISTS `view_ConnectableCI`;
/*!50001 DROP VIEW IF EXISTS `view_ConnectableCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ConnectableCI` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Contact`
--

DROP TABLE IF EXISTS `view_Contact`;
/*!50001 DROP VIEW IF EXISTS `view_Contact`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Contact` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `status`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `email`,
 1 AS `phone`,
 1 AS `notify`,
 1 AS `function`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_ContactType`
--

DROP TABLE IF EXISTS `view_ContactType`;
/*!50001 DROP VIEW IF EXISTS `view_ContactType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ContactType` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Contract`
--

DROP TABLE IF EXISTS `view_Contract`;
/*!50001 DROP VIEW IF EXISTS `view_Contract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Contract` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `cost`,
 1 AS `cost_currency`,
 1 AS `contracttype_id`,
 1 AS `contracttype_name`,
 1 AS `billing_frequency`,
 1 AS `cost_unit`,
 1 AS `provider_id`,
 1 AS `provider_name`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `contracttype_id_friendlyname`,
 1 AS `provider_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_ContractType`
--

DROP TABLE IF EXISTS `view_ContractType`;
/*!50001 DROP VIEW IF EXISTS `view_ContractType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ContractType` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_CustomerContract`
--

DROP TABLE IF EXISTS `view_CustomerContract`;
/*!50001 DROP VIEW IF EXISTS `view_CustomerContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_CustomerContract` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `cost`,
 1 AS `cost_currency`,
 1 AS `contracttype_id`,
 1 AS `contracttype_name`,
 1 AS `billing_frequency`,
 1 AS `cost_unit`,
 1 AS `provider_id`,
 1 AS `provider_name`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `contracttype_id_friendlyname`,
 1 AS `provider_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_DBServer`
--

DROP TABLE IF EXISTS `view_DBServer`;
/*!50001 DROP VIEW IF EXISTS `view_DBServer`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DBServer` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `system_id`,
 1 AS `system_name`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `softwarelicence_id`,
 1 AS `softwarelicence_name`,
 1 AS `path`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `system_id_friendlyname`,
 1 AS `system_id_finalclass_recall`,
 1 AS `software_id_friendlyname`,
 1 AS `softwarelicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_DatabaseSchema`
--

DROP TABLE IF EXISTS `view_DatabaseSchema`;
/*!50001 DROP VIEW IF EXISTS `view_DatabaseSchema`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DatabaseSchema` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `dbserver_id`,
 1 AS `dbserver_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `dbserver_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_DatacenterDevice`
--

DROP TABLE IF EXISTS `view_DatacenterDevice`;
/*!50001 DROP VIEW IF EXISTS `view_DatacenterDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DatacenterDevice` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_DeliveryModel`
--

DROP TABLE IF EXISTS `view_DeliveryModel`;
/*!50001 DROP VIEW IF EXISTS `view_DeliveryModel`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DeliveryModel` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `description`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Document`
--

DROP TABLE IF EXISTS `view_Document`;
/*!50001 DROP VIEW IF EXISTS `view_Document`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Document` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `documenttype_id`,
 1 AS `documenttype_name`,
 1 AS `version`,
 1 AS `description`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `documenttype_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_DocumentFile`
--

DROP TABLE IF EXISTS `view_DocumentFile`;
/*!50001 DROP VIEW IF EXISTS `view_DocumentFile`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DocumentFile` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `documenttype_id`,
 1 AS `documenttype_name`,
 1 AS `version`,
 1 AS `description`,
 1 AS `status`,
 1 AS `file`,
 1 AS `file_data`,
 1 AS `file_filename`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `documenttype_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_DocumentNote`
--

DROP TABLE IF EXISTS `view_DocumentNote`;
/*!50001 DROP VIEW IF EXISTS `view_DocumentNote`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DocumentNote` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `documenttype_id`,
 1 AS `documenttype_name`,
 1 AS `version`,
 1 AS `description`,
 1 AS `status`,
 1 AS `text`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `documenttype_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_DocumentType`
--

DROP TABLE IF EXISTS `view_DocumentType`;
/*!50001 DROP VIEW IF EXISTS `view_DocumentType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DocumentType` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_DocumentWeb`
--

DROP TABLE IF EXISTS `view_DocumentWeb`;
/*!50001 DROP VIEW IF EXISTS `view_DocumentWeb`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_DocumentWeb` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `documenttype_id`,
 1 AS `documenttype_name`,
 1 AS `version`,
 1 AS `description`,
 1 AS `status`,
 1 AS `url`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `documenttype_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_EmergencyChange`
--

DROP TABLE IF EXISTS `view_EmergencyChange`;
/*!50001 DROP VIEW IF EXISTS `view_EmergencyChange`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_EmergencyChange` AS SELECT 
 1 AS `id`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `status`,
 1 AS `reason`,
 1 AS `requestor_id`,
 1 AS `requestor_email`,
 1 AS `creation_date`,
 1 AS `impact`,
 1 AS `supervisor_group_id`,
 1 AS `supervisor_group_name`,
 1 AS `supervisor_id`,
 1 AS `supervisor_email`,
 1 AS `manager_group_id`,
 1 AS `manager_group_name`,
 1 AS `manager_id`,
 1 AS `manager_email`,
 1 AS `outage`,
 1 AS `fallback`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `approval_date`,
 1 AS `approval_comment`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `requestor_id_friendlyname`,
 1 AS `supervisor_group_id_friendlyname`,
 1 AS `supervisor_id_friendlyname`,
 1 AS `manager_group_id_friendlyname`,
 1 AS `manager_id_friendlyname`,
 1 AS `parent_id_friendlyname`,
 1 AS `parent_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Enclosure`
--

DROP TABLE IF EXISTS `view_Enclosure`;
/*!50001 DROP VIEW IF EXISTS `view_Enclosure`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Enclosure` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `nb_u`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_FAQ`
--

DROP TABLE IF EXISTS `view_FAQ`;
/*!50001 DROP VIEW IF EXISTS `view_FAQ`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_FAQ` AS SELECT 
 1 AS `id`,
 1 AS `title`,
 1 AS `summary`,
 1 AS `description`,
 1 AS `category_id`,
 1 AS `category_name`,
 1 AS `error_code`,
 1 AS `key_words`,
 1 AS `friendlyname`,
 1 AS `category_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_FAQCategory`
--

DROP TABLE IF EXISTS `view_FAQCategory`;
/*!50001 DROP VIEW IF EXISTS `view_FAQCategory`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_FAQCategory` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Farm`
--

DROP TABLE IF EXISTS `view_Farm`;
/*!50001 DROP VIEW IF EXISTS `view_Farm`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Farm` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_FiberChannelInterface`
--

DROP TABLE IF EXISTS `view_FiberChannelInterface`;
/*!50001 DROP VIEW IF EXISTS `view_FiberChannelInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_FiberChannelInterface` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `speed`,
 1 AS `topology`,
 1 AS `wwn`,
 1 AS `datacenterdevice_id`,
 1 AS `datacenterdevice_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `datacenterdevice_id_friendlyname`,
 1 AS `datacenterdevice_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_FunctionalCI`
--

DROP TABLE IF EXISTS `view_FunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_FunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_FunctionalCI` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Group`
--

DROP TABLE IF EXISTS `view_Group`;
/*!50001 DROP VIEW IF EXISTS `view_Group`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Group` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `status`,
 1 AS `org_id`,
 1 AS `owner_name`,
 1 AS `description`,
 1 AS `type`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `parent_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Hypervisor`
--

DROP TABLE IF EXISTS `view_Hypervisor`;
/*!50001 DROP VIEW IF EXISTS `view_Hypervisor`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Hypervisor` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `farm_id`,
 1 AS `farm_name`,
 1 AS `server_id`,
 1 AS `server_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `farm_id_friendlyname`,
 1 AS `server_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_IOSVersion`
--

DROP TABLE IF EXISTS `view_IOSVersion`;
/*!50001 DROP VIEW IF EXISTS `view_IOSVersion`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_IOSVersion` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `brand_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_IPInterface`
--

DROP TABLE IF EXISTS `view_IPInterface`;
/*!50001 DROP VIEW IF EXISTS `view_IPInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_IPInterface` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `ipaddress`,
 1 AS `macaddress`,
 1 AS `comment`,
 1 AS `ipgateway`,
 1 AS `ipmask`,
 1 AS `speed`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_IPPhone`
--

DROP TABLE IF EXISTS `view_IPPhone`;
/*!50001 DROP VIEW IF EXISTS `view_IPPhone`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_IPPhone` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `phonenumber`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Incident`
--

DROP TABLE IF EXISTS `view_Incident`;
/*!50001 DROP VIEW IF EXISTS `view_Incident`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Incident` AS SELECT 
 1 AS `id`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `status`,
 1 AS `impact`,
 1 AS `priority`,
 1 AS `urgency`,
 1 AS `origin`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `servicesubcategory_id`,
 1 AS `servicesubcategory_name`,
 1 AS `escalation_flag`,
 1 AS `escalation_reason`,
 1 AS `assignment_date`,
 1 AS `resolution_date`,
 1 AS `last_pending_date`,
 1 AS `cumulatedpending`,
 1 AS `cumulatedpending_started`,
 1 AS `cumulatedpending_laststart`,
 1 AS `cumulatedpending_stopped`,
 1 AS `tto`,
 1 AS `tto_started`,
 1 AS `tto_laststart`,
 1 AS `tto_stopped`,
 1 AS `tto_75_deadline`,
 1 AS `tto_75_passed`,
 1 AS `tto_75_triggered`,
 1 AS `tto_75_overrun`,
 1 AS `tto_100_deadline`,
 1 AS `tto_100_passed`,
 1 AS `tto_100_triggered`,
 1 AS `tto_100_overrun`,
 1 AS `ttr`,
 1 AS `ttr_started`,
 1 AS `ttr_laststart`,
 1 AS `ttr_stopped`,
 1 AS `ttr_75_deadline`,
 1 AS `ttr_75_passed`,
 1 AS `ttr_75_triggered`,
 1 AS `ttr_75_overrun`,
 1 AS `ttr_100_deadline`,
 1 AS `ttr_100_passed`,
 1 AS `ttr_100_triggered`,
 1 AS `ttr_100_overrun`,
 1 AS `tto_escalation_deadline`,
 1 AS `sla_tto_passed`,
 1 AS `sla_tto_over`,
 1 AS `ttr_escalation_deadline`,
 1 AS `sla_ttr_passed`,
 1 AS `sla_ttr_over`,
 1 AS `time_spent`,
 1 AS `resolution_code`,
 1 AS `solution`,
 1 AS `pending_reason`,
 1 AS `parent_incident_id`,
 1 AS `parent_incident_ref`,
 1 AS `parent_problem_id`,
 1 AS `parent_problem_ref`,
 1 AS `parent_change_id`,
 1 AS `parent_change_ref`,
 1 AS `public_log`,
 1 AS `public_log_index`,
 1 AS `user_satisfaction`,
 1 AS `user_comment`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `servicesubcategory_id_friendlyname`,
 1 AS `parent_incident_id_friendlyname`,
 1 AS `parent_problem_id_friendlyname`,
 1 AS `parent_change_id_friendlyname`,
 1 AS `parent_change_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_KnownError`
--

DROP TABLE IF EXISTS `view_KnownError`;
/*!50001 DROP VIEW IF EXISTS `view_KnownError`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_KnownError` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `cust_name`,
 1 AS `problem_id`,
 1 AS `problem_ref`,
 1 AS `symptom`,
 1 AS `root_cause`,
 1 AS `workaround`,
 1 AS `solution`,
 1 AS `error_code`,
 1 AS `domain`,
 1 AS `vendor`,
 1 AS `model`,
 1 AS `version`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `problem_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Licence`
--

DROP TABLE IF EXISTS `view_Licence`;
/*!50001 DROP VIEW IF EXISTS `view_Licence`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Licence` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `usage_limit`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `licence_key`,
 1 AS `perpetual`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Location`
--

DROP TABLE IF EXISTS `view_Location`;
/*!50001 DROP VIEW IF EXISTS `view_Location`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Location` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `status`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `address`,
 1 AS `postal_code`,
 1 AS `city`,
 1 AS `country`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_LogicalInterface`
--

DROP TABLE IF EXISTS `view_LogicalInterface`;
/*!50001 DROP VIEW IF EXISTS `view_LogicalInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_LogicalInterface` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `ipaddress`,
 1 AS `macaddress`,
 1 AS `comment`,
 1 AS `ipgateway`,
 1 AS `ipmask`,
 1 AS `speed`,
 1 AS `virtualmachine_id`,
 1 AS `virtualmachine_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `virtualmachine_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_LogicalVolume`
--

DROP TABLE IF EXISTS `view_LogicalVolume`;
/*!50001 DROP VIEW IF EXISTS `view_LogicalVolume`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_LogicalVolume` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `lun_id`,
 1 AS `description`,
 1 AS `raid_level`,
 1 AS `size`,
 1 AS `storagesystem_id`,
 1 AS `storagesystem_name`,
 1 AS `friendlyname`,
 1 AS `storagesystem_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Middleware`
--

DROP TABLE IF EXISTS `view_Middleware`;
/*!50001 DROP VIEW IF EXISTS `view_Middleware`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Middleware` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `system_id`,
 1 AS `system_name`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `softwarelicence_id`,
 1 AS `softwarelicence_name`,
 1 AS `path`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `system_id_friendlyname`,
 1 AS `system_id_finalclass_recall`,
 1 AS `software_id_friendlyname`,
 1 AS `softwarelicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_MiddlewareInstance`
--

DROP TABLE IF EXISTS `view_MiddlewareInstance`;
/*!50001 DROP VIEW IF EXISTS `view_MiddlewareInstance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_MiddlewareInstance` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `middleware_id`,
 1 AS `middleware_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `middleware_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_MobilePhone`
--

DROP TABLE IF EXISTS `view_MobilePhone`;
/*!50001 DROP VIEW IF EXISTS `view_MobilePhone`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_MobilePhone` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `phonenumber`,
 1 AS `imei`,
 1 AS `hw_pin`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Model`
--

DROP TABLE IF EXISTS `view_Model`;
/*!50001 DROP VIEW IF EXISTS `view_Model`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Model` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `type`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `brand_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_NAS`
--

DROP TABLE IF EXISTS `view_NAS`;
/*!50001 DROP VIEW IF EXISTS `view_NAS`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_NAS` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_NASFileSystem`
--

DROP TABLE IF EXISTS `view_NASFileSystem`;
/*!50001 DROP VIEW IF EXISTS `view_NASFileSystem`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_NASFileSystem` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `raid_level`,
 1 AS `size`,
 1 AS `nas_id`,
 1 AS `nas_name`,
 1 AS `friendlyname`,
 1 AS `nas_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_NetworkDevice`
--

DROP TABLE IF EXISTS `view_NetworkDevice`;
/*!50001 DROP VIEW IF EXISTS `view_NetworkDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_NetworkDevice` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `networkdevicetype_id`,
 1 AS `networkdevicetype_name`,
 1 AS `iosversion_id`,
 1 AS `iosversion_name`,
 1 AS `ram`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`,
 1 AS `networkdevicetype_id_friendlyname`,
 1 AS `iosversion_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_NetworkDeviceType`
--

DROP TABLE IF EXISTS `view_NetworkDeviceType`;
/*!50001 DROP VIEW IF EXISTS `view_NetworkDeviceType`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_NetworkDeviceType` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_NetworkInterface`
--

DROP TABLE IF EXISTS `view_NetworkInterface`;
/*!50001 DROP VIEW IF EXISTS `view_NetworkInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_NetworkInterface` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_NormalChange`
--

DROP TABLE IF EXISTS `view_NormalChange`;
/*!50001 DROP VIEW IF EXISTS `view_NormalChange`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_NormalChange` AS SELECT 
 1 AS `id`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `status`,
 1 AS `reason`,
 1 AS `requestor_id`,
 1 AS `requestor_email`,
 1 AS `creation_date`,
 1 AS `impact`,
 1 AS `supervisor_group_id`,
 1 AS `supervisor_group_name`,
 1 AS `supervisor_id`,
 1 AS `supervisor_email`,
 1 AS `manager_group_id`,
 1 AS `manager_group_name`,
 1 AS `manager_id`,
 1 AS `manager_email`,
 1 AS `outage`,
 1 AS `fallback`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `approval_date`,
 1 AS `approval_comment`,
 1 AS `acceptance_date`,
 1 AS `acceptance_comment`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `requestor_id_friendlyname`,
 1 AS `supervisor_group_id_friendlyname`,
 1 AS `supervisor_id_friendlyname`,
 1 AS `manager_group_id_friendlyname`,
 1 AS `manager_id_friendlyname`,
 1 AS `parent_id_friendlyname`,
 1 AS `parent_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_OSFamily`
--

DROP TABLE IF EXISTS `view_OSFamily`;
/*!50001 DROP VIEW IF EXISTS `view_OSFamily`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_OSFamily` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_OSLicence`
--

DROP TABLE IF EXISTS `view_OSLicence`;
/*!50001 DROP VIEW IF EXISTS `view_OSLicence`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_OSLicence` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `usage_limit`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `licence_key`,
 1 AS `perpetual`,
 1 AS `osversion_id`,
 1 AS `osversion_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `osversion_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_OSPatch`
--

DROP TABLE IF EXISTS `view_OSPatch`;
/*!50001 DROP VIEW IF EXISTS `view_OSPatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_OSPatch` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `osversion_id`,
 1 AS `osversion_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `osversion_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_OSVersion`
--

DROP TABLE IF EXISTS `view_OSVersion`;
/*!50001 DROP VIEW IF EXISTS `view_OSVersion`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_OSVersion` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `osfamily_id`,
 1 AS `osfamily_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `osfamily_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Organization`
--

DROP TABLE IF EXISTS `view_Organization`;
/*!50001 DROP VIEW IF EXISTS `view_Organization`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Organization` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `code`,
 1 AS `status`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `deliverymodel_id`,
 1 AS `deliverymodel_name`,
 1 AS `friendlyname`,
 1 AS `parent_id_friendlyname`,
 1 AS `deliverymodel_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_OtherSoftware`
--

DROP TABLE IF EXISTS `view_OtherSoftware`;
/*!50001 DROP VIEW IF EXISTS `view_OtherSoftware`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_OtherSoftware` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `system_id`,
 1 AS `system_name`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `softwarelicence_id`,
 1 AS `softwarelicence_name`,
 1 AS `path`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `system_id_friendlyname`,
 1 AS `system_id_finalclass_recall`,
 1 AS `software_id_friendlyname`,
 1 AS `softwarelicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_PC`
--

DROP TABLE IF EXISTS `view_PC`;
/*!50001 DROP VIEW IF EXISTS `view_PC`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PC` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `osfamily_id`,
 1 AS `osfamily_name`,
 1 AS `osversion_id`,
 1 AS `osversion_name`,
 1 AS `cpu`,
 1 AS `ram`,
 1 AS `type`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `osfamily_id_friendlyname`,
 1 AS `osversion_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_PCSoftware`
--

DROP TABLE IF EXISTS `view_PCSoftware`;
/*!50001 DROP VIEW IF EXISTS `view_PCSoftware`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PCSoftware` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `system_id`,
 1 AS `system_name`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `softwarelicence_id`,
 1 AS `softwarelicence_name`,
 1 AS `path`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `system_id_friendlyname`,
 1 AS `system_id_finalclass_recall`,
 1 AS `software_id_friendlyname`,
 1 AS `softwarelicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_PDU`
--

DROP TABLE IF EXISTS `view_PDU`;
/*!50001 DROP VIEW IF EXISTS `view_PDU`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PDU` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `powerstart_id`,
 1 AS `powerstart_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `powerstart_id_friendlyname`,
 1 AS `powerstart_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Patch`
--

DROP TABLE IF EXISTS `view_Patch`;
/*!50001 DROP VIEW IF EXISTS `view_Patch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Patch` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Peripheral`
--

DROP TABLE IF EXISTS `view_Peripheral`;
/*!50001 DROP VIEW IF EXISTS `view_Peripheral`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Peripheral` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Person`
--

DROP TABLE IF EXISTS `view_Person`;
/*!50001 DROP VIEW IF EXISTS `view_Person`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Person` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `status`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `email`,
 1 AS `phone`,
 1 AS `notify`,
 1 AS `function`,
 1 AS `first_name`,
 1 AS `employee_number`,
 1 AS `mobile_phone`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `manager_id`,
 1 AS `manager_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `manager_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Phone`
--

DROP TABLE IF EXISTS `view_Phone`;
/*!50001 DROP VIEW IF EXISTS `view_Phone`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Phone` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `phonenumber`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_PhysicalDevice`
--

DROP TABLE IF EXISTS `view_PhysicalDevice`;
/*!50001 DROP VIEW IF EXISTS `view_PhysicalDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PhysicalDevice` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_PhysicalInterface`
--

DROP TABLE IF EXISTS `view_PhysicalInterface`;
/*!50001 DROP VIEW IF EXISTS `view_PhysicalInterface`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PhysicalInterface` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `ipaddress`,
 1 AS `macaddress`,
 1 AS `comment`,
 1 AS `ipgateway`,
 1 AS `ipmask`,
 1 AS `speed`,
 1 AS `connectableci_id`,
 1 AS `connectableci_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `connectableci_id_friendlyname`,
 1 AS `connectableci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_PowerConnection`
--

DROP TABLE IF EXISTS `view_PowerConnection`;
/*!50001 DROP VIEW IF EXISTS `view_PowerConnection`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PowerConnection` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_PowerSource`
--

DROP TABLE IF EXISTS `view_PowerSource`;
/*!50001 DROP VIEW IF EXISTS `view_PowerSource`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PowerSource` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Printer`
--

DROP TABLE IF EXISTS `view_Printer`;
/*!50001 DROP VIEW IF EXISTS `view_Printer`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Printer` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Problem`
--

DROP TABLE IF EXISTS `view_Problem`;
/*!50001 DROP VIEW IF EXISTS `view_Problem`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Problem` AS SELECT 
 1 AS `id`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `status`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `servicesubcategory_id`,
 1 AS `servicesubcategory_name`,
 1 AS `product`,
 1 AS `impact`,
 1 AS `urgency`,
 1 AS `priority`,
 1 AS `related_change_id`,
 1 AS `related_change_ref`,
 1 AS `assignment_date`,
 1 AS `resolution_date`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `servicesubcategory_id_friendlyname`,
 1 AS `related_change_id_friendlyname`,
 1 AS `related_change_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_ProviderContract`
--

DROP TABLE IF EXISTS `view_ProviderContract`;
/*!50001 DROP VIEW IF EXISTS `view_ProviderContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ProviderContract` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `cost`,
 1 AS `cost_currency`,
 1 AS `contracttype_id`,
 1 AS `contracttype_name`,
 1 AS `billing_frequency`,
 1 AS `cost_unit`,
 1 AS `provider_id`,
 1 AS `provider_name`,
 1 AS `status`,
 1 AS `sla`,
 1 AS `coverage`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `contracttype_id_friendlyname`,
 1 AS `provider_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Rack`
--

DROP TABLE IF EXISTS `view_Rack`;
/*!50001 DROP VIEW IF EXISTS `view_Rack`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Rack` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `nb_u`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_RoutineChange`
--

DROP TABLE IF EXISTS `view_RoutineChange`;
/*!50001 DROP VIEW IF EXISTS `view_RoutineChange`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_RoutineChange` AS SELECT 
 1 AS `id`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `status`,
 1 AS `reason`,
 1 AS `requestor_id`,
 1 AS `requestor_email`,
 1 AS `creation_date`,
 1 AS `impact`,
 1 AS `supervisor_group_id`,
 1 AS `supervisor_group_name`,
 1 AS `supervisor_id`,
 1 AS `supervisor_email`,
 1 AS `manager_group_id`,
 1 AS `manager_group_name`,
 1 AS `manager_id`,
 1 AS `manager_email`,
 1 AS `outage`,
 1 AS `fallback`,
 1 AS `parent_id`,
 1 AS `parent_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `requestor_id_friendlyname`,
 1 AS `supervisor_group_id_friendlyname`,
 1 AS `supervisor_id_friendlyname`,
 1 AS `manager_group_id_friendlyname`,
 1 AS `manager_id_friendlyname`,
 1 AS `parent_id_friendlyname`,
 1 AS `parent_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_SANSwitch`
--

DROP TABLE IF EXISTS `view_SANSwitch`;
/*!50001 DROP VIEW IF EXISTS `view_SANSwitch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_SANSwitch` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_SLA`
--

DROP TABLE IF EXISTS `view_SLA`;
/*!50001 DROP VIEW IF EXISTS `view_SLA`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_SLA` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_SLT`
--

DROP TABLE IF EXISTS `view_SLT`;
/*!50001 DROP VIEW IF EXISTS `view_SLT`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_SLT` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `priority`,
 1 AS `request_type`,
 1 AS `metric`,
 1 AS `value`,
 1 AS `unit`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Server`
--

DROP TABLE IF EXISTS `view_Server`;
/*!50001 DROP VIEW IF EXISTS `view_Server`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Server` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `osfamily_id`,
 1 AS `osfamily_name`,
 1 AS `osversion_id`,
 1 AS `osversion_name`,
 1 AS `oslicence_id`,
 1 AS `oslicence_name`,
 1 AS `cpu`,
 1 AS `ram`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`,
 1 AS `osfamily_id_friendlyname`,
 1 AS `osversion_id_friendlyname`,
 1 AS `oslicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Service`
--

DROP TABLE IF EXISTS `view_Service`;
/*!50001 DROP VIEW IF EXISTS `view_Service`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Service` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `servicefamily_id`,
 1 AS `servicefamily_name`,
 1 AS `description`,
 1 AS `status`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `servicefamily_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_ServiceFamily`
--

DROP TABLE IF EXISTS `view_ServiceFamily`;
/*!50001 DROP VIEW IF EXISTS `view_ServiceFamily`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ServiceFamily` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_ServiceSubcategory`
--

DROP TABLE IF EXISTS `view_ServiceSubcategory`;
/*!50001 DROP VIEW IF EXISTS `view_ServiceSubcategory`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ServiceSubcategory` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `service_id`,
 1 AS `service_org_id`,
 1 AS `service_name`,
 1 AS `service_provider`,
 1 AS `request_type`,
 1 AS `status`,
 1 AS `friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `service_org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Software`
--

DROP TABLE IF EXISTS `view_Software`;
/*!50001 DROP VIEW IF EXISTS `view_Software`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Software` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `vendor`,
 1 AS `version`,
 1 AS `type`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_SoftwareInstance`
--

DROP TABLE IF EXISTS `view_SoftwareInstance`;
/*!50001 DROP VIEW IF EXISTS `view_SoftwareInstance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_SoftwareInstance` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `system_id`,
 1 AS `system_name`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `softwarelicence_id`,
 1 AS `softwarelicence_name`,
 1 AS `path`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `system_id_friendlyname`,
 1 AS `system_id_finalclass_recall`,
 1 AS `software_id_friendlyname`,
 1 AS `softwarelicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_SoftwareLicence`
--

DROP TABLE IF EXISTS `view_SoftwareLicence`;
/*!50001 DROP VIEW IF EXISTS `view_SoftwareLicence`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_SoftwareLicence` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `usage_limit`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `licence_key`,
 1 AS `perpetual`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `software_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_SoftwarePatch`
--

DROP TABLE IF EXISTS `view_SoftwarePatch`;
/*!50001 DROP VIEW IF EXISTS `view_SoftwarePatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_SoftwarePatch` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `software_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_StorageSystem`
--

DROP TABLE IF EXISTS `view_StorageSystem`;
/*!50001 DROP VIEW IF EXISTS `view_StorageSystem`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_StorageSystem` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Subnet`
--

DROP TABLE IF EXISTS `view_Subnet`;
/*!50001 DROP VIEW IF EXISTS `view_Subnet`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Subnet` AS SELECT 
 1 AS `id`,
 1 AS `description`,
 1 AS `subnet_name`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `ip`,
 1 AS `ip_mask`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Tablet`
--

DROP TABLE IF EXISTS `view_Tablet`;
/*!50001 DROP VIEW IF EXISTS `view_Tablet`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Tablet` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Tape`
--

DROP TABLE IF EXISTS `view_Tape`;
/*!50001 DROP VIEW IF EXISTS `view_Tape`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Tape` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `size`,
 1 AS `tapelibrary_id`,
 1 AS `tapelibrary_name`,
 1 AS `friendlyname`,
 1 AS `tapelibrary_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_TapeLibrary`
--

DROP TABLE IF EXISTS `view_TapeLibrary`;
/*!50001 DROP VIEW IF EXISTS `view_TapeLibrary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_TapeLibrary` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `rack_id`,
 1 AS `rack_name`,
 1 AS `enclosure_id`,
 1 AS `enclosure_name`,
 1 AS `nb_u`,
 1 AS `managementip`,
 1 AS `powerA_id`,
 1 AS `powerA_name`,
 1 AS `powerB_id`,
 1 AS `powerB_name`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`,
 1 AS `rack_id_friendlyname`,
 1 AS `enclosure_id_friendlyname`,
 1 AS `powerA_id_friendlyname`,
 1 AS `powerA_id_finalclass_recall`,
 1 AS `powerB_id_friendlyname`,
 1 AS `powerB_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Team`
--

DROP TABLE IF EXISTS `view_Team`;
/*!50001 DROP VIEW IF EXISTS `view_Team`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Team` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `status`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `email`,
 1 AS `phone`,
 1 AS `notify`,
 1 AS `function`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_TelephonyCI`
--

DROP TABLE IF EXISTS `view_TelephonyCI`;
/*!50001 DROP VIEW IF EXISTS `view_TelephonyCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_TelephonyCI` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `serialnumber`,
 1 AS `location_id`,
 1 AS `location_name`,
 1 AS `status`,
 1 AS `brand_id`,
 1 AS `brand_name`,
 1 AS `model_id`,
 1 AS `model_name`,
 1 AS `asset_number`,
 1 AS `purchase_date`,
 1 AS `end_of_warranty`,
 1 AS `phonenumber`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `location_id_friendlyname`,
 1 AS `brand_id_friendlyname`,
 1 AS `model_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Ticket`
--

DROP TABLE IF EXISTS `view_Ticket`;
/*!50001 DROP VIEW IF EXISTS `view_Ticket`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Ticket` AS SELECT 
 1 AS `id`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_TriggerOnObjectCreate`
--

DROP TABLE IF EXISTS `view_TriggerOnObjectCreate`;
/*!50001 DROP VIEW IF EXISTS `view_TriggerOnObjectCreate`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_TriggerOnObjectCreate` AS SELECT 
 1 AS `id`,
 1 AS `description`,
 1 AS `target_class`,
 1 AS `filter`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_TriggerOnPortalUpdate`
--

DROP TABLE IF EXISTS `view_TriggerOnPortalUpdate`;
/*!50001 DROP VIEW IF EXISTS `view_TriggerOnPortalUpdate`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_TriggerOnPortalUpdate` AS SELECT 
 1 AS `id`,
 1 AS `description`,
 1 AS `target_class`,
 1 AS `filter`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_TriggerOnStateEnter`
--

DROP TABLE IF EXISTS `view_TriggerOnStateEnter`;
/*!50001 DROP VIEW IF EXISTS `view_TriggerOnStateEnter`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_TriggerOnStateEnter` AS SELECT 
 1 AS `id`,
 1 AS `description`,
 1 AS `target_class`,
 1 AS `filter`,
 1 AS `state`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_TriggerOnStateLeave`
--

DROP TABLE IF EXISTS `view_TriggerOnStateLeave`;
/*!50001 DROP VIEW IF EXISTS `view_TriggerOnStateLeave`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_TriggerOnStateLeave` AS SELECT 
 1 AS `id`,
 1 AS `description`,
 1 AS `target_class`,
 1 AS `filter`,
 1 AS `state`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_TriggerOnThresholdReached`
--

DROP TABLE IF EXISTS `view_TriggerOnThresholdReached`;
/*!50001 DROP VIEW IF EXISTS `view_TriggerOnThresholdReached`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_TriggerOnThresholdReached` AS SELECT 
 1 AS `id`,
 1 AS `description`,
 1 AS `target_class`,
 1 AS `filter`,
 1 AS `stop_watch_code`,
 1 AS `threshold_index`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_Typology`
--

DROP TABLE IF EXISTS `view_Typology`;
/*!50001 DROP VIEW IF EXISTS `view_Typology`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Typology` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `finalclass`,
 1 AS `friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_UserRequest`
--

DROP TABLE IF EXISTS `view_UserRequest`;
/*!50001 DROP VIEW IF EXISTS `view_UserRequest`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_UserRequest` AS SELECT 
 1 AS `id`,
 1 AS `ref`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `caller_id`,
 1 AS `caller_name`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_name`,
 1 AS `title`,
 1 AS `description`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `last_update`,
 1 AS `close_date`,
 1 AS `private_log`,
 1 AS `private_log_index`,
 1 AS `status`,
 1 AS `request_type`,
 1 AS `impact`,
 1 AS `priority`,
 1 AS `urgency`,
 1 AS `origin`,
 1 AS `approver_id`,
 1 AS `approver_email`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `servicesubcategory_id`,
 1 AS `servicesubcategory_name`,
 1 AS `escalation_flag`,
 1 AS `escalation_reason`,
 1 AS `assignment_date`,
 1 AS `resolution_date`,
 1 AS `last_pending_date`,
 1 AS `cumulatedpending`,
 1 AS `cumulatedpending_started`,
 1 AS `cumulatedpending_laststart`,
 1 AS `cumulatedpending_stopped`,
 1 AS `tto`,
 1 AS `tto_started`,
 1 AS `tto_laststart`,
 1 AS `tto_stopped`,
 1 AS `tto_75_deadline`,
 1 AS `tto_75_passed`,
 1 AS `tto_75_triggered`,
 1 AS `tto_75_overrun`,
 1 AS `tto_100_deadline`,
 1 AS `tto_100_passed`,
 1 AS `tto_100_triggered`,
 1 AS `tto_100_overrun`,
 1 AS `ttr`,
 1 AS `ttr_started`,
 1 AS `ttr_laststart`,
 1 AS `ttr_stopped`,
 1 AS `ttr_75_deadline`,
 1 AS `ttr_75_passed`,
 1 AS `ttr_75_triggered`,
 1 AS `ttr_75_overrun`,
 1 AS `ttr_100_deadline`,
 1 AS `ttr_100_passed`,
 1 AS `ttr_100_triggered`,
 1 AS `ttr_100_overrun`,
 1 AS `tto_escalation_deadline`,
 1 AS `sla_tto_passed`,
 1 AS `sla_tto_over`,
 1 AS `ttr_escalation_deadline`,
 1 AS `sla_ttr_passed`,
 1 AS `sla_ttr_over`,
 1 AS `time_spent`,
 1 AS `resolution_code`,
 1 AS `solution`,
 1 AS `pending_reason`,
 1 AS `parent_request_id`,
 1 AS `parent_request_ref`,
 1 AS `parent_incident_id`,
 1 AS `parent_incident_ref`,
 1 AS `parent_problem_id`,
 1 AS `parent_problem_ref`,
 1 AS `parent_change_id`,
 1 AS `parent_change_ref`,
 1 AS `public_log`,
 1 AS `public_log_index`,
 1 AS `user_satisfaction`,
 1 AS `user_comment`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `caller_id_friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`,
 1 AS `approver_id_friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `servicesubcategory_id_friendlyname`,
 1 AS `parent_request_id_friendlyname`,
 1 AS `parent_incident_id_friendlyname`,
 1 AS `parent_problem_id_friendlyname`,
 1 AS `parent_change_id_friendlyname`,
 1 AS `parent_change_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_VLAN`
--

DROP TABLE IF EXISTS `view_VLAN`;
/*!50001 DROP VIEW IF EXISTS `view_VLAN`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_VLAN` AS SELECT 
 1 AS `id`,
 1 AS `vlan_tag`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `org_name`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_VirtualDevice`
--

DROP TABLE IF EXISTS `view_VirtualDevice`;
/*!50001 DROP VIEW IF EXISTS `view_VirtualDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_VirtualDevice` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_VirtualHost`
--

DROP TABLE IF EXISTS `view_VirtualHost`;
/*!50001 DROP VIEW IF EXISTS `view_VirtualHost`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_VirtualHost` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_VirtualMachine`
--

DROP TABLE IF EXISTS `view_VirtualMachine`;
/*!50001 DROP VIEW IF EXISTS `view_VirtualMachine`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_VirtualMachine` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `status`,
 1 AS `virtualhost_id`,
 1 AS `virtualhost_name`,
 1 AS `osfamily_id`,
 1 AS `osfamily_name`,
 1 AS `osversion_id`,
 1 AS `osversion_name`,
 1 AS `oslicence_id`,
 1 AS `oslicence_name`,
 1 AS `cpu`,
 1 AS `ram`,
 1 AS `managementip`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `virtualhost_id_friendlyname`,
 1 AS `virtualhost_id_finalclass_recall`,
 1 AS `osfamily_id_friendlyname`,
 1 AS `osversion_id_friendlyname`,
 1 AS `oslicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_WebApplication`
--

DROP TABLE IF EXISTS `view_WebApplication`;
/*!50001 DROP VIEW IF EXISTS `view_WebApplication`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_WebApplication` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `webserver_id`,
 1 AS `webserver_name`,
 1 AS `url`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `webserver_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_WebServer`
--

DROP TABLE IF EXISTS `view_WebServer`;
/*!50001 DROP VIEW IF EXISTS `view_WebServer`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_WebServer` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `description`,
 1 AS `org_id`,
 1 AS `organization_name`,
 1 AS `business_criticity`,
 1 AS `move2production`,
 1 AS `system_id`,
 1 AS `system_name`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `softwarelicence_id`,
 1 AS `softwarelicence_name`,
 1 AS `path`,
 1 AS `status`,
 1 AS `finalclass`,
 1 AS `friendlyname`,
 1 AS `org_id_friendlyname`,
 1 AS `system_id_friendlyname`,
 1 AS `system_id_finalclass_recall`,
 1 AS `software_id_friendlyname`,
 1 AS `softwarelicence_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_WorkOrder`
--

DROP TABLE IF EXISTS `view_WorkOrder`;
/*!50001 DROP VIEW IF EXISTS `view_WorkOrder`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_WorkOrder` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `status`,
 1 AS `description`,
 1 AS `ticket_id`,
 1 AS `ticket_ref`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `agent_id`,
 1 AS `agent_email`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `log`,
 1 AS `log_index`,
 1 AS `friendlyname`,
 1 AS `ticket_id_friendlyname`,
 1 AS `ticket_id_finalclass_recall`,
 1 AS `team_id_friendlyname`,
 1 AS `agent_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkApplicationSolutionToBusinessProcess`
--

DROP TABLE IF EXISTS `view_lnkApplicationSolutionToBusinessProcess`;
/*!50001 DROP VIEW IF EXISTS `view_lnkApplicationSolutionToBusinessProcess`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkApplicationSolutionToBusinessProcess` AS SELECT 
 1 AS `id`,
 1 AS `businessprocess_id`,
 1 AS `businessprocess_name`,
 1 AS `applicationsolution_id`,
 1 AS `applicationsolution_name`,
 1 AS `friendlyname`,
 1 AS `businessprocess_id_friendlyname`,
 1 AS `applicationsolution_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkApplicationSolutionToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkApplicationSolutionToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkApplicationSolutionToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkApplicationSolutionToFunctionalCI` AS SELECT 
 1 AS `id`,
 1 AS `applicationsolution_id`,
 1 AS `applicationsolution_name`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `friendlyname`,
 1 AS `applicationsolution_id_friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkConnectableCIToNetworkDevice`
--

DROP TABLE IF EXISTS `view_lnkConnectableCIToNetworkDevice`;
/*!50001 DROP VIEW IF EXISTS `view_lnkConnectableCIToNetworkDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkConnectableCIToNetworkDevice` AS SELECT 
 1 AS `id`,
 1 AS `networkdevice_id`,
 1 AS `networkdevice_name`,
 1 AS `connectableci_id`,
 1 AS `connectableci_name`,
 1 AS `network_port`,
 1 AS `device_port`,
 1 AS `connection_type`,
 1 AS `friendlyname`,
 1 AS `networkdevice_id_friendlyname`,
 1 AS `connectableci_id_friendlyname`,
 1 AS `connectableci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkContactToContract`
--

DROP TABLE IF EXISTS `view_lnkContactToContract`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkContactToContract` AS SELECT 
 1 AS `id`,
 1 AS `contract_id`,
 1 AS `contract_name`,
 1 AS `contact_id`,
 1 AS `contact_name`,
 1 AS `friendlyname`,
 1 AS `contract_id_friendlyname`,
 1 AS `contract_id_finalclass_recall`,
 1 AS `contact_id_friendlyname`,
 1 AS `contact_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkContactToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkContactToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkContactToFunctionalCI` AS SELECT 
 1 AS `id`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `contact_id`,
 1 AS `contact_name`,
 1 AS `friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`,
 1 AS `contact_id_friendlyname`,
 1 AS `contact_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkContactToService`
--

DROP TABLE IF EXISTS `view_lnkContactToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkContactToService` AS SELECT 
 1 AS `id`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `contact_id`,
 1 AS `contact_name`,
 1 AS `friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `contact_id_friendlyname`,
 1 AS `contact_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkContactToTicket`
--

DROP TABLE IF EXISTS `view_lnkContactToTicket`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContactToTicket`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkContactToTicket` AS SELECT 
 1 AS `id`,
 1 AS `ticket_id`,
 1 AS `ticket_ref`,
 1 AS `contact_id`,
 1 AS `contact_email`,
 1 AS `role`,
 1 AS `friendlyname`,
 1 AS `ticket_id_friendlyname`,
 1 AS `ticket_id_finalclass_recall`,
 1 AS `contact_id_friendlyname`,
 1 AS `contact_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkContractToDocument`
--

DROP TABLE IF EXISTS `view_lnkContractToDocument`;
/*!50001 DROP VIEW IF EXISTS `view_lnkContractToDocument`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkContractToDocument` AS SELECT 
 1 AS `id`,
 1 AS `contract_id`,
 1 AS `contract_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `friendlyname`,
 1 AS `contract_id_friendlyname`,
 1 AS `contract_id_finalclass_recall`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkCustomerContractToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkCustomerContractToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkCustomerContractToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkCustomerContractToFunctionalCI` AS SELECT 
 1 AS `id`,
 1 AS `customercontract_id`,
 1 AS `customercontract_name`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `friendlyname`,
 1 AS `customercontract_id_friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkCustomerContractToProviderContract`
--

DROP TABLE IF EXISTS `view_lnkCustomerContractToProviderContract`;
/*!50001 DROP VIEW IF EXISTS `view_lnkCustomerContractToProviderContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkCustomerContractToProviderContract` AS SELECT 
 1 AS `id`,
 1 AS `customercontract_id`,
 1 AS `customercontract_name`,
 1 AS `providercontract_id`,
 1 AS `providercontract_name`,
 1 AS `friendlyname`,
 1 AS `customercontract_id_friendlyname`,
 1 AS `providercontract_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkCustomerContractToService`
--

DROP TABLE IF EXISTS `view_lnkCustomerContractToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkCustomerContractToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkCustomerContractToService` AS SELECT 
 1 AS `id`,
 1 AS `customercontract_id`,
 1 AS `customercontract_name`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `sla_id`,
 1 AS `sla_name`,
 1 AS `friendlyname`,
 1 AS `customercontract_id_friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `sla_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkDeliveryModelToContact`
--

DROP TABLE IF EXISTS `view_lnkDeliveryModelToContact`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDeliveryModelToContact`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDeliveryModelToContact` AS SELECT 
 1 AS `id`,
 1 AS `deliverymodel_id`,
 1 AS `deliverymodel_name`,
 1 AS `contact_id`,
 1 AS `contact_name`,
 1 AS `role_id`,
 1 AS `role_name`,
 1 AS `friendlyname`,
 1 AS `deliverymodel_id_friendlyname`,
 1 AS `contact_id_friendlyname`,
 1 AS `contact_id_finalclass_recall`,
 1 AS `role_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkDocumentToError`
--

DROP TABLE IF EXISTS `view_lnkDocumentToError`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToError`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDocumentToError` AS SELECT 
 1 AS `id`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `error_id`,
 1 AS `error_name`,
 1 AS `link_type`,
 1 AS `friendlyname`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`,
 1 AS `error_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkDocumentToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkDocumentToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDocumentToFunctionalCI` AS SELECT 
 1 AS `id`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkDocumentToLicence`
--

DROP TABLE IF EXISTS `view_lnkDocumentToLicence`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToLicence`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDocumentToLicence` AS SELECT 
 1 AS `id`,
 1 AS `licence_id`,
 1 AS `licence_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `friendlyname`,
 1 AS `licence_id_friendlyname`,
 1 AS `licence_id_finalclass_recall`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkDocumentToPatch`
--

DROP TABLE IF EXISTS `view_lnkDocumentToPatch`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToPatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDocumentToPatch` AS SELECT 
 1 AS `id`,
 1 AS `patch_id`,
 1 AS `patch_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `friendlyname`,
 1 AS `patch_id_friendlyname`,
 1 AS `patch_id_finalclass_recall`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkDocumentToService`
--

DROP TABLE IF EXISTS `view_lnkDocumentToService`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToService`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDocumentToService` AS SELECT 
 1 AS `id`,
 1 AS `service_id`,
 1 AS `service_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `friendlyname`,
 1 AS `service_id_friendlyname`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkDocumentToSoftware`
--

DROP TABLE IF EXISTS `view_lnkDocumentToSoftware`;
/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToSoftware`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkDocumentToSoftware` AS SELECT 
 1 AS `id`,
 1 AS `software_id`,
 1 AS `software_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `friendlyname`,
 1 AS `software_id_friendlyname`,
 1 AS `document_id_friendlyname`,
 1 AS `document_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkErrorToFunctionalCI`
--

DROP TABLE IF EXISTS `view_lnkErrorToFunctionalCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkErrorToFunctionalCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkErrorToFunctionalCI` AS SELECT 
 1 AS `id`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `error_id`,
 1 AS `error_name`,
 1 AS `reason`,
 1 AS `friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`,
 1 AS `error_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkFunctionalCIToOSPatch`
--

DROP TABLE IF EXISTS `view_lnkFunctionalCIToOSPatch`;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToOSPatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkFunctionalCIToOSPatch` AS SELECT 
 1 AS `id`,
 1 AS `ospatch_id`,
 1 AS `ospatch_name`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `friendlyname`,
 1 AS `ospatch_id_friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkFunctionalCIToProviderContract`
--

DROP TABLE IF EXISTS `view_lnkFunctionalCIToProviderContract`;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToProviderContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkFunctionalCIToProviderContract` AS SELECT 
 1 AS `id`,
 1 AS `providercontract_id`,
 1 AS `providercontract_name`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `friendlyname`,
 1 AS `providercontract_id_friendlyname`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkFunctionalCIToTicket`
--

DROP TABLE IF EXISTS `view_lnkFunctionalCIToTicket`;
/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToTicket`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkFunctionalCIToTicket` AS SELECT 
 1 AS `id`,
 1 AS `ticket_id`,
 1 AS `ticket_ref`,
 1 AS `ticket_title`,
 1 AS `functionalci_id`,
 1 AS `functionalci_name`,
 1 AS `impact`,
 1 AS `friendlyname`,
 1 AS `ticket_id_friendlyname`,
 1 AS `ticket_id_finalclass_recall`,
 1 AS `functionalci_id_friendlyname`,
 1 AS `functionalci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkGroupToCI`
--

DROP TABLE IF EXISTS `view_lnkGroupToCI`;
/*!50001 DROP VIEW IF EXISTS `view_lnkGroupToCI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkGroupToCI` AS SELECT 
 1 AS `id`,
 1 AS `group_id`,
 1 AS `group_name`,
 1 AS `ci_id`,
 1 AS `ci_name`,
 1 AS `reason`,
 1 AS `friendlyname`,
 1 AS `group_id_friendlyname`,
 1 AS `ci_id_friendlyname`,
 1 AS `ci_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkPersonToTeam`
--

DROP TABLE IF EXISTS `view_lnkPersonToTeam`;
/*!50001 DROP VIEW IF EXISTS `view_lnkPersonToTeam`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkPersonToTeam` AS SELECT 
 1 AS `id`,
 1 AS `team_id`,
 1 AS `team_name`,
 1 AS `person_id`,
 1 AS `person_name`,
 1 AS `role_id`,
 1 AS `role_name`,
 1 AS `friendlyname`,
 1 AS `team_id_friendlyname`,
 1 AS `person_id_friendlyname`,
 1 AS `role_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkPhysicalInterfaceToVLAN`
--

DROP TABLE IF EXISTS `view_lnkPhysicalInterfaceToVLAN`;
/*!50001 DROP VIEW IF EXISTS `view_lnkPhysicalInterfaceToVLAN`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkPhysicalInterfaceToVLAN` AS SELECT 
 1 AS `id`,
 1 AS `physicalinterface_id`,
 1 AS `physicalinterface_name`,
 1 AS `physicalinterface_device_id`,
 1 AS `physicalinterface_device_name`,
 1 AS `vlan_id`,
 1 AS `vlan_tag`,
 1 AS `friendlyname`,
 1 AS `physicalinterface_id_friendlyname`,
 1 AS `physicalinterface_device_id_friendlyname`,
 1 AS `vlan_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkSLAToSLT`
--

DROP TABLE IF EXISTS `view_lnkSLAToSLT`;
/*!50001 DROP VIEW IF EXISTS `view_lnkSLAToSLT`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkSLAToSLT` AS SELECT 
 1 AS `id`,
 1 AS `sla_id`,
 1 AS `sla_name`,
 1 AS `slt_id`,
 1 AS `slt_name`,
 1 AS `slt_metric`,
 1 AS `slt_request_type`,
 1 AS `slt_ticket_priority`,
 1 AS `slt_value`,
 1 AS `slt_value_unit`,
 1 AS `friendlyname`,
 1 AS `sla_id_friendlyname`,
 1 AS `slt_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkSanToDatacenterDevice`
--

DROP TABLE IF EXISTS `view_lnkSanToDatacenterDevice`;
/*!50001 DROP VIEW IF EXISTS `view_lnkSanToDatacenterDevice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkSanToDatacenterDevice` AS SELECT 
 1 AS `id`,
 1 AS `san_id`,
 1 AS `san_name`,
 1 AS `datacenterdevice_id`,
 1 AS `datacenterdevice_name`,
 1 AS `san_port`,
 1 AS `datacenterdevice_port`,
 1 AS `friendlyname`,
 1 AS `san_id_friendlyname`,
 1 AS `datacenterdevice_id_friendlyname`,
 1 AS `datacenterdevice_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkServerToVolume`
--

DROP TABLE IF EXISTS `view_lnkServerToVolume`;
/*!50001 DROP VIEW IF EXISTS `view_lnkServerToVolume`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkServerToVolume` AS SELECT 
 1 AS `id`,
 1 AS `volume_id`,
 1 AS `volume_name`,
 1 AS `server_id`,
 1 AS `server_name`,
 1 AS `size_used`,
 1 AS `friendlyname`,
 1 AS `volume_id_friendlyname`,
 1 AS `server_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkSoftwareInstanceToSoftwarePatch`
--

DROP TABLE IF EXISTS `view_lnkSoftwareInstanceToSoftwarePatch`;
/*!50001 DROP VIEW IF EXISTS `view_lnkSoftwareInstanceToSoftwarePatch`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkSoftwareInstanceToSoftwarePatch` AS SELECT 
 1 AS `id`,
 1 AS `softwarepatch_id`,
 1 AS `softwarepatch_name`,
 1 AS `softwareinstance_id`,
 1 AS `softwareinstance_name`,
 1 AS `friendlyname`,
 1 AS `softwarepatch_id_friendlyname`,
 1 AS `softwareinstance_id_friendlyname`,
 1 AS `softwareinstance_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkSubnetToVLAN`
--

DROP TABLE IF EXISTS `view_lnkSubnetToVLAN`;
/*!50001 DROP VIEW IF EXISTS `view_lnkSubnetToVLAN`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkSubnetToVLAN` AS SELECT 
 1 AS `id`,
 1 AS `subnet_id`,
 1 AS `subnet_ip`,
 1 AS `subnet_name`,
 1 AS `vlan_id`,
 1 AS `vlan_tag`,
 1 AS `friendlyname`,
 1 AS `subnet_id_friendlyname`,
 1 AS `vlan_id_friendlyname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkTriggerAction`
--

DROP TABLE IF EXISTS `view_lnkTriggerAction`;
/*!50001 DROP VIEW IF EXISTS `view_lnkTriggerAction`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkTriggerAction` AS SELECT 
 1 AS `id`,
 1 AS `action_id`,
 1 AS `action_name`,
 1 AS `trigger_id`,
 1 AS `trigger_name`,
 1 AS `order`,
 1 AS `friendlyname`,
 1 AS `action_id_friendlyname`,
 1 AS `action_id_finalclass_recall`,
 1 AS `trigger_id_friendlyname`,
 1 AS `trigger_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_lnkVirtualDeviceToVolume`
--

DROP TABLE IF EXISTS `view_lnkVirtualDeviceToVolume`;
/*!50001 DROP VIEW IF EXISTS `view_lnkVirtualDeviceToVolume`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_lnkVirtualDeviceToVolume` AS SELECT 
 1 AS `id`,
 1 AS `volume_id`,
 1 AS `volume_name`,
 1 AS `virtualdevice_id`,
 1 AS `virtualdevice_name`,
 1 AS `size_used`,
 1 AS `friendlyname`,
 1 AS `volume_id_friendlyname`,
 1 AS `virtualdevice_id_friendlyname`,
 1 AS `virtualdevice_id_finalclass_recall`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `virtualdevice`
--

DROP TABLE IF EXISTS `virtualdevice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtualdevice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('implementation','obsolete','production','stock') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualdevice`
--

LOCK TABLES `virtualdevice` WRITE;
/*!40000 ALTER TABLE `virtualdevice` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtualdevice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtualhost`
--

DROP TABLE IF EXISTS `virtualhost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtualhost` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualhost`
--

LOCK TABLES `virtualhost` WRITE;
/*!40000 ALTER TABLE `virtualhost` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtualhost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtualmachine`
--

DROP TABLE IF EXISTS `virtualmachine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtualmachine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `virtualhost_id` int(11) NOT NULL,
  `osfamily_id` int(11) DEFAULT NULL,
  `osversion_id` int(11) DEFAULT NULL,
  `oslicence_id` int(11) DEFAULT NULL,
  `cpu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `managementip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `virtualhost_id` (`virtualhost_id`),
  KEY `osfamily_id` (`osfamily_id`),
  KEY `osversion_id` (`osversion_id`),
  KEY `oslicence_id` (`oslicence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtualmachine`
--

LOCK TABLES `virtualmachine` WRITE;
/*!40000 ALTER TABLE `virtualmachine` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtualmachine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vlan`
--

DROP TABLE IF EXISTS `vlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vlan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vlan_tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `org_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vlan`
--

LOCK TABLES `vlan` WRITE;
/*!40000 ALTER TABLE `vlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `vlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webapplication`
--

DROP TABLE IF EXISTS `webapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webapplication` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `webserver_id` int(11) NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `webserver_id` (`webserver_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webapplication`
--

LOCK TABLES `webapplication` WRITE;
/*!40000 ALTER TABLE `webapplication` DISABLE KEYS */;
/*!40000 ALTER TABLE `webapplication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webserver`
--

DROP TABLE IF EXISTS `webserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webserver` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webserver`
--

LOCK TABLES `webserver` WRITE;
/*!40000 ALTER TABLE `webserver` DISABLE KEYS */;
/*!40000 ALTER TABLE `webserver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workorder`
--

DROP TABLE IF EXISTS `workorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('closed','open') COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `log` longtext COLLATE utf8_unicode_ci,
  `log_index` blob,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `team_id` (`team_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workorder`
--

LOCK TABLES `workorder` WRITE;
/*!40000 ALTER TABLE `workorder` DISABLE KEYS */;
/*!40000 ALTER TABLE `workorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `view_ActionEmail`
--

/*!50001 DROP VIEW IF EXISTS `view_ActionEmail`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ActionEmail` AS select distinct `_priv_action_email`.`id` AS `id`,`_priv_action`.`name` AS `name`,`_priv_action`.`description` AS `description`,`_priv_action`.`status` AS `status`,`_priv_action_email`.`test_recipient` AS `test_recipient`,`_priv_action_email`.`from` AS `from`,`_priv_action_email`.`reply_to` AS `reply_to`,`_priv_action_email`.`to` AS `to`,`_priv_action_email`.`cc` AS `cc`,`_priv_action_email`.`bcc` AS `bcc`,`_priv_action_email`.`subject` AS `subject`,`_priv_action_email`.`body` AS `body`,`_priv_action_email`.`importance` AS `importance`,`_priv_action`.`realclass` AS `finalclass`,cast(concat(coalesce(`_priv_action`.`name`,'')) as char charset utf8) AS `friendlyname` from (`priv_action_email` `_priv_action_email` join `priv_action` `_priv_action` on((`_priv_action_email`.`id` = `_priv_action`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ApplicationSolution`
--

/*!50001 DROP VIEW IF EXISTS `view_ApplicationSolution`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ApplicationSolution` AS select distinct `_applicationsolution`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_applicationsolution`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`applicationsolution` `_applicationsolution` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_applicationsolution`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ApprovedChange`
--

/*!50001 DROP VIEW IF EXISTS `view_ApprovedChange`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ApprovedChange` AS select distinct `_change_approved`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_change`.`status` AS `status`,`_change`.`reason` AS `reason`,`_change`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`email` AS `requestor_email`,`_change`.`creation_date` AS `creation_date`,`_change`.`impact` AS `impact`,`_change`.`supervisor_group_id` AS `supervisor_group_id`,`Team_supervisor_group_id_contact`.`name` AS `supervisor_group_name`,`_change`.`supervisor_id` AS `supervisor_id`,`Person_supervisor_id_contact`.`email` AS `supervisor_email`,`_change`.`manager_group_id` AS `manager_group_id`,`Team_manager_group_id_contact`.`name` AS `manager_group_name`,`_change`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`email` AS `manager_email`,`_change`.`outage` AS `outage`,`_change`.`fallback` AS `fallback`,`_change`.`parent_id` AS `parent_id`,`Change_parent_id_ticket`.`ref` AS `parent_name`,`_change_approved`.`approval_date` AS `approval_date`,`_change_approved`.`approval_comment` AS `approval_comment`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Team_supervisor_group_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_group_id_friendlyname`,cast(concat(coalesce(`Person_supervisor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_supervisor_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_id_friendlyname`,cast(concat(coalesce(`Team_manager_group_id_contact`.`name`,'')) as char charset utf8) AS `manager_group_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname`,cast(concat(coalesce(`Change_parent_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_id_friendlyname`,`Change_parent_id_ticket`.`finalclass` AS `parent_id_finalclass_recall` from ((`change_approved` `_change_approved` join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_change_approved`.`id` = `_ticket`.`id`))) join ((((((`change` `_change` left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_change`.`requestor_id` = `Person_requestor_id_person`.`id`))) left join (`team` `Team_supervisor_group_id_team` join `contact` `Team_supervisor_group_id_contact` on((`Team_supervisor_group_id_team`.`id` = `Team_supervisor_group_id_contact`.`id`))) on((`_change`.`supervisor_group_id` = `Team_supervisor_group_id_team`.`id`))) left join (`person` `Person_supervisor_id_person` join `contact` `Person_supervisor_id_contact` on((`Person_supervisor_id_person`.`id` = `Person_supervisor_id_contact`.`id`))) on((`_change`.`supervisor_id` = `Person_supervisor_id_person`.`id`))) left join (`team` `Team_manager_group_id_team` join `contact` `Team_manager_group_id_contact` on((`Team_manager_group_id_team`.`id` = `Team_manager_group_id_contact`.`id`))) on((`_change`.`manager_group_id` = `Team_manager_group_id_team`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_change`.`manager_id` = `Person_manager_id_person`.`id`))) left join (`change` `Change_parent_id_change` join `ticket` `Change_parent_id_ticket` on((`Change_parent_id_change`.`id` = `Change_parent_id_ticket`.`id`))) on((`_change`.`parent_id` = `Change_parent_id_change`.`id`))) on((`_change_approved`.`id` = `_change`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Attachment`
--

/*!50001 DROP VIEW IF EXISTS `view_Attachment`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Attachment` AS select distinct `_attachment`.`id` AS `id`,`_attachment`.`expire` AS `expire`,`_attachment`.`temp_id` AS `temp_id`,`_attachment`.`item_class` AS `item_class`,`_attachment`.`item_id` AS `item_id`,`_attachment`.`item_org_id` AS `item_org_id`,`_attachment`.`contents_mimetype` AS `contents`,`_attachment`.`contents_data` AS `contents_data`,`_attachment`.`contents_filename` AS `contents_filename`,cast(concat(coalesce(`_attachment`.`item_class`,''),coalesce(' ',''),coalesce(`_attachment`.`temp_id`,'')) as char charset utf8) AS `friendlyname` from `attachment` `_attachment` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Brand`
--

/*!50001 DROP VIEW IF EXISTS `view_Brand`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Brand` AS select distinct `_brand`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`brand` `_brand` join `typology` `_typology` on((`_brand`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_BusinessProcess`
--

/*!50001 DROP VIEW IF EXISTS `view_BusinessProcess`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_BusinessProcess` AS select distinct `_businessprocess`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_businessprocess`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`businessprocess` `_businessprocess` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_businessprocess`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Change`
--

/*!50001 DROP VIEW IF EXISTS `view_Change`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Change` AS select distinct `_change`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_change`.`status` AS `status`,`_change`.`reason` AS `reason`,`_change`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`email` AS `requestor_email`,`_change`.`creation_date` AS `creation_date`,`_change`.`impact` AS `impact`,`_change`.`supervisor_group_id` AS `supervisor_group_id`,`Team_supervisor_group_id_contact`.`name` AS `supervisor_group_name`,`_change`.`supervisor_id` AS `supervisor_id`,`Person_supervisor_id_contact`.`email` AS `supervisor_email`,`_change`.`manager_group_id` AS `manager_group_id`,`Team_manager_group_id_contact`.`name` AS `manager_group_name`,`_change`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`email` AS `manager_email`,`_change`.`outage` AS `outage`,`_change`.`fallback` AS `fallback`,`_change`.`parent_id` AS `parent_id`,`Change_parent_id_ticket`.`ref` AS `parent_name`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Team_supervisor_group_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_group_id_friendlyname`,cast(concat(coalesce(`Person_supervisor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_supervisor_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_id_friendlyname`,cast(concat(coalesce(`Team_manager_group_id_contact`.`name`,'')) as char charset utf8) AS `manager_group_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname`,cast(concat(coalesce(`Change_parent_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_id_friendlyname`,`Change_parent_id_ticket`.`finalclass` AS `parent_id_finalclass_recall` from (((((((`change` `_change` left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_change`.`requestor_id` = `Person_requestor_id_person`.`id`))) left join (`team` `Team_supervisor_group_id_team` join `contact` `Team_supervisor_group_id_contact` on((`Team_supervisor_group_id_team`.`id` = `Team_supervisor_group_id_contact`.`id`))) on((`_change`.`supervisor_group_id` = `Team_supervisor_group_id_team`.`id`))) left join (`person` `Person_supervisor_id_person` join `contact` `Person_supervisor_id_contact` on((`Person_supervisor_id_person`.`id` = `Person_supervisor_id_contact`.`id`))) on((`_change`.`supervisor_id` = `Person_supervisor_id_person`.`id`))) left join (`team` `Team_manager_group_id_team` join `contact` `Team_manager_group_id_contact` on((`Team_manager_group_id_team`.`id` = `Team_manager_group_id_contact`.`id`))) on((`_change`.`manager_group_id` = `Team_manager_group_id_team`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_change`.`manager_id` = `Person_manager_id_person`.`id`))) left join (`change` `Change_parent_id_change` join `ticket` `Change_parent_id_ticket` on((`Change_parent_id_change`.`id` = `Change_parent_id_ticket`.`id`))) on((`_change`.`parent_id` = `Change_parent_id_change`.`id`))) join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_change`.`id` = `_ticket`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ConnectableCI`
--

/*!50001 DROP VIEW IF EXISTS `view_ConnectableCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ConnectableCI` AS select distinct `_connectableci`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`connectableci` `_connectableci` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_connectableci`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_connectableci`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Contact`
--

/*!50001 DROP VIEW IF EXISTS `view_Contact`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Contact` AS select distinct `_contact`.`id` AS `id`,`_contact`.`name` AS `name`,`_contact`.`status` AS `status`,`_contact`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_contact`.`email` AS `email`,`_contact`.`phone` AS `phone`,`_contact`.`notify` AS `notify`,`_contact`.`function` AS `function`,`_contact`.`finalclass` AS `finalclass`,if((`_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`_contact`.`name`,'')) as char charset utf8)) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`contact` `_contact` join `organization` `Organization_org_id_organization` on((`_contact`.`org_id` = `Organization_org_id_organization`.`id`))) left join `person` `_fn_Person_person` on((`_contact`.`id` = `_fn_Person_person`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ContactType`
--

/*!50001 DROP VIEW IF EXISTS `view_ContactType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ContactType` AS select distinct `_contacttype`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`contacttype` `_contacttype` join `typology` `_typology` on((`_contacttype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Contract`
--

/*!50001 DROP VIEW IF EXISTS `view_Contract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Contract` AS select distinct `_contract`.`id` AS `id`,`_contract`.`name` AS `name`,`_contract`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_contract`.`description` AS `description`,`_contract`.`start_date` AS `start_date`,`_contract`.`end_date` AS `end_date`,`_contract`.`cost` AS `cost`,`_contract`.`cost_currency` AS `cost_currency`,`_contract`.`contracttype_id` AS `contracttype_id`,`ContractType_contracttype_id_typology`.`name` AS `contracttype_name`,`_contract`.`billing_frequency` AS `billing_frequency`,`_contract`.`cost_unit` AS `cost_unit`,`_contract`.`provider_id` AS `provider_id`,`Organization_provider_id_organization`.`name` AS `provider_name`,`_contract`.`status` AS `status`,`_contract`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_contract`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`ContractType_contracttype_id_typology`.`name`,'')) as char charset utf8) AS `contracttype_id_friendlyname`,cast(concat(coalesce(`Organization_provider_id_organization`.`name`,'')) as char charset utf8) AS `provider_id_friendlyname` from (((`contract` `_contract` join `organization` `Organization_org_id_organization` on((`_contract`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`contracttype` `ContractType_contracttype_id_contracttype` join `typology` `ContractType_contracttype_id_typology` on((`ContractType_contracttype_id_contracttype`.`id` = `ContractType_contracttype_id_typology`.`id`))) on((`_contract`.`contracttype_id` = `ContractType_contracttype_id_contracttype`.`id`))) join `organization` `Organization_provider_id_organization` on((`_contract`.`provider_id` = `Organization_provider_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ContractType`
--

/*!50001 DROP VIEW IF EXISTS `view_ContractType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ContractType` AS select distinct `_contracttype`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`contracttype` `_contracttype` join `typology` `_typology` on((`_contracttype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_CustomerContract`
--

/*!50001 DROP VIEW IF EXISTS `view_CustomerContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_CustomerContract` AS select distinct `_customercontract`.`id` AS `id`,`_contract`.`name` AS `name`,`_contract`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_contract`.`description` AS `description`,`_contract`.`start_date` AS `start_date`,`_contract`.`end_date` AS `end_date`,`_contract`.`cost` AS `cost`,`_contract`.`cost_currency` AS `cost_currency`,`_contract`.`contracttype_id` AS `contracttype_id`,`ContractType_contracttype_id_typology`.`name` AS `contracttype_name`,`_contract`.`billing_frequency` AS `billing_frequency`,`_contract`.`cost_unit` AS `cost_unit`,`_contract`.`provider_id` AS `provider_id`,`Organization_provider_id_organization`.`name` AS `provider_name`,`_contract`.`status` AS `status`,`_contract`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_contract`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`ContractType_contracttype_id_typology`.`name`,'')) as char charset utf8) AS `contracttype_id_friendlyname`,cast(concat(coalesce(`Organization_provider_id_organization`.`name`,'')) as char charset utf8) AS `provider_id_friendlyname` from (`customercontract` `_customercontract` join (((`contract` `_contract` join `organization` `Organization_org_id_organization` on((`_contract`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`contracttype` `ContractType_contracttype_id_contracttype` join `typology` `ContractType_contracttype_id_typology` on((`ContractType_contracttype_id_contracttype`.`id` = `ContractType_contracttype_id_typology`.`id`))) on((`_contract`.`contracttype_id` = `ContractType_contracttype_id_contracttype`.`id`))) join `organization` `Organization_provider_id_organization` on((`_contract`.`provider_id` = `Organization_provider_id_organization`.`id`))) on((`_customercontract`.`id` = `_contract`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DBServer`
--

/*!50001 DROP VIEW IF EXISTS `view_DBServer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DBServer` AS select distinct `_dbserver`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`dbserver` `_dbserver` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_dbserver`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_dbserver`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DatabaseSchema`
--

/*!50001 DROP VIEW IF EXISTS `view_DatabaseSchema`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DatabaseSchema` AS select distinct `_databaseschema`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_databaseschema`.`dbserver_id` AS `dbserver_id`,`DBServer_dbserver_id_functionalci`.`name` AS `dbserver_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DBServer_dbserver_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `dbserver_id_friendlyname` from ((`databaseschema` `_databaseschema` join ((`dbserver` `DBServer_dbserver_id_dbserver` join `functionalci` `DBServer_dbserver_id_functionalci` on((`DBServer_dbserver_id_dbserver`.`id` = `DBServer_dbserver_id_functionalci`.`id`))) join (`softwareinstance` `DBServer_dbserver_id_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`DBServer_dbserver_id_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`DBServer_dbserver_id_dbserver`.`id` = `DBServer_dbserver_id_softwareinstance`.`id`))) on((`_databaseschema`.`dbserver_id` = `DBServer_dbserver_id_dbserver`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_databaseschema`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DatacenterDevice`
--

/*!50001 DROP VIEW IF EXISTS `view_DatacenterDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DatacenterDevice` AS select distinct `_datacenterdevice`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall` from ((((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_datacenterdevice`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_datacenterdevice`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DeliveryModel`
--

/*!50001 DROP VIEW IF EXISTS `view_DeliveryModel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DeliveryModel` AS select distinct `_deliverymodel`.`id` AS `id`,`_deliverymodel`.`name` AS `name`,`_deliverymodel`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_deliverymodel`.`description` AS `description`,cast(concat(coalesce(`_deliverymodel`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`deliverymodel` `_deliverymodel` join `organization` `Organization_org_id_organization` on((`_deliverymodel`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Document`
--

/*!50001 DROP VIEW IF EXISTS `view_Document`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Document` AS select distinct `_document`.`id` AS `id`,`_document`.`name` AS `name`,`_document`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_document`.`documenttype_id` AS `documenttype_id`,`DocumentType_documenttype_id_typology`.`name` AS `documenttype_name`,`_document`.`version` AS `version`,`_document`.`description` AS `description`,`_document`.`status` AS `status`,`_document`.`finalclass` AS `finalclass`,if((`_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`_document`.`name`,'')) as char charset utf8)) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DocumentType_documenttype_id_typology`.`name`,'')) as char charset utf8) AS `documenttype_id_friendlyname` from ((`document` `_document` join `organization` `Organization_org_id_organization` on((`_document`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`documenttype` `DocumentType_documenttype_id_documenttype` join `typology` `DocumentType_documenttype_id_typology` on((`DocumentType_documenttype_id_documenttype`.`id` = `DocumentType_documenttype_id_typology`.`id`))) on((`_document`.`documenttype_id` = `DocumentType_documenttype_id_documenttype`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DocumentFile`
--

/*!50001 DROP VIEW IF EXISTS `view_DocumentFile`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DocumentFile` AS select distinct `_documentfile`.`id` AS `id`,`_document`.`name` AS `name`,`_document`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_document`.`documenttype_id` AS `documenttype_id`,`DocumentType_documenttype_id_typology`.`name` AS `documenttype_name`,`_document`.`version` AS `version`,`_document`.`description` AS `description`,`_document`.`status` AS `status`,`_documentfile`.`file_mimetype` AS `file`,`_documentfile`.`file_data` AS `file_data`,`_documentfile`.`file_filename` AS `file_filename`,`_document`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_document`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DocumentType_documenttype_id_typology`.`name`,'')) as char charset utf8) AS `documenttype_id_friendlyname` from (`documentfile` `_documentfile` join ((`document` `_document` join `organization` `Organization_org_id_organization` on((`_document`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`documenttype` `DocumentType_documenttype_id_documenttype` join `typology` `DocumentType_documenttype_id_typology` on((`DocumentType_documenttype_id_documenttype`.`id` = `DocumentType_documenttype_id_typology`.`id`))) on((`_document`.`documenttype_id` = `DocumentType_documenttype_id_documenttype`.`id`))) on((`_documentfile`.`id` = `_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DocumentNote`
--

/*!50001 DROP VIEW IF EXISTS `view_DocumentNote`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DocumentNote` AS select distinct `_documentnote`.`id` AS `id`,`_document`.`name` AS `name`,`_document`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_document`.`documenttype_id` AS `documenttype_id`,`DocumentType_documenttype_id_typology`.`name` AS `documenttype_name`,`_document`.`version` AS `version`,`_document`.`description` AS `description`,`_document`.`status` AS `status`,`_documentnote`.`text` AS `text`,`_document`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_document`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DocumentType_documenttype_id_typology`.`name`,'')) as char charset utf8) AS `documenttype_id_friendlyname` from (`documentnote` `_documentnote` join ((`document` `_document` join `organization` `Organization_org_id_organization` on((`_document`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`documenttype` `DocumentType_documenttype_id_documenttype` join `typology` `DocumentType_documenttype_id_typology` on((`DocumentType_documenttype_id_documenttype`.`id` = `DocumentType_documenttype_id_typology`.`id`))) on((`_document`.`documenttype_id` = `DocumentType_documenttype_id_documenttype`.`id`))) on((`_documentnote`.`id` = `_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DocumentType`
--

/*!50001 DROP VIEW IF EXISTS `view_DocumentType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DocumentType` AS select distinct `_documenttype`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`documenttype` `_documenttype` join `typology` `_typology` on((`_documenttype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_DocumentWeb`
--

/*!50001 DROP VIEW IF EXISTS `view_DocumentWeb`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_DocumentWeb` AS select distinct `_documentweb`.`id` AS `id`,`_document`.`name` AS `name`,`_document`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_document`.`documenttype_id` AS `documenttype_id`,`DocumentType_documenttype_id_typology`.`name` AS `documenttype_name`,`_document`.`version` AS `version`,`_document`.`description` AS `description`,`_document`.`status` AS `status`,`_documentweb`.`url` AS `url`,`_document`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_document`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`DocumentType_documenttype_id_typology`.`name`,'')) as char charset utf8) AS `documenttype_id_friendlyname` from (`documentweb` `_documentweb` join ((`document` `_document` join `organization` `Organization_org_id_organization` on((`_document`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`documenttype` `DocumentType_documenttype_id_documenttype` join `typology` `DocumentType_documenttype_id_typology` on((`DocumentType_documenttype_id_documenttype`.`id` = `DocumentType_documenttype_id_typology`.`id`))) on((`_document`.`documenttype_id` = `DocumentType_documenttype_id_documenttype`.`id`))) on((`_documentweb`.`id` = `_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_EmergencyChange`
--

/*!50001 DROP VIEW IF EXISTS `view_EmergencyChange`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_EmergencyChange` AS select distinct `_change_emergency`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_change`.`status` AS `status`,`_change`.`reason` AS `reason`,`_change`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`email` AS `requestor_email`,`_change`.`creation_date` AS `creation_date`,`_change`.`impact` AS `impact`,`_change`.`supervisor_group_id` AS `supervisor_group_id`,`Team_supervisor_group_id_contact`.`name` AS `supervisor_group_name`,`_change`.`supervisor_id` AS `supervisor_id`,`Person_supervisor_id_contact`.`email` AS `supervisor_email`,`_change`.`manager_group_id` AS `manager_group_id`,`Team_manager_group_id_contact`.`name` AS `manager_group_name`,`_change`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`email` AS `manager_email`,`_change`.`outage` AS `outage`,`_change`.`fallback` AS `fallback`,`_change`.`parent_id` AS `parent_id`,`Change_parent_id_ticket`.`ref` AS `parent_name`,`_change_approved`.`approval_date` AS `approval_date`,`_change_approved`.`approval_comment` AS `approval_comment`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Team_supervisor_group_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_group_id_friendlyname`,cast(concat(coalesce(`Person_supervisor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_supervisor_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_id_friendlyname`,cast(concat(coalesce(`Team_manager_group_id_contact`.`name`,'')) as char charset utf8) AS `manager_group_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname`,cast(concat(coalesce(`Change_parent_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_id_friendlyname`,`Change_parent_id_ticket`.`finalclass` AS `parent_id_finalclass_recall` from (((`change_emergency` `_change_emergency` join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_change_emergency`.`id` = `_ticket`.`id`))) join ((((((`change` `_change` left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_change`.`requestor_id` = `Person_requestor_id_person`.`id`))) left join (`team` `Team_supervisor_group_id_team` join `contact` `Team_supervisor_group_id_contact` on((`Team_supervisor_group_id_team`.`id` = `Team_supervisor_group_id_contact`.`id`))) on((`_change`.`supervisor_group_id` = `Team_supervisor_group_id_team`.`id`))) left join (`person` `Person_supervisor_id_person` join `contact` `Person_supervisor_id_contact` on((`Person_supervisor_id_person`.`id` = `Person_supervisor_id_contact`.`id`))) on((`_change`.`supervisor_id` = `Person_supervisor_id_person`.`id`))) left join (`team` `Team_manager_group_id_team` join `contact` `Team_manager_group_id_contact` on((`Team_manager_group_id_team`.`id` = `Team_manager_group_id_contact`.`id`))) on((`_change`.`manager_group_id` = `Team_manager_group_id_team`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_change`.`manager_id` = `Person_manager_id_person`.`id`))) left join (`change` `Change_parent_id_change` join `ticket` `Change_parent_id_ticket` on((`Change_parent_id_change`.`id` = `Change_parent_id_ticket`.`id`))) on((`_change`.`parent_id` = `Change_parent_id_change`.`id`))) on((`_change_emergency`.`id` = `_change`.`id`))) join `change_approved` `_change_approved` on((`_change_emergency`.`id` = `_change_approved`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Enclosure`
--

/*!50001 DROP VIEW IF EXISTS `view_Enclosure`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Enclosure` AS select distinct `_enclosure`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_enclosure`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_enclosure`.`nb_u` AS `nb_u`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname` from (((`enclosure` `_enclosure` join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_enclosure`.`rack_id` = `Rack_rack_id_rack`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_enclosure`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_enclosure`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_FAQ`
--

/*!50001 DROP VIEW IF EXISTS `view_FAQ`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_FAQ` AS select distinct `_faq`.`id` AS `id`,`_faq`.`title` AS `title`,`_faq`.`summary` AS `summary`,`_faq`.`description` AS `description`,`_faq`.`category_id` AS `category_id`,`FAQCategory_category_id_faqcategory`.`nam` AS `category_name`,`_faq`.`error_code` AS `error_code`,`_faq`.`key_words` AS `key_words`,cast(concat(coalesce(`_faq`.`title`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`FAQCategory_category_id_faqcategory`.`nam`,'')) as char charset utf8) AS `category_id_friendlyname` from (`faq` `_faq` join `faqcategory` `FAQCategory_category_id_faqcategory` on((`_faq`.`category_id` = `FAQCategory_category_id_faqcategory`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_FAQCategory`
--

/*!50001 DROP VIEW IF EXISTS `view_FAQCategory`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_FAQCategory` AS select distinct `_faqcategory`.`id` AS `id`,`_faqcategory`.`nam` AS `name`,cast(concat(coalesce(`_faqcategory`.`nam`,'')) as char charset utf8) AS `friendlyname` from `faqcategory` `_faqcategory` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Farm`
--

/*!50001 DROP VIEW IF EXISTS `view_Farm`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Farm` AS select distinct `_farm`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`farm` `_farm` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_farm`.`id` = `_functionalci`.`id`))) join `virtualdevice` `_virtualdevice` on((`_farm`.`id` = `_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_FiberChannelInterface`
--

/*!50001 DROP VIEW IF EXISTS `view_FiberChannelInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_FiberChannelInterface` AS select distinct `_fiberchannelinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_fiberchannelinterface`.`speed` AS `speed`,`_fiberchannelinterface`.`topology` AS `topology`,`_fiberchannelinterface`.`wwn` AS `wwn`,`_fiberchannelinterface`.`datacenterdevice_id` AS `datacenterdevice_id`,`DatacenterDevice_datacenterdevice_id_functionalci`.`name` AS `datacenterdevice_name`,`_networkinterface`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `datacenterdevice_id_friendlyname`,`DatacenterDevice_datacenterdevice_id_functionalci`.`finalclass` AS `datacenterdevice_id_finalclass_recall` from ((`fiberchannelinterface` `_fiberchannelinterface` join (`datacenterdevice` `DatacenterDevice_datacenterdevice_id_datacenterdevice` join `functionalci` `DatacenterDevice_datacenterdevice_id_functionalci` on((`DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id` = `DatacenterDevice_datacenterdevice_id_functionalci`.`id`))) on((`_fiberchannelinterface`.`datacenterdevice_id` = `DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id`))) join `networkinterface` `_networkinterface` on((`_fiberchannelinterface`.`id` = `_networkinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_FunctionalCI`
--

/*!50001 DROP VIEW IF EXISTS `view_FunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_FunctionalCI` AS select distinct `_functionalci`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_functionalci`.`finalclass` AS `finalclass`,if((`_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8)) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`softwareinstance` `_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`_functionalci`.`id` = `_fn_SoftwareInstance_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Group`
--

/*!50001 DROP VIEW IF EXISTS `view_Group`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Group` AS select distinct `_group`.`id` AS `id`,`_group`.`name` AS `name`,`_group`.`status` AS `status`,`_group`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `owner_name`,`_group`.`description` AS `description`,`_group`.`type` AS `type`,`_group`.`parent_id` AS `parent_id`,`Group_parent_id_group`.`name` AS `parent_name`,cast(concat(coalesce(`_group`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Group_parent_id_group`.`name`,'')) as char charset utf8) AS `parent_id_friendlyname` from ((`group` `_group` join `organization` `Organization_org_id_organization` on((`_group`.`org_id` = `Organization_org_id_organization`.`id`))) left join `group` `Group_parent_id_group` on((`_group`.`parent_id` = `Group_parent_id_group`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Hypervisor`
--

/*!50001 DROP VIEW IF EXISTS `view_Hypervisor`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Hypervisor` AS select distinct `_hypervisor`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_hypervisor`.`farm_id` AS `farm_id`,`Farm_farm_id_functionalci`.`name` AS `farm_name`,`_hypervisor`.`server_id` AS `server_id`,`Server_server_id_functionalci`.`name` AS `server_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Farm_farm_id_functionalci`.`name`,'')) as char charset utf8) AS `farm_id_friendlyname`,cast(concat(coalesce(`Server_server_id_functionalci`.`name`,'')) as char charset utf8) AS `server_id_friendlyname` from ((((`hypervisor` `_hypervisor` left join (`farm` `Farm_farm_id_farm` join `functionalci` `Farm_farm_id_functionalci` on((`Farm_farm_id_farm`.`id` = `Farm_farm_id_functionalci`.`id`))) on((`_hypervisor`.`farm_id` = `Farm_farm_id_farm`.`id`))) left join (`server` `Server_server_id_server` join `functionalci` `Server_server_id_functionalci` on((`Server_server_id_server`.`id` = `Server_server_id_functionalci`.`id`))) on((`_hypervisor`.`server_id` = `Server_server_id_server`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_hypervisor`.`id` = `_functionalci`.`id`))) join `virtualdevice` `_virtualdevice` on((`_hypervisor`.`id` = `_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IOSVersion`
--

/*!50001 DROP VIEW IF EXISTS `view_IOSVersion`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IOSVersion` AS select distinct `_iosversion`.`id` AS `id`,`_typology`.`name` AS `name`,`_iosversion`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,''),coalesce(' ',''),coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname` from ((`iosversion` `_iosversion` join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_iosversion`.`brand_id` = `Brand_brand_id_brand`.`id`))) join `typology` `_typology` on((`_iosversion`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPInterface`
--

/*!50001 DROP VIEW IF EXISTS `view_IPInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPInterface` AS select distinct `_ipinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_ipinterface`.`ipaddress` AS `ipaddress`,`_ipinterface`.`macaddress` AS `macaddress`,`_ipinterface`.`comment` AS `comment`,`_ipinterface`.`ipgateway` AS `ipgateway`,`_ipinterface`.`ipmask` AS `ipmask`,`_ipinterface`.`speed` AS `speed`,`_networkinterface`.`finalclass` AS `finalclass`,if((`_networkinterface`.`finalclass` = 'IPInterface'),cast(concat(coalesce(`_networkinterface`.`name`,'')) as char charset utf8),if((`_networkinterface`.`finalclass` = 'LogicalInterface'),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8))) AS `friendlyname` from (((`ipinterface` `_ipinterface` join `networkinterface` `_networkinterface` on((`_ipinterface`.`id` = `_networkinterface`.`id`))) left join (`logicalinterface` `_fn_LogicalInterface_logicalinterface` join (`virtualmachine` `VirtualMachine_virtualmachine_id_virtualmachine` join `functionalci` `VirtualMachine_virtualmachine_id_functionalci` on((`VirtualMachine_virtualmachine_id_virtualmachine`.`id` = `VirtualMachine_virtualmachine_id_functionalci`.`id`))) on((`_fn_LogicalInterface_logicalinterface`.`virtualmachine_id` = `VirtualMachine_virtualmachine_id_virtualmachine`.`id`))) on((`_ipinterface`.`id` = `_fn_LogicalInterface_logicalinterface`.`id`))) left join (`physicalinterface` `_fn_PhysicalInterface_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`_fn_PhysicalInterface_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) on((`_ipinterface`.`id` = `_fn_PhysicalInterface_physicalinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_IPPhone`
--

/*!50001 DROP VIEW IF EXISTS `view_IPPhone`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_IPPhone` AS select distinct `_ipphone`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_telephonyci`.`phonenumber` AS `phonenumber`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from (((`ipphone` `_ipphone` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_ipphone`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_ipphone`.`id` = `_physicaldevice`.`id`))) join `telephonyci` `_telephonyci` on((`_ipphone`.`id` = `_telephonyci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Incident`
--

/*!50001 DROP VIEW IF EXISTS `view_Incident`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Incident` AS select distinct `_ticket_incident`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket_incident`.`status` AS `status`,`_ticket_incident`.`impact` AS `impact`,`_ticket_incident`.`priority` AS `priority`,`_ticket_incident`.`urgency` AS `urgency`,`_ticket_incident`.`origin` AS `origin`,`_ticket_incident`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_ticket_incident`.`servicesubcategory_id` AS `servicesubcategory_id`,`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name` AS `servicesubcategory_name`,`_ticket_incident`.`escalation_flag` AS `escalation_flag`,`_ticket_incident`.`escalation_reason` AS `escalation_reason`,`_ticket_incident`.`assignment_date` AS `assignment_date`,`_ticket_incident`.`resolution_date` AS `resolution_date`,`_ticket_incident`.`last_pending_date` AS `last_pending_date`,`_ticket_incident`.`cumulatedpending_timespent` AS `cumulatedpending`,`_ticket_incident`.`cumulatedpending_started` AS `cumulatedpending_started`,`_ticket_incident`.`cumulatedpending_laststart` AS `cumulatedpending_laststart`,`_ticket_incident`.`cumulatedpending_stopped` AS `cumulatedpending_stopped`,`_ticket_incident`.`tto_timespent` AS `tto`,`_ticket_incident`.`tto_started` AS `tto_started`,`_ticket_incident`.`tto_laststart` AS `tto_laststart`,`_ticket_incident`.`tto_stopped` AS `tto_stopped`,`_ticket_incident`.`tto_75_deadline` AS `tto_75_deadline`,`_ticket_incident`.`tto_75_passed` AS `tto_75_passed`,`_ticket_incident`.`tto_75_triggered` AS `tto_75_triggered`,`_ticket_incident`.`tto_75_overrun` AS `tto_75_overrun`,`_ticket_incident`.`tto_100_deadline` AS `tto_100_deadline`,`_ticket_incident`.`tto_100_passed` AS `tto_100_passed`,`_ticket_incident`.`tto_100_triggered` AS `tto_100_triggered`,`_ticket_incident`.`tto_100_overrun` AS `tto_100_overrun`,`_ticket_incident`.`ttr_timespent` AS `ttr`,`_ticket_incident`.`ttr_started` AS `ttr_started`,`_ticket_incident`.`ttr_laststart` AS `ttr_laststart`,`_ticket_incident`.`ttr_stopped` AS `ttr_stopped`,`_ticket_incident`.`ttr_75_deadline` AS `ttr_75_deadline`,`_ticket_incident`.`ttr_75_passed` AS `ttr_75_passed`,`_ticket_incident`.`ttr_75_triggered` AS `ttr_75_triggered`,`_ticket_incident`.`ttr_75_overrun` AS `ttr_75_overrun`,`_ticket_incident`.`ttr_100_deadline` AS `ttr_100_deadline`,`_ticket_incident`.`ttr_100_passed` AS `ttr_100_passed`,`_ticket_incident`.`ttr_100_triggered` AS `ttr_100_triggered`,`_ticket_incident`.`ttr_100_overrun` AS `ttr_100_overrun`,`_ticket_incident`.`tto_100_deadline` AS `tto_escalation_deadline`,`_ticket_incident`.`tto_100_passed` AS `sla_tto_passed`,`_ticket_incident`.`tto_100_overrun` AS `sla_tto_over`,`_ticket_incident`.`ttr_100_deadline` AS `ttr_escalation_deadline`,`_ticket_incident`.`ttr_100_passed` AS `sla_ttr_passed`,`_ticket_incident`.`ttr_100_overrun` AS `sla_ttr_over`,`_ticket_incident`.`time_spent` AS `time_spent`,`_ticket_incident`.`resolution_code` AS `resolution_code`,`_ticket_incident`.`solution` AS `solution`,`_ticket_incident`.`pending_reason` AS `pending_reason`,`_ticket_incident`.`parent_incident_id` AS `parent_incident_id`,`Incident_parent_incident_id_ticket`.`ref` AS `parent_incident_ref`,`_ticket_incident`.`parent_problem_id` AS `parent_problem_id`,`Problem_parent_problem_id_ticket`.`ref` AS `parent_problem_ref`,`_ticket_incident`.`parent_change_id` AS `parent_change_id`,`Change_parent_change_id_ticket`.`ref` AS `parent_change_ref`,`_ticket_incident`.`public_log` AS `public_log`,`_ticket_incident`.`public_log_index` AS `public_log_index`,`_ticket_incident`.`user_satisfaction` AS `user_satisfaction`,`_ticket_incident`.`user_commment` AS `user_comment`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_id_friendlyname`,cast(concat(coalesce(`Incident_parent_incident_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_incident_id_friendlyname`,cast(concat(coalesce(`Problem_parent_problem_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_problem_id_friendlyname`,cast(concat(coalesce(`Change_parent_change_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_change_id_friendlyname`,`Change_parent_change_id_ticket`.`finalclass` AS `parent_change_id_finalclass_recall` from ((((((`ticket_incident` `_ticket_incident` left join `service` `Service_service_id_service` on((`_ticket_incident`.`service_id` = `Service_service_id_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_id_servicesubcategory` on((`_ticket_incident`.`servicesubcategory_id` = `ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`id`))) left join (`ticket_incident` `Incident_parent_incident_id_ticket_incident` join `ticket` `Incident_parent_incident_id_ticket` on((`Incident_parent_incident_id_ticket_incident`.`id` = `Incident_parent_incident_id_ticket`.`id`))) on((`_ticket_incident`.`parent_incident_id` = `Incident_parent_incident_id_ticket_incident`.`id`))) left join (`ticket_problem` `Problem_parent_problem_id_ticket_problem` join `ticket` `Problem_parent_problem_id_ticket` on((`Problem_parent_problem_id_ticket_problem`.`id` = `Problem_parent_problem_id_ticket`.`id`))) on((`_ticket_incident`.`parent_problem_id` = `Problem_parent_problem_id_ticket_problem`.`id`))) left join (`change` `Change_parent_change_id_change` join `ticket` `Change_parent_change_id_ticket` on((`Change_parent_change_id_change`.`id` = `Change_parent_change_id_ticket`.`id`))) on((`_ticket_incident`.`parent_change_id` = `Change_parent_change_id_change`.`id`))) join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_ticket_incident`.`id` = `_ticket`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_KnownError`
--

/*!50001 DROP VIEW IF EXISTS `view_KnownError`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_KnownError` AS select distinct `_knownerror`.`id` AS `id`,`_knownerror`.`name` AS `name`,`_knownerror`.`cust_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `cust_name`,`_knownerror`.`problem_id` AS `problem_id`,`Problem_problem_id_ticket`.`ref` AS `problem_ref`,`_knownerror`.`symptom` AS `symptom`,`_knownerror`.`rootcause` AS `root_cause`,`_knownerror`.`workaround` AS `workaround`,`_knownerror`.`solution` AS `solution`,`_knownerror`.`error_code` AS `error_code`,`_knownerror`.`domain` AS `domain`,`_knownerror`.`vendor` AS `vendor`,`_knownerror`.`model` AS `model`,`_knownerror`.`version` AS `version`,cast(concat(coalesce(`_knownerror`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Problem_problem_id_ticket`.`ref`,'')) as char charset utf8) AS `problem_id_friendlyname` from ((`knownerror` `_knownerror` join `organization` `Organization_org_id_organization` on((`_knownerror`.`cust_id` = `Organization_org_id_organization`.`id`))) left join (`ticket_problem` `Problem_problem_id_ticket_problem` join `ticket` `Problem_problem_id_ticket` on((`Problem_problem_id_ticket_problem`.`id` = `Problem_problem_id_ticket`.`id`))) on((`_knownerror`.`problem_id` = `Problem_problem_id_ticket_problem`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Licence`
--

/*!50001 DROP VIEW IF EXISTS `view_Licence`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Licence` AS select distinct `_licence`.`id` AS `id`,`_licence`.`name` AS `name`,`_licence`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_licence`.`usage_limit` AS `usage_limit`,`_licence`.`description` AS `description`,`_licence`.`start_date` AS `start_date`,`_licence`.`end_date` AS `end_date`,`_licence`.`licence_key` AS `licence_key`,`_licence`.`perpetual` AS `perpetual`,`_licence`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_licence`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`licence` `_licence` join `organization` `Organization_org_id_organization` on((`_licence`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Location`
--

/*!50001 DROP VIEW IF EXISTS `view_Location`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Location` AS select distinct `_location`.`id` AS `id`,`_location`.`name` AS `name`,`_location`.`status` AS `status`,`_location`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_location`.`address` AS `address`,`_location`.`postal_code` AS `postal_code`,`_location`.`city` AS `city`,`_location`.`country` AS `country`,cast(concat(coalesce(`_location`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`location` `_location` join `organization` `Organization_org_id_organization` on((`_location`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_LogicalInterface`
--

/*!50001 DROP VIEW IF EXISTS `view_LogicalInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_LogicalInterface` AS select distinct `_logicalinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_ipinterface`.`ipaddress` AS `ipaddress`,`_ipinterface`.`macaddress` AS `macaddress`,`_ipinterface`.`comment` AS `comment`,`_ipinterface`.`ipgateway` AS `ipgateway`,`_ipinterface`.`ipmask` AS `ipmask`,`_ipinterface`.`speed` AS `speed`,`_logicalinterface`.`virtualmachine_id` AS `virtualmachine_id`,`VirtualMachine_virtualmachine_id_functionalci`.`name` AS `virtualmachine_name`,`_networkinterface`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8) AS `virtualmachine_id_friendlyname` from (((`logicalinterface` `_logicalinterface` join (`virtualmachine` `VirtualMachine_virtualmachine_id_virtualmachine` join `functionalci` `VirtualMachine_virtualmachine_id_functionalci` on((`VirtualMachine_virtualmachine_id_virtualmachine`.`id` = `VirtualMachine_virtualmachine_id_functionalci`.`id`))) on((`_logicalinterface`.`virtualmachine_id` = `VirtualMachine_virtualmachine_id_virtualmachine`.`id`))) join `networkinterface` `_networkinterface` on((`_logicalinterface`.`id` = `_networkinterface`.`id`))) join `ipinterface` `_ipinterface` on((`_logicalinterface`.`id` = `_ipinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_LogicalVolume`
--

/*!50001 DROP VIEW IF EXISTS `view_LogicalVolume`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_LogicalVolume` AS select distinct `_logicalvolume`.`id` AS `id`,`_logicalvolume`.`name` AS `name`,`_logicalvolume`.`lun_id` AS `lun_id`,`_logicalvolume`.`description` AS `description`,`_logicalvolume`.`raid_level` AS `raid_level`,`_logicalvolume`.`size` AS `size`,`_logicalvolume`.`storagesystem_id` AS `storagesystem_id`,`StorageSystem_storagesystem_id_functionalci`.`name` AS `storagesystem_name`,cast(concat(coalesce(`StorageSystem_storagesystem_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`_logicalvolume`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`StorageSystem_storagesystem_id_functionalci`.`name`,'')) as char charset utf8) AS `storagesystem_id_friendlyname` from (`logicalvolume` `_logicalvolume` join (`storagesystem` `StorageSystem_storagesystem_id_storagesystem` join `functionalci` `StorageSystem_storagesystem_id_functionalci` on((`StorageSystem_storagesystem_id_storagesystem`.`id` = `StorageSystem_storagesystem_id_functionalci`.`id`))) on((`_logicalvolume`.`storagesystem_id` = `StorageSystem_storagesystem_id_storagesystem`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Middleware`
--

/*!50001 DROP VIEW IF EXISTS `view_Middleware`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Middleware` AS select distinct `_middleware`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`middleware` `_middleware` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_middleware`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_middleware`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_MiddlewareInstance`
--

/*!50001 DROP VIEW IF EXISTS `view_MiddlewareInstance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_MiddlewareInstance` AS select distinct `_middlewareinstance`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_middlewareinstance`.`middleware_id` AS `middleware_id`,`Middleware_middleware_id_functionalci`.`name` AS `middleware_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Middleware_middleware_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `middleware_id_friendlyname` from ((`middlewareinstance` `_middlewareinstance` join ((`middleware` `Middleware_middleware_id_middleware` join `functionalci` `Middleware_middleware_id_functionalci` on((`Middleware_middleware_id_middleware`.`id` = `Middleware_middleware_id_functionalci`.`id`))) join (`softwareinstance` `Middleware_middleware_id_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`Middleware_middleware_id_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`Middleware_middleware_id_middleware`.`id` = `Middleware_middleware_id_softwareinstance`.`id`))) on((`_middlewareinstance`.`middleware_id` = `Middleware_middleware_id_middleware`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_middlewareinstance`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_MobilePhone`
--

/*!50001 DROP VIEW IF EXISTS `view_MobilePhone`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_MobilePhone` AS select distinct `_mobilephone`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_telephonyci`.`phonenumber` AS `phonenumber`,`_mobilephone`.`imei` AS `imei`,`_mobilephone`.`hw_pin` AS `hw_pin`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from (((`mobilephone` `_mobilephone` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_mobilephone`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_mobilephone`.`id` = `_physicaldevice`.`id`))) join `telephonyci` `_telephonyci` on((`_mobilephone`.`id` = `_telephonyci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Model`
--

/*!50001 DROP VIEW IF EXISTS `view_Model`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Model` AS select distinct `_model`.`id` AS `id`,`_typology`.`name` AS `name`,`_model`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_model`.`type` AS `type`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname` from ((`model` `_model` join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_model`.`brand_id` = `Brand_brand_id_brand`.`id`))) join `typology` `_typology` on((`_model`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NAS`
--

/*!50001 DROP VIEW IF EXISTS `view_NAS`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NAS` AS select distinct `_nas`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall` from (((`nas` `_nas` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_nas`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_nas`.`id` = `_physicaldevice`.`id`))) join ((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) on((`_nas`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NASFileSystem`
--

/*!50001 DROP VIEW IF EXISTS `view_NASFileSystem`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NASFileSystem` AS select distinct `_nasfilesystem`.`id` AS `id`,`_nasfilesystem`.`name` AS `name`,`_nasfilesystem`.`description` AS `description`,`_nasfilesystem`.`raid_level` AS `raid_level`,`_nasfilesystem`.`size` AS `size`,`_nasfilesystem`.`nas_id` AS `nas_id`,`NAS_nas_id_functionalci`.`name` AS `nas_name`,cast(concat(coalesce(`_nasfilesystem`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`NAS_nas_id_functionalci`.`name`,'')) as char charset utf8) AS `nas_id_friendlyname` from (`nasfilesystem` `_nasfilesystem` join (`nas` `NAS_nas_id_nas` join `functionalci` `NAS_nas_id_functionalci` on((`NAS_nas_id_nas`.`id` = `NAS_nas_id_functionalci`.`id`))) on((`_nasfilesystem`.`nas_id` = `NAS_nas_id_nas`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NetworkDevice`
--

/*!50001 DROP VIEW IF EXISTS `view_NetworkDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NetworkDevice` AS select distinct `_networkdevice`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id1_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_networkdevice`.`networkdevicetype_id` AS `networkdevicetype_id`,`NetworkDeviceType_networkdevicetype_id_typology`.`name` AS `networkdevicetype_name`,`_networkdevice`.`iosversion_id` AS `iosversion_id`,`IOSVersion_iosversion_id_typology`.`name` AS `iosversion_name`,`_networkdevice`.`ram` AS `ram`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id1_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall`,cast(concat(coalesce(`NetworkDeviceType_networkdevicetype_id_typology`.`name`,'')) as char charset utf8) AS `networkdevicetype_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,''),coalesce(' ',''),coalesce(`IOSVersion_iosversion_id_typology`.`name`,'')) as char charset utf8) AS `iosversion_id_friendlyname` from (((((`networkdevice` `_networkdevice` join (`networkdevicetype` `NetworkDeviceType_networkdevicetype_id_networkdevicetype` join `typology` `NetworkDeviceType_networkdevicetype_id_typology` on((`NetworkDeviceType_networkdevicetype_id_networkdevicetype`.`id` = `NetworkDeviceType_networkdevicetype_id_typology`.`id`))) on((`_networkdevice`.`networkdevicetype_id` = `NetworkDeviceType_networkdevicetype_id_networkdevicetype`.`id`))) left join ((`iosversion` `IOSVersion_iosversion_id_iosversion` join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`IOSVersion_iosversion_id_iosversion`.`brand_id` = `Brand_brand_id_brand`.`id`))) join `typology` `IOSVersion_iosversion_id_typology` on((`IOSVersion_iosversion_id_iosversion`.`id` = `IOSVersion_iosversion_id_typology`.`id`))) on((`_networkdevice`.`iosversion_id` = `IOSVersion_iosversion_id_iosversion`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_networkdevice`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id1_brand` join `typology` `Brand_brand_id1_typology` on((`Brand_brand_id1_brand`.`id` = `Brand_brand_id1_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id1_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_networkdevice`.`id` = `_physicaldevice`.`id`))) join ((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) on((`_networkdevice`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NetworkDeviceType`
--

/*!50001 DROP VIEW IF EXISTS `view_NetworkDeviceType`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NetworkDeviceType` AS select distinct `_networkdevicetype`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`networkdevicetype` `_networkdevicetype` join `typology` `_typology` on((`_networkdevicetype`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NetworkInterface`
--

/*!50001 DROP VIEW IF EXISTS `view_NetworkInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NetworkInterface` AS select distinct `_networkinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_networkinterface`.`finalclass` AS `finalclass`,if((`_networkinterface`.`finalclass` = 'NetworkInterface'),cast(concat(coalesce(`_networkinterface`.`name`,'')) as char charset utf8),if((`_networkinterface`.`finalclass` = 'LogicalInterface'),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`VirtualMachine_virtualmachine_id_functionalci`.`name`,'')) as char charset utf8),if((`_networkinterface`.`finalclass` = 'FiberChannelInterface'),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8)))) AS `friendlyname` from (((`networkinterface` `_networkinterface` left join (`logicalinterface` `_fn_LogicalInterface_logicalinterface` join (`virtualmachine` `VirtualMachine_virtualmachine_id_virtualmachine` join `functionalci` `VirtualMachine_virtualmachine_id_functionalci` on((`VirtualMachine_virtualmachine_id_virtualmachine`.`id` = `VirtualMachine_virtualmachine_id_functionalci`.`id`))) on((`_fn_LogicalInterface_logicalinterface`.`virtualmachine_id` = `VirtualMachine_virtualmachine_id_virtualmachine`.`id`))) on((`_networkinterface`.`id` = `_fn_LogicalInterface_logicalinterface`.`id`))) left join (`fiberchannelinterface` `_fn_FiberChannelInterface_fiberchannelinterface` join (`datacenterdevice` `DatacenterDevice_datacenterdevice_id_datacenterdevice` join `functionalci` `DatacenterDevice_datacenterdevice_id_functionalci` on((`DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id` = `DatacenterDevice_datacenterdevice_id_functionalci`.`id`))) on((`_fn_FiberChannelInterface_fiberchannelinterface`.`datacenterdevice_id` = `DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id`))) on((`_networkinterface`.`id` = `_fn_FiberChannelInterface_fiberchannelinterface`.`id`))) left join (`physicalinterface` `_fn_PhysicalInterface_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`_fn_PhysicalInterface_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) on((`_networkinterface`.`id` = `_fn_PhysicalInterface_physicalinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_NormalChange`
--

/*!50001 DROP VIEW IF EXISTS `view_NormalChange`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_NormalChange` AS select distinct `_change_normal`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_change`.`status` AS `status`,`_change`.`reason` AS `reason`,`_change`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`email` AS `requestor_email`,`_change`.`creation_date` AS `creation_date`,`_change`.`impact` AS `impact`,`_change`.`supervisor_group_id` AS `supervisor_group_id`,`Team_supervisor_group_id_contact`.`name` AS `supervisor_group_name`,`_change`.`supervisor_id` AS `supervisor_id`,`Person_supervisor_id_contact`.`email` AS `supervisor_email`,`_change`.`manager_group_id` AS `manager_group_id`,`Team_manager_group_id_contact`.`name` AS `manager_group_name`,`_change`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`email` AS `manager_email`,`_change`.`outage` AS `outage`,`_change`.`fallback` AS `fallback`,`_change`.`parent_id` AS `parent_id`,`Change_parent_id_ticket`.`ref` AS `parent_name`,`_change_approved`.`approval_date` AS `approval_date`,`_change_approved`.`approval_comment` AS `approval_comment`,`_change_normal`.`acceptance_date` AS `acceptance_date`,`_change_normal`.`acceptance_comment` AS `acceptance_comment`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Team_supervisor_group_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_group_id_friendlyname`,cast(concat(coalesce(`Person_supervisor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_supervisor_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_id_friendlyname`,cast(concat(coalesce(`Team_manager_group_id_contact`.`name`,'')) as char charset utf8) AS `manager_group_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname`,cast(concat(coalesce(`Change_parent_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_id_friendlyname`,`Change_parent_id_ticket`.`finalclass` AS `parent_id_finalclass_recall` from (((`change_normal` `_change_normal` join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_change_normal`.`id` = `_ticket`.`id`))) join ((((((`change` `_change` left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_change`.`requestor_id` = `Person_requestor_id_person`.`id`))) left join (`team` `Team_supervisor_group_id_team` join `contact` `Team_supervisor_group_id_contact` on((`Team_supervisor_group_id_team`.`id` = `Team_supervisor_group_id_contact`.`id`))) on((`_change`.`supervisor_group_id` = `Team_supervisor_group_id_team`.`id`))) left join (`person` `Person_supervisor_id_person` join `contact` `Person_supervisor_id_contact` on((`Person_supervisor_id_person`.`id` = `Person_supervisor_id_contact`.`id`))) on((`_change`.`supervisor_id` = `Person_supervisor_id_person`.`id`))) left join (`team` `Team_manager_group_id_team` join `contact` `Team_manager_group_id_contact` on((`Team_manager_group_id_team`.`id` = `Team_manager_group_id_contact`.`id`))) on((`_change`.`manager_group_id` = `Team_manager_group_id_team`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_change`.`manager_id` = `Person_manager_id_person`.`id`))) left join (`change` `Change_parent_id_change` join `ticket` `Change_parent_id_ticket` on((`Change_parent_id_change`.`id` = `Change_parent_id_ticket`.`id`))) on((`_change`.`parent_id` = `Change_parent_id_change`.`id`))) on((`_change_normal`.`id` = `_change`.`id`))) join `change_approved` `_change_approved` on((`_change_normal`.`id` = `_change_approved`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OSFamily`
--

/*!50001 DROP VIEW IF EXISTS `view_OSFamily`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OSFamily` AS select distinct `_osfamily`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname` from (`osfamily` `_osfamily` join `typology` `_typology` on((`_osfamily`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OSLicence`
--

/*!50001 DROP VIEW IF EXISTS `view_OSLicence`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OSLicence` AS select distinct `_oslicence`.`id` AS `id`,`_licence`.`name` AS `name`,`_licence`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_licence`.`usage_limit` AS `usage_limit`,`_licence`.`description` AS `description`,`_licence`.`start_date` AS `start_date`,`_licence`.`end_date` AS `end_date`,`_licence`.`licence_key` AS `licence_key`,`_licence`.`perpetual` AS `perpetual`,`_oslicence`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_licence`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_licence`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname` from ((`oslicence` `_oslicence` join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_oslicence`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) join (`licence` `_licence` join `organization` `Organization_org_id_organization` on((`_licence`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_oslicence`.`id` = `_licence`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OSPatch`
--

/*!50001 DROP VIEW IF EXISTS `view_OSPatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OSPatch` AS select distinct `_ospatch`.`id` AS `id`,`_patch`.`name` AS `name`,`_patch`.`description` AS `description`,`_ospatch`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_patch`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_patch`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname` from ((`ospatch` `_ospatch` join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_ospatch`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) join `patch` `_patch` on((`_ospatch`.`id` = `_patch`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OSVersion`
--

/*!50001 DROP VIEW IF EXISTS `view_OSVersion`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OSVersion` AS select distinct `_osversion`.`id` AS `id`,`_typology`.`name` AS `name`,`_osversion`.`osfamily_id` AS `osfamily_id`,`OSFamily_osfamily_id_typology`.`name` AS `osfamily_name`,`_typology`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`OSFamily_osfamily_id_typology`.`name`,'')) as char charset utf8) AS `osfamily_id_friendlyname` from ((`osversion` `_osversion` join (`osfamily` `OSFamily_osfamily_id_osfamily` join `typology` `OSFamily_osfamily_id_typology` on((`OSFamily_osfamily_id_osfamily`.`id` = `OSFamily_osfamily_id_typology`.`id`))) on((`_osversion`.`osfamily_id` = `OSFamily_osfamily_id_osfamily`.`id`))) join `typology` `_typology` on((`_osversion`.`id` = `_typology`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Organization`
--

/*!50001 DROP VIEW IF EXISTS `view_Organization`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Organization` AS select distinct `_organization`.`id` AS `id`,`_organization`.`name` AS `name`,`_organization`.`code` AS `code`,`_organization`.`status` AS `status`,`_organization`.`parent_id` AS `parent_id`,`Organization_parent_id_organization`.`name` AS `parent_name`,`_organization`.`deliverymodel_id` AS `deliverymodel_id`,`DeliveryModel_deliverymodel_id_deliverymodel`.`name` AS `deliverymodel_name`,cast(concat(coalesce(`_organization`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_parent_id_organization`.`name`,'')) as char charset utf8) AS `parent_id_friendlyname`,cast(concat(coalesce(`DeliveryModel_deliverymodel_id_deliverymodel`.`name`,'')) as char charset utf8) AS `deliverymodel_id_friendlyname` from ((`organization` `_organization` left join `organization` `Organization_parent_id_organization` on((`_organization`.`parent_id` = `Organization_parent_id_organization`.`id`))) left join `deliverymodel` `DeliveryModel_deliverymodel_id_deliverymodel` on((`_organization`.`deliverymodel_id` = `DeliveryModel_deliverymodel_id_deliverymodel`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_OtherSoftware`
--

/*!50001 DROP VIEW IF EXISTS `view_OtherSoftware`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_OtherSoftware` AS select distinct `_othersoftware`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`othersoftware` `_othersoftware` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_othersoftware`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_othersoftware`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PC`
--

/*!50001 DROP VIEW IF EXISTS `view_PC`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PC` AS select distinct `_pc`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_pc`.`osfamily_id` AS `osfamily_id`,`OSFamily_osfamily_id_typology`.`name` AS `osfamily_name`,`_pc`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_pc`.`cpu` AS `cpu`,`_pc`.`ram` AS `ram`,`_pc`.`type` AS `type`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`OSFamily_osfamily_id_typology`.`name`,'')) as char charset utf8) AS `osfamily_id_friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname` from ((((`pc` `_pc` left join (`osfamily` `OSFamily_osfamily_id_osfamily` join `typology` `OSFamily_osfamily_id_typology` on((`OSFamily_osfamily_id_osfamily`.`id` = `OSFamily_osfamily_id_typology`.`id`))) on((`_pc`.`osfamily_id` = `OSFamily_osfamily_id_osfamily`.`id`))) left join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_pc`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_pc`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_pc`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PCSoftware`
--

/*!50001 DROP VIEW IF EXISTS `view_PCSoftware`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PCSoftware` AS select distinct `_pcsoftware`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`pcsoftware` `_pcsoftware` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_pcsoftware`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_pcsoftware`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PDU`
--

/*!50001 DROP VIEW IF EXISTS `view_PDU`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PDU` AS select distinct `_pdu`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_pdu`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_pdu`.`powerstart_id` AS `powerstart_id`,`PowerConnection_powerstart_id_functionalci`.`name` AS `powerstart_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerstart_id_functionalci`.`name`,'')) as char charset utf8) AS `powerstart_id_friendlyname`,`PowerConnection_powerstart_id_functionalci`.`finalclass` AS `powerstart_id_finalclass_recall` from ((((`pdu` `_pdu` join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_pdu`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`powerconnection` `PowerConnection_powerstart_id_powerconnection` join `functionalci` `PowerConnection_powerstart_id_functionalci` on((`PowerConnection_powerstart_id_powerconnection`.`id` = `PowerConnection_powerstart_id_functionalci`.`id`))) on((`_pdu`.`powerstart_id` = `PowerConnection_powerstart_id_powerconnection`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_pdu`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_pdu`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Patch`
--

/*!50001 DROP VIEW IF EXISTS `view_Patch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Patch` AS select distinct `_patch`.`id` AS `id`,`_patch`.`name` AS `name`,`_patch`.`description` AS `description`,`_patch`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_patch`.`name`,'')) as char charset utf8) AS `friendlyname` from `patch` `_patch` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Peripheral`
--

/*!50001 DROP VIEW IF EXISTS `view_Peripheral`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Peripheral` AS select distinct `_peripheral`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`peripheral` `_peripheral` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_peripheral`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_peripheral`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Person`
--

/*!50001 DROP VIEW IF EXISTS `view_Person`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Person` AS select distinct `_person`.`id` AS `id`,`_contact`.`name` AS `name`,`_contact`.`status` AS `status`,`_contact`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_contact`.`email` AS `email`,`_contact`.`phone` AS `phone`,`_contact`.`notify` AS `notify`,`_contact`.`function` AS `function`,`_person`.`first_name` AS `first_name`,`_person`.`employee_number` AS `employee_number`,`_person`.`mobile_phone` AS `mobile_phone`,`_person`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_person`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`name` AS `manager_name`,`_contact`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_person`.`first_name`,''),coalesce(' ',''),coalesce(`_contact`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname` from (((`person` `_person` left join `location` `Location_location_id_location` on((`_person`.`location_id` = `Location_location_id_location`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_person`.`manager_id` = `Person_manager_id_person`.`id`))) join (`contact` `_contact` join `organization` `Organization_org_id_organization` on((`_contact`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_person`.`id` = `_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Phone`
--

/*!50001 DROP VIEW IF EXISTS `view_Phone`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Phone` AS select distinct `_phone`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_telephonyci`.`phonenumber` AS `phonenumber`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from (((`phone` `_phone` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_phone`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_phone`.`id` = `_physicaldevice`.`id`))) join `telephonyci` `_telephonyci` on((`_phone`.`id` = `_telephonyci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PhysicalDevice`
--

/*!50001 DROP VIEW IF EXISTS `view_PhysicalDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PhysicalDevice` AS select distinct `_physicaldevice`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_physicaldevice`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PhysicalInterface`
--

/*!50001 DROP VIEW IF EXISTS `view_PhysicalInterface`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PhysicalInterface` AS select distinct `_physicalinterface`.`id` AS `id`,`_networkinterface`.`name` AS `name`,`_ipinterface`.`ipaddress` AS `ipaddress`,`_ipinterface`.`macaddress` AS `macaddress`,`_ipinterface`.`comment` AS `comment`,`_ipinterface`.`ipgateway` AS `ipgateway`,`_ipinterface`.`ipmask` AS `ipmask`,`_ipinterface`.`speed` AS `speed`,`_physicalinterface`.`connectableci_id` AS `connectableci_id`,`ConnectableCI_connectableci_id_functionalci`.`name` AS `connectableci_name`,`_networkinterface`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `connectableci_id_friendlyname`,`ConnectableCI_connectableci_id_functionalci`.`finalclass` AS `connectableci_id_finalclass_recall` from (((`physicalinterface` `_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) join `networkinterface` `_networkinterface` on((`_physicalinterface`.`id` = `_networkinterface`.`id`))) join `ipinterface` `_ipinterface` on((`_physicalinterface`.`id` = `_ipinterface`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PowerConnection`
--

/*!50001 DROP VIEW IF EXISTS `view_PowerConnection`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PowerConnection` AS select distinct `_powerconnection`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`powerconnection` `_powerconnection` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_powerconnection`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_powerconnection`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PowerSource`
--

/*!50001 DROP VIEW IF EXISTS `view_PowerSource`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PowerSource` AS select distinct `_powersource`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`powersource` `_powersource` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_powersource`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_powersource`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Printer`
--

/*!50001 DROP VIEW IF EXISTS `view_Printer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Printer` AS select distinct `_printer`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`printer` `_printer` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_printer`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_printer`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Problem`
--

/*!50001 DROP VIEW IF EXISTS `view_Problem`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Problem` AS select distinct `_ticket_problem`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket_problem`.`status` AS `status`,`_ticket_problem`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_ticket_problem`.`servicesubcategory_id` AS `servicesubcategory_id`,`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name` AS `servicesubcategory_name`,`_ticket_problem`.`product` AS `product`,`_ticket_problem`.`impact` AS `impact`,`_ticket_problem`.`urgency` AS `urgency`,`_ticket_problem`.`priority` AS `priority`,`_ticket_problem`.`related_change_id` AS `related_change_id`,`Change_related_change_id_ticket`.`ref` AS `related_change_ref`,`_ticket_problem`.`assignment_date` AS `assignment_date`,`_ticket_problem`.`resolution_date` AS `resolution_date`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_id_friendlyname`,cast(concat(coalesce(`Change_related_change_id_ticket`.`ref`,'')) as char charset utf8) AS `related_change_id_friendlyname`,`Change_related_change_id_ticket`.`finalclass` AS `related_change_id_finalclass_recall` from ((((`ticket_problem` `_ticket_problem` left join `service` `Service_service_id_service` on((`_ticket_problem`.`service_id` = `Service_service_id_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_id_servicesubcategory` on((`_ticket_problem`.`servicesubcategory_id` = `ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`id`))) left join (`change` `Change_related_change_id_change` join `ticket` `Change_related_change_id_ticket` on((`Change_related_change_id_change`.`id` = `Change_related_change_id_ticket`.`id`))) on((`_ticket_problem`.`related_change_id` = `Change_related_change_id_change`.`id`))) join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_ticket_problem`.`id` = `_ticket`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ProviderContract`
--

/*!50001 DROP VIEW IF EXISTS `view_ProviderContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ProviderContract` AS select distinct `_providercontract`.`id` AS `id`,`_contract`.`name` AS `name`,`_contract`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_contract`.`description` AS `description`,`_contract`.`start_date` AS `start_date`,`_contract`.`end_date` AS `end_date`,`_contract`.`cost` AS `cost`,`_contract`.`cost_currency` AS `cost_currency`,`_contract`.`contracttype_id` AS `contracttype_id`,`ContractType_contracttype_id_typology`.`name` AS `contracttype_name`,`_contract`.`billing_frequency` AS `billing_frequency`,`_contract`.`cost_unit` AS `cost_unit`,`_contract`.`provider_id` AS `provider_id`,`Organization_provider_id_organization`.`name` AS `provider_name`,`_contract`.`status` AS `status`,`_providercontract`.`sla` AS `sla`,`_providercontract`.`coverage` AS `coverage`,`_contract`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_contract`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`ContractType_contracttype_id_typology`.`name`,'')) as char charset utf8) AS `contracttype_id_friendlyname`,cast(concat(coalesce(`Organization_provider_id_organization`.`name`,'')) as char charset utf8) AS `provider_id_friendlyname` from (`providercontract` `_providercontract` join (((`contract` `_contract` join `organization` `Organization_org_id_organization` on((`_contract`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`contracttype` `ContractType_contracttype_id_contracttype` join `typology` `ContractType_contracttype_id_typology` on((`ContractType_contracttype_id_contracttype`.`id` = `ContractType_contracttype_id_typology`.`id`))) on((`_contract`.`contracttype_id` = `ContractType_contracttype_id_contracttype`.`id`))) join `organization` `Organization_provider_id_organization` on((`_contract`.`provider_id` = `Organization_provider_id_organization`.`id`))) on((`_providercontract`.`id` = `_contract`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Rack`
--

/*!50001 DROP VIEW IF EXISTS `view_Rack`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Rack` AS select distinct `_rack`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_rack`.`nb_u` AS `nb_u`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`rack` `_rack` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_rack`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_rack`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_RoutineChange`
--

/*!50001 DROP VIEW IF EXISTS `view_RoutineChange`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_RoutineChange` AS select distinct `_change_routine`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_change`.`status` AS `status`,`_change`.`reason` AS `reason`,`_change`.`requestor_id` AS `requestor_id`,`Person_requestor_id_contact`.`email` AS `requestor_email`,`_change`.`creation_date` AS `creation_date`,`_change`.`impact` AS `impact`,`_change`.`supervisor_group_id` AS `supervisor_group_id`,`Team_supervisor_group_id_contact`.`name` AS `supervisor_group_name`,`_change`.`supervisor_id` AS `supervisor_id`,`Person_supervisor_id_contact`.`email` AS `supervisor_email`,`_change`.`manager_group_id` AS `manager_group_id`,`Team_manager_group_id_contact`.`name` AS `manager_group_name`,`_change`.`manager_id` AS `manager_id`,`Person_manager_id_contact`.`email` AS `manager_email`,`_change`.`outage` AS `outage`,`_change`.`fallback` AS `fallback`,`_change`.`parent_id` AS `parent_id`,`Change_parent_id_ticket`.`ref` AS `parent_name`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_requestor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_requestor_id_contact`.`name`,'')) as char charset utf8) AS `requestor_id_friendlyname`,cast(concat(coalesce(`Team_supervisor_group_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_group_id_friendlyname`,cast(concat(coalesce(`Person_supervisor_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_supervisor_id_contact`.`name`,'')) as char charset utf8) AS `supervisor_id_friendlyname`,cast(concat(coalesce(`Team_manager_group_id_contact`.`name`,'')) as char charset utf8) AS `manager_group_id_friendlyname`,cast(concat(coalesce(`Person_manager_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_manager_id_contact`.`name`,'')) as char charset utf8) AS `manager_id_friendlyname`,cast(concat(coalesce(`Change_parent_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_id_friendlyname`,`Change_parent_id_ticket`.`finalclass` AS `parent_id_finalclass_recall` from ((`change_routine` `_change_routine` join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_change_routine`.`id` = `_ticket`.`id`))) join ((((((`change` `_change` left join (`person` `Person_requestor_id_person` join `contact` `Person_requestor_id_contact` on((`Person_requestor_id_person`.`id` = `Person_requestor_id_contact`.`id`))) on((`_change`.`requestor_id` = `Person_requestor_id_person`.`id`))) left join (`team` `Team_supervisor_group_id_team` join `contact` `Team_supervisor_group_id_contact` on((`Team_supervisor_group_id_team`.`id` = `Team_supervisor_group_id_contact`.`id`))) on((`_change`.`supervisor_group_id` = `Team_supervisor_group_id_team`.`id`))) left join (`person` `Person_supervisor_id_person` join `contact` `Person_supervisor_id_contact` on((`Person_supervisor_id_person`.`id` = `Person_supervisor_id_contact`.`id`))) on((`_change`.`supervisor_id` = `Person_supervisor_id_person`.`id`))) left join (`team` `Team_manager_group_id_team` join `contact` `Team_manager_group_id_contact` on((`Team_manager_group_id_team`.`id` = `Team_manager_group_id_contact`.`id`))) on((`_change`.`manager_group_id` = `Team_manager_group_id_team`.`id`))) left join (`person` `Person_manager_id_person` join `contact` `Person_manager_id_contact` on((`Person_manager_id_person`.`id` = `Person_manager_id_contact`.`id`))) on((`_change`.`manager_id` = `Person_manager_id_person`.`id`))) left join (`change` `Change_parent_id_change` join `ticket` `Change_parent_id_ticket` on((`Change_parent_id_change`.`id` = `Change_parent_id_ticket`.`id`))) on((`_change`.`parent_id` = `Change_parent_id_change`.`id`))) on((`_change_routine`.`id` = `_change`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SANSwitch`
--

/*!50001 DROP VIEW IF EXISTS `view_SANSwitch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SANSwitch` AS select distinct `_sanswitch`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall` from (((`sanswitch` `_sanswitch` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_sanswitch`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_sanswitch`.`id` = `_physicaldevice`.`id`))) join ((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) on((`_sanswitch`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SLA`
--

/*!50001 DROP VIEW IF EXISTS `view_SLA`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SLA` AS select distinct `_sla`.`id` AS `id`,`_sla`.`name` AS `name`,`_sla`.`description` AS `description`,`_sla`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,cast(concat(coalesce(`_sla`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`sla` `_sla` join `organization` `Organization_org_id_organization` on((`_sla`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SLT`
--

/*!50001 DROP VIEW IF EXISTS `view_SLT`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SLT` AS select distinct `_slt`.`id` AS `id`,`_slt`.`name` AS `name`,`_slt`.`priority` AS `priority`,`_slt`.`request_type` AS `request_type`,`_slt`.`metric` AS `metric`,`_slt`.`value` AS `value`,`_slt`.`unit` AS `unit`,cast(concat(coalesce(`_slt`.`name`,'')) as char charset utf8) AS `friendlyname` from `slt` `_slt` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Server`
--

/*!50001 DROP VIEW IF EXISTS `view_Server`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Server` AS select distinct `_server`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_server`.`osfamily_id` AS `osfamily_id`,`OSFamily_osfamily_id_typology`.`name` AS `osfamily_name`,`_server`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_server`.`oslicence_id` AS `oslicence_id`,`OSLicence_oslicence_id_licence`.`name` AS `oslicence_name`,`_server`.`cpu` AS `cpu`,`_server`.`ram` AS `ram`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall`,cast(concat(coalesce(`OSFamily_osfamily_id_typology`.`name`,'')) as char charset utf8) AS `osfamily_id_friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname`,cast(concat(coalesce(`OSLicence_oslicence_id_licence`.`name`,'')) as char charset utf8) AS `oslicence_id_friendlyname` from ((((((`server` `_server` left join (`osfamily` `OSFamily_osfamily_id_osfamily` join `typology` `OSFamily_osfamily_id_typology` on((`OSFamily_osfamily_id_osfamily`.`id` = `OSFamily_osfamily_id_typology`.`id`))) on((`_server`.`osfamily_id` = `OSFamily_osfamily_id_osfamily`.`id`))) left join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_server`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) left join (`oslicence` `OSLicence_oslicence_id_oslicence` join `licence` `OSLicence_oslicence_id_licence` on((`OSLicence_oslicence_id_oslicence`.`id` = `OSLicence_oslicence_id_licence`.`id`))) on((`_server`.`oslicence_id` = `OSLicence_oslicence_id_oslicence`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_server`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_server`.`id` = `_physicaldevice`.`id`))) join ((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) on((`_server`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Service`
--

/*!50001 DROP VIEW IF EXISTS `view_Service`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Service` AS select distinct `_service`.`id` AS `id`,`_service`.`name` AS `name`,`_service`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_service`.`servicefamily_id` AS `servicefamily_id`,`ServiceFamily_servicefamily_id_servicefamilly`.`name` AS `servicefamily_name`,`_service`.`description` AS `description`,`_service`.`status` AS `status`,cast(concat(coalesce(`_service`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`ServiceFamily_servicefamily_id_servicefamilly`.`name`,'')) as char charset utf8) AS `servicefamily_id_friendlyname` from ((`service` `_service` join `organization` `Organization_org_id_organization` on((`_service`.`org_id` = `Organization_org_id_organization`.`id`))) left join `servicefamilly` `ServiceFamily_servicefamily_id_servicefamilly` on((`_service`.`servicefamily_id` = `ServiceFamily_servicefamily_id_servicefamilly`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ServiceFamily`
--

/*!50001 DROP VIEW IF EXISTS `view_ServiceFamily`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ServiceFamily` AS select distinct `_servicefamilly`.`id` AS `id`,`_servicefamilly`.`name` AS `name`,cast(concat(coalesce(`_servicefamilly`.`name`,'')) as char charset utf8) AS `friendlyname` from `servicefamilly` `_servicefamilly` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ServiceSubcategory`
--

/*!50001 DROP VIEW IF EXISTS `view_ServiceSubcategory`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ServiceSubcategory` AS select distinct `_servicesubcategory`.`id` AS `id`,`_servicesubcategory`.`name` AS `name`,`_servicesubcategory`.`description` AS `description`,`_servicesubcategory`.`service_id` AS `service_id`,`Service_service_id_service`.`org_id` AS `service_org_id`,`Service_service_id_service`.`name` AS `service_name`,`Organization_org_id_organization`.`name` AS `service_provider`,`_servicesubcategory`.`request_type` AS `request_type`,`_servicesubcategory`.`status` AS `status`,cast(concat(coalesce(`_servicesubcategory`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `service_org_id_friendlyname` from (`servicesubcategory` `_servicesubcategory` join (`service` `Service_service_id_service` join `organization` `Organization_org_id_organization` on((`Service_service_id_service`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_servicesubcategory`.`service_id` = `Service_service_id_service`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Software`
--

/*!50001 DROP VIEW IF EXISTS `view_Software`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Software` AS select distinct `_software`.`id` AS `id`,`_software`.`name` AS `name`,`_software`.`vendor` AS `vendor`,`_software`.`version` AS `version`,`_software`.`type` AS `type`,cast(concat(coalesce(`_software`.`name`,''),coalesce(' ',''),coalesce(`_software`.`version`,'')) as char charset utf8) AS `friendlyname` from `software` `_software` where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SoftwareInstance`
--

/*!50001 DROP VIEW IF EXISTS `view_SoftwareInstance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SoftwareInstance` AS select distinct `_softwareinstance`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_softwareinstance`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SoftwareLicence`
--

/*!50001 DROP VIEW IF EXISTS `view_SoftwareLicence`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SoftwareLicence` AS select distinct `_softwarelicence`.`id` AS `id`,`_licence`.`name` AS `name`,`_licence`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_licence`.`usage_limit` AS `usage_limit`,`_licence`.`description` AS `description`,`_licence`.`start_date` AS `start_date`,`_licence`.`end_date` AS `end_date`,`_licence`.`licence_key` AS `licence_key`,`_licence`.`perpetual` AS `perpetual`,`_softwarelicence`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_licence`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_licence`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname` from ((`softwarelicence` `_softwarelicence` join `software` `Software_software_id_software` on((`_softwarelicence`.`software_id` = `Software_software_id_software`.`id`))) join (`licence` `_licence` join `organization` `Organization_org_id_organization` on((`_licence`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_softwarelicence`.`id` = `_licence`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_SoftwarePatch`
--

/*!50001 DROP VIEW IF EXISTS `view_SoftwarePatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_SoftwarePatch` AS select distinct `_softwarepatch`.`id` AS `id`,`_patch`.`name` AS `name`,`_patch`.`description` AS `description`,`_softwarepatch`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_patch`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_patch`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname` from ((`softwarepatch` `_softwarepatch` join `software` `Software_software_id_software` on((`_softwarepatch`.`software_id` = `Software_software_id_software`.`id`))) join `patch` `_patch` on((`_softwarepatch`.`id` = `_patch`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_StorageSystem`
--

/*!50001 DROP VIEW IF EXISTS `view_StorageSystem`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_StorageSystem` AS select distinct `_storagesystem`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall` from (((`storagesystem` `_storagesystem` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_storagesystem`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_storagesystem`.`id` = `_physicaldevice`.`id`))) join ((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) on((`_storagesystem`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Subnet`
--

/*!50001 DROP VIEW IF EXISTS `view_Subnet`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Subnet` AS select distinct `_subnet`.`id` AS `id`,`_subnet`.`description` AS `description`,`_subnet`.`subnet_name` AS `subnet_name`,`_subnet`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_subnet`.`ip` AS `ip`,`_subnet`.`ip_mask` AS `ip_mask`,cast(concat(coalesce(`_subnet`.`ip`,''),coalesce(' ',''),coalesce(`_subnet`.`ip_mask`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`subnet` `_subnet` join `organization` `Organization_org_id_organization` on((`_subnet`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Tablet`
--

/*!50001 DROP VIEW IF EXISTS `view_Tablet`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Tablet` AS select distinct `_tablet`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`tablet` `_tablet` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_tablet`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_tablet`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Tape`
--

/*!50001 DROP VIEW IF EXISTS `view_Tape`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Tape` AS select distinct `_tape`.`id` AS `id`,`_tape`.`name` AS `name`,`_tape`.`description` AS `description`,`_tape`.`size` AS `size`,`_tape`.`tapelibrary_id` AS `tapelibrary_id`,`TapeLibrary_tapelibrary_id_functionalci`.`name` AS `tapelibrary_name`,cast(concat(coalesce(`_tape`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`TapeLibrary_tapelibrary_id_functionalci`.`name`,'')) as char charset utf8) AS `tapelibrary_id_friendlyname` from (`tape` `_tape` join (`tapelibrary` `TapeLibrary_tapelibrary_id_tapelibrary` join `functionalci` `TapeLibrary_tapelibrary_id_functionalci` on((`TapeLibrary_tapelibrary_id_tapelibrary`.`id` = `TapeLibrary_tapelibrary_id_functionalci`.`id`))) on((`_tape`.`tapelibrary_id` = `TapeLibrary_tapelibrary_id_tapelibrary`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_TapeLibrary`
--

/*!50001 DROP VIEW IF EXISTS `view_TapeLibrary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_TapeLibrary` AS select distinct `_tapelibrary`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_datacenterdevice`.`rack_id` AS `rack_id`,`Rack_rack_id_functionalci`.`name` AS `rack_name`,`_datacenterdevice`.`enclosure_id` AS `enclosure_id`,`Enclosure_enclosure_id_functionalci`.`name` AS `enclosure_name`,`_datacenterdevice`.`nb_u` AS `nb_u`,`_datacenterdevice`.`managementip` AS `managementip`,`_datacenterdevice`.`powera_id` AS `powerA_id`,`PowerConnection_powerA_id_functionalci`.`name` AS `powerA_name`,`_datacenterdevice`.`powerB_id` AS `powerB_id`,`PowerConnection_powerB_id_functionalci`.`name` AS `powerB_name`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname`,cast(concat(coalesce(`Rack_rack_id_functionalci`.`name`,'')) as char charset utf8) AS `rack_id_friendlyname`,cast(concat(coalesce(`Enclosure_enclosure_id_functionalci`.`name`,'')) as char charset utf8) AS `enclosure_id_friendlyname`,cast(concat(coalesce(`PowerConnection_powerA_id_functionalci`.`name`,'')) as char charset utf8) AS `powerA_id_friendlyname`,`PowerConnection_powerA_id_functionalci`.`finalclass` AS `powerA_id_finalclass_recall`,cast(concat(coalesce(`PowerConnection_powerB_id_functionalci`.`name`,'')) as char charset utf8) AS `powerB_id_friendlyname`,`PowerConnection_powerB_id_functionalci`.`finalclass` AS `powerB_id_finalclass_recall` from (((`tapelibrary` `_tapelibrary` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_tapelibrary`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_tapelibrary`.`id` = `_physicaldevice`.`id`))) join ((((`datacenterdevice` `_datacenterdevice` left join (`rack` `Rack_rack_id_rack` join `functionalci` `Rack_rack_id_functionalci` on((`Rack_rack_id_rack`.`id` = `Rack_rack_id_functionalci`.`id`))) on((`_datacenterdevice`.`rack_id` = `Rack_rack_id_rack`.`id`))) left join (`enclosure` `Enclosure_enclosure_id_enclosure` join `functionalci` `Enclosure_enclosure_id_functionalci` on((`Enclosure_enclosure_id_enclosure`.`id` = `Enclosure_enclosure_id_functionalci`.`id`))) on((`_datacenterdevice`.`enclosure_id` = `Enclosure_enclosure_id_enclosure`.`id`))) left join (`powerconnection` `PowerConnection_powerA_id_powerconnection` join `functionalci` `PowerConnection_powerA_id_functionalci` on((`PowerConnection_powerA_id_powerconnection`.`id` = `PowerConnection_powerA_id_functionalci`.`id`))) on((`_datacenterdevice`.`powera_id` = `PowerConnection_powerA_id_powerconnection`.`id`))) left join (`powerconnection` `PowerConnection_powerB_id_powerconnection` join `functionalci` `PowerConnection_powerB_id_functionalci` on((`PowerConnection_powerB_id_powerconnection`.`id` = `PowerConnection_powerB_id_functionalci`.`id`))) on((`_datacenterdevice`.`powerB_id` = `PowerConnection_powerB_id_powerconnection`.`id`))) on((`_tapelibrary`.`id` = `_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Team`
--

/*!50001 DROP VIEW IF EXISTS `view_Team`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Team` AS select distinct `_team`.`id` AS `id`,`_contact`.`name` AS `name`,`_contact`.`status` AS `status`,`_contact`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_contact`.`email` AS `email`,`_contact`.`phone` AS `phone`,`_contact`.`notify` AS `notify`,`_contact`.`function` AS `function`,`_contact`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_contact`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`team` `_team` join (`contact` `_contact` join `organization` `Organization_org_id_organization` on((`_contact`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_team`.`id` = `_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_TelephonyCI`
--

/*!50001 DROP VIEW IF EXISTS `view_TelephonyCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_TelephonyCI` AS select distinct `_telephonyci`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_physicaldevice`.`serialnumber` AS `serialnumber`,`_physicaldevice`.`location_id` AS `location_id`,`Location_location_id_location`.`name` AS `location_name`,`_physicaldevice`.`status` AS `status`,`_physicaldevice`.`brand_id` AS `brand_id`,`Brand_brand_id_typology`.`name` AS `brand_name`,`_physicaldevice`.`model_id` AS `model_id`,`Model_model_id_typology`.`name` AS `model_name`,`_physicaldevice`.`asset_number` AS `asset_number`,`_physicaldevice`.`purchase_date` AS `purchase_date`,`_physicaldevice`.`end_of_warranty` AS `end_of_warranty`,`_telephonyci`.`phonenumber` AS `phonenumber`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Location_location_id_location`.`name`,'')) as char charset utf8) AS `location_id_friendlyname`,cast(concat(coalesce(`Brand_brand_id_typology`.`name`,'')) as char charset utf8) AS `brand_id_friendlyname`,cast(concat(coalesce(`Model_model_id_typology`.`name`,'')) as char charset utf8) AS `model_id_friendlyname` from ((`telephonyci` `_telephonyci` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_telephonyci`.`id` = `_functionalci`.`id`))) join (((`physicaldevice` `_physicaldevice` left join `location` `Location_location_id_location` on((`_physicaldevice`.`location_id` = `Location_location_id_location`.`id`))) left join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_physicaldevice`.`brand_id` = `Brand_brand_id_brand`.`id`))) left join (`model` `Model_model_id_model` join `typology` `Model_model_id_typology` on((`Model_model_id_model`.`id` = `Model_model_id_typology`.`id`))) on((`_physicaldevice`.`model_id` = `Model_model_id_model`.`id`))) on((`_telephonyci`.`id` = `_physicaldevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Ticket`
--

/*!50001 DROP VIEW IF EXISTS `view_Ticket`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Ticket` AS select distinct `_ticket`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname` from ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_TriggerOnObjectCreate`
--

/*!50001 DROP VIEW IF EXISTS `view_TriggerOnObjectCreate`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_TriggerOnObjectCreate` AS select distinct `_priv_trigger_onobjcreate`.`id` AS `id`,`_priv_trigger`.`description` AS `description`,`_priv_trigger_onobject`.`target_class` AS `target_class`,`_priv_trigger_onobject`.`filter` AS `filter`,`_priv_trigger`.`realclass` AS `finalclass`,cast(concat(coalesce(`_priv_trigger`.`description`,'')) as char charset utf8) AS `friendlyname` from ((`priv_trigger_onobjcreate` `_priv_trigger_onobjcreate` join `priv_trigger` `_priv_trigger` on((`_priv_trigger_onobjcreate`.`id` = `_priv_trigger`.`id`))) join `priv_trigger_onobject` `_priv_trigger_onobject` on((`_priv_trigger_onobjcreate`.`id` = `_priv_trigger_onobject`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_TriggerOnPortalUpdate`
--

/*!50001 DROP VIEW IF EXISTS `view_TriggerOnPortalUpdate`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_TriggerOnPortalUpdate` AS select distinct `_priv_trigger_onportalupdate`.`id` AS `id`,`_priv_trigger`.`description` AS `description`,`_priv_trigger_onobject`.`target_class` AS `target_class`,`_priv_trigger_onobject`.`filter` AS `filter`,`_priv_trigger`.`realclass` AS `finalclass`,cast(concat(coalesce(`_priv_trigger`.`description`,'')) as char charset utf8) AS `friendlyname` from ((`priv_trigger_onportalupdate` `_priv_trigger_onportalupdate` join `priv_trigger` `_priv_trigger` on((`_priv_trigger_onportalupdate`.`id` = `_priv_trigger`.`id`))) join `priv_trigger_onobject` `_priv_trigger_onobject` on((`_priv_trigger_onportalupdate`.`id` = `_priv_trigger_onobject`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_TriggerOnStateEnter`
--

/*!50001 DROP VIEW IF EXISTS `view_TriggerOnStateEnter`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_TriggerOnStateEnter` AS select distinct `_priv_trigger_onstateenter`.`id` AS `id`,`_priv_trigger`.`description` AS `description`,`_priv_trigger_onobject`.`target_class` AS `target_class`,`_priv_trigger_onobject`.`filter` AS `filter`,`_priv_trigger_onstatechange`.`state` AS `state`,`_priv_trigger`.`realclass` AS `finalclass`,cast(concat(coalesce(`_priv_trigger`.`description`,'')) as char charset utf8) AS `friendlyname` from (((`priv_trigger_onstateenter` `_priv_trigger_onstateenter` join `priv_trigger` `_priv_trigger` on((`_priv_trigger_onstateenter`.`id` = `_priv_trigger`.`id`))) join `priv_trigger_onobject` `_priv_trigger_onobject` on((`_priv_trigger_onstateenter`.`id` = `_priv_trigger_onobject`.`id`))) join `priv_trigger_onstatechange` `_priv_trigger_onstatechange` on((`_priv_trigger_onstateenter`.`id` = `_priv_trigger_onstatechange`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_TriggerOnStateLeave`
--

/*!50001 DROP VIEW IF EXISTS `view_TriggerOnStateLeave`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_TriggerOnStateLeave` AS select distinct `_priv_trigger_onstateleave`.`id` AS `id`,`_priv_trigger`.`description` AS `description`,`_priv_trigger_onobject`.`target_class` AS `target_class`,`_priv_trigger_onobject`.`filter` AS `filter`,`_priv_trigger_onstatechange`.`state` AS `state`,`_priv_trigger`.`realclass` AS `finalclass`,cast(concat(coalesce(`_priv_trigger`.`description`,'')) as char charset utf8) AS `friendlyname` from (((`priv_trigger_onstateleave` `_priv_trigger_onstateleave` join `priv_trigger` `_priv_trigger` on((`_priv_trigger_onstateleave`.`id` = `_priv_trigger`.`id`))) join `priv_trigger_onobject` `_priv_trigger_onobject` on((`_priv_trigger_onstateleave`.`id` = `_priv_trigger_onobject`.`id`))) join `priv_trigger_onstatechange` `_priv_trigger_onstatechange` on((`_priv_trigger_onstateleave`.`id` = `_priv_trigger_onstatechange`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_TriggerOnThresholdReached`
--

/*!50001 DROP VIEW IF EXISTS `view_TriggerOnThresholdReached`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_TriggerOnThresholdReached` AS select distinct `_priv_trigger_threshold`.`id` AS `id`,`_priv_trigger`.`description` AS `description`,`_priv_trigger_onobject`.`target_class` AS `target_class`,`_priv_trigger_onobject`.`filter` AS `filter`,`_priv_trigger_threshold`.`stop_watch_code` AS `stop_watch_code`,`_priv_trigger_threshold`.`threshold_index` AS `threshold_index`,`_priv_trigger`.`realclass` AS `finalclass`,cast(concat(coalesce(`_priv_trigger`.`description`,'')) as char charset utf8) AS `friendlyname` from ((`priv_trigger_threshold` `_priv_trigger_threshold` join `priv_trigger` `_priv_trigger` on((`_priv_trigger_threshold`.`id` = `_priv_trigger`.`id`))) join `priv_trigger_onobject` `_priv_trigger_onobject` on((`_priv_trigger_threshold`.`id` = `_priv_trigger_onobject`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Typology`
--

/*!50001 DROP VIEW IF EXISTS `view_Typology`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Typology` AS select distinct `_typology`.`id` AS `id`,`_typology`.`name` AS `name`,`_typology`.`finalclass` AS `finalclass`,if((`_typology`.`finalclass` = 'IOSVersion'),cast(concat(coalesce(`Brand_brand_id_typology`.`name`,''),coalesce(' ',''),coalesce(`_typology`.`name`,'')) as char charset utf8),cast(concat(coalesce(`_typology`.`name`,'')) as char charset utf8)) AS `friendlyname` from (`typology` `_typology` left join (`iosversion` `_fn_IOSVersion_iosversion` join (`brand` `Brand_brand_id_brand` join `typology` `Brand_brand_id_typology` on((`Brand_brand_id_brand`.`id` = `Brand_brand_id_typology`.`id`))) on((`_fn_IOSVersion_iosversion`.`brand_id` = `Brand_brand_id_brand`.`id`))) on((`_typology`.`id` = `_fn_IOSVersion_iosversion`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_UserRequest`
--

/*!50001 DROP VIEW IF EXISTS `view_UserRequest`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_UserRequest` AS select distinct `_ticket_request`.`id` AS `id`,`_ticket`.`ref` AS `ref`,`_ticket`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,`_ticket`.`caller_id` AS `caller_id`,`Person_caller_id_contact`.`name` AS `caller_name`,`_ticket`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_ticket`.`agent_id` AS `agent_id`,`Person_agent_id_contact`.`name` AS `agent_name`,`_ticket`.`title` AS `title`,`_ticket`.`description` AS `description`,`_ticket`.`start_date` AS `start_date`,`_ticket`.`end_date` AS `end_date`,`_ticket`.`last_update` AS `last_update`,`_ticket`.`close_date` AS `close_date`,`_ticket`.`private_log` AS `private_log`,`_ticket`.`private_log_index` AS `private_log_index`,`_ticket_request`.`status` AS `status`,`_ticket_request`.`request_type` AS `request_type`,`_ticket_request`.`impact` AS `impact`,`_ticket_request`.`priority` AS `priority`,`_ticket_request`.`urgency` AS `urgency`,`_ticket_request`.`origin` AS `origin`,`_ticket_request`.`approver_id` AS `approver_id`,`Person_approver_id_contact`.`email` AS `approver_email`,`_ticket_request`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_ticket_request`.`servicesubcategory_id` AS `servicesubcategory_id`,`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name` AS `servicesubcategory_name`,`_ticket_request`.`escalation_flag` AS `escalation_flag`,`_ticket_request`.`escalation_reason` AS `escalation_reason`,`_ticket_request`.`assignment_date` AS `assignment_date`,`_ticket_request`.`resolution_date` AS `resolution_date`,`_ticket_request`.`last_pending_date` AS `last_pending_date`,`_ticket_request`.`cumulatedpending_timespent` AS `cumulatedpending`,`_ticket_request`.`cumulatedpending_started` AS `cumulatedpending_started`,`_ticket_request`.`cumulatedpending_laststart` AS `cumulatedpending_laststart`,`_ticket_request`.`cumulatedpending_stopped` AS `cumulatedpending_stopped`,`_ticket_request`.`tto_timespent` AS `tto`,`_ticket_request`.`tto_started` AS `tto_started`,`_ticket_request`.`tto_laststart` AS `tto_laststart`,`_ticket_request`.`tto_stopped` AS `tto_stopped`,`_ticket_request`.`tto_75_deadline` AS `tto_75_deadline`,`_ticket_request`.`tto_75_passed` AS `tto_75_passed`,`_ticket_request`.`tto_75_triggered` AS `tto_75_triggered`,`_ticket_request`.`tto_75_overrun` AS `tto_75_overrun`,`_ticket_request`.`tto_100_deadline` AS `tto_100_deadline`,`_ticket_request`.`tto_100_passed` AS `tto_100_passed`,`_ticket_request`.`tto_100_triggered` AS `tto_100_triggered`,`_ticket_request`.`tto_100_overrun` AS `tto_100_overrun`,`_ticket_request`.`ttr_timespent` AS `ttr`,`_ticket_request`.`ttr_started` AS `ttr_started`,`_ticket_request`.`ttr_laststart` AS `ttr_laststart`,`_ticket_request`.`ttr_stopped` AS `ttr_stopped`,`_ticket_request`.`ttr_75_deadline` AS `ttr_75_deadline`,`_ticket_request`.`ttr_75_passed` AS `ttr_75_passed`,`_ticket_request`.`ttr_75_triggered` AS `ttr_75_triggered`,`_ticket_request`.`ttr_75_overrun` AS `ttr_75_overrun`,`_ticket_request`.`ttr_100_deadline` AS `ttr_100_deadline`,`_ticket_request`.`ttr_100_passed` AS `ttr_100_passed`,`_ticket_request`.`ttr_100_triggered` AS `ttr_100_triggered`,`_ticket_request`.`ttr_100_overrun` AS `ttr_100_overrun`,`_ticket_request`.`tto_100_deadline` AS `tto_escalation_deadline`,`_ticket_request`.`tto_100_passed` AS `sla_tto_passed`,`_ticket_request`.`tto_100_overrun` AS `sla_tto_over`,`_ticket_request`.`ttr_100_deadline` AS `ttr_escalation_deadline`,`_ticket_request`.`ttr_100_passed` AS `sla_ttr_passed`,`_ticket_request`.`ttr_100_overrun` AS `sla_ttr_over`,`_ticket_request`.`time_spent` AS `time_spent`,`_ticket_request`.`resolution_code` AS `resolution_code`,`_ticket_request`.`solution` AS `solution`,`_ticket_request`.`pending_reason` AS `pending_reason`,`_ticket_request`.`parent_request_id` AS `parent_request_id`,`UserRequest_parent_request_id_ticket`.`ref` AS `parent_request_ref`,`_ticket_request`.`parent_incident_id` AS `parent_incident_id`,`Incident_parent_incident_id_ticket`.`ref` AS `parent_incident_ref`,`_ticket_request`.`parent_problem_id` AS `parent_problem_id`,`Problem_parent_problem_id_ticket`.`ref` AS `parent_problem_ref`,`_ticket_request`.`parent_change_id` AS `parent_change_id`,`Change_parent_change_id_ticket`.`ref` AS `parent_change_ref`,`_ticket_request`.`public_log` AS `public_log`,`_ticket_request`.`public_log_index` AS `public_log_index`,`_ticket_request`.`user_satisfaction` AS `user_satisfaction`,`_ticket_request`.`user_commment` AS `user_comment`,`_ticket`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_ticket`.`ref`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`Person_caller_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_caller_id_contact`.`name`,'')) as char charset utf8) AS `caller_id_friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname`,cast(concat(coalesce(`Person_approver_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_approver_id_contact`.`name`,'')) as char charset utf8) AS `approver_id_friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`name`,'')) as char charset utf8) AS `servicesubcategory_id_friendlyname`,cast(concat(coalesce(`UserRequest_parent_request_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_request_id_friendlyname`,cast(concat(coalesce(`Incident_parent_incident_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_incident_id_friendlyname`,cast(concat(coalesce(`Problem_parent_problem_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_problem_id_friendlyname`,cast(concat(coalesce(`Change_parent_change_id_ticket`.`ref`,'')) as char charset utf8) AS `parent_change_id_friendlyname`,`Change_parent_change_id_ticket`.`finalclass` AS `parent_change_id_finalclass_recall` from ((((((((`ticket_request` `_ticket_request` left join (`person` `Person_approver_id_person` join `contact` `Person_approver_id_contact` on((`Person_approver_id_person`.`id` = `Person_approver_id_contact`.`id`))) on((`_ticket_request`.`approver_id` = `Person_approver_id_person`.`id`))) left join `service` `Service_service_id_service` on((`_ticket_request`.`service_id` = `Service_service_id_service`.`id`))) left join `servicesubcategory` `ServiceSubcategory_servicesubcategory_id_servicesubcategory` on((`_ticket_request`.`servicesubcategory_id` = `ServiceSubcategory_servicesubcategory_id_servicesubcategory`.`id`))) left join (`ticket_request` `UserRequest_parent_request_id_ticket_request` join `ticket` `UserRequest_parent_request_id_ticket` on((`UserRequest_parent_request_id_ticket_request`.`id` = `UserRequest_parent_request_id_ticket`.`id`))) on((`_ticket_request`.`parent_request_id` = `UserRequest_parent_request_id_ticket_request`.`id`))) left join (`ticket_incident` `Incident_parent_incident_id_ticket_incident` join `ticket` `Incident_parent_incident_id_ticket` on((`Incident_parent_incident_id_ticket_incident`.`id` = `Incident_parent_incident_id_ticket`.`id`))) on((`_ticket_request`.`parent_incident_id` = `Incident_parent_incident_id_ticket_incident`.`id`))) left join (`ticket_problem` `Problem_parent_problem_id_ticket_problem` join `ticket` `Problem_parent_problem_id_ticket` on((`Problem_parent_problem_id_ticket_problem`.`id` = `Problem_parent_problem_id_ticket`.`id`))) on((`_ticket_request`.`parent_problem_id` = `Problem_parent_problem_id_ticket_problem`.`id`))) left join (`change` `Change_parent_change_id_change` join `ticket` `Change_parent_change_id_ticket` on((`Change_parent_change_id_change`.`id` = `Change_parent_change_id_ticket`.`id`))) on((`_ticket_request`.`parent_change_id` = `Change_parent_change_id_change`.`id`))) join ((((`ticket` `_ticket` join `organization` `Organization_org_id_organization` on((`_ticket`.`org_id` = `Organization_org_id_organization`.`id`))) left join (`person` `Person_caller_id_person` join `contact` `Person_caller_id_contact` on((`Person_caller_id_person`.`id` = `Person_caller_id_contact`.`id`))) on((`_ticket`.`caller_id` = `Person_caller_id_person`.`id`))) left join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_ticket`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_ticket`.`agent_id` = `Person_agent_id_person`.`id`))) on((`_ticket_request`.`id` = `_ticket`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VLAN`
--

/*!50001 DROP VIEW IF EXISTS `view_VLAN`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VLAN` AS select distinct `_vlan`.`id` AS `id`,`_vlan`.`vlan_tag` AS `vlan_tag`,`_vlan`.`description` AS `description`,`_vlan`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `org_name`,cast(concat(coalesce(`_vlan`.`vlan_tag`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`vlan` `_vlan` join `organization` `Organization_org_id_organization` on((`_vlan`.`org_id` = `Organization_org_id_organization`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VirtualDevice`
--

/*!50001 DROP VIEW IF EXISTS `view_VirtualDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VirtualDevice` AS select distinct `_virtualdevice`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from (`virtualdevice` `_virtualdevice` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_virtualdevice`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VirtualHost`
--

/*!50001 DROP VIEW IF EXISTS `view_VirtualHost`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VirtualHost` AS select distinct `_virtualhost`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname` from ((`virtualhost` `_virtualhost` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_virtualhost`.`id` = `_functionalci`.`id`))) join `virtualdevice` `_virtualdevice` on((`_virtualhost`.`id` = `_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_VirtualMachine`
--

/*!50001 DROP VIEW IF EXISTS `view_VirtualMachine`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_VirtualMachine` AS select distinct `_virtualmachine`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_virtualdevice`.`status` AS `status`,`_virtualmachine`.`virtualhost_id` AS `virtualhost_id`,`VirtualHost_virtualhost_id_functionalci`.`name` AS `virtualhost_name`,`_virtualmachine`.`osfamily_id` AS `osfamily_id`,`OSFamily_osfamily_id_typology`.`name` AS `osfamily_name`,`_virtualmachine`.`osversion_id` AS `osversion_id`,`OSVersion_osversion_id_typology`.`name` AS `osversion_name`,`_virtualmachine`.`oslicence_id` AS `oslicence_id`,`OSLicence_oslicence_id_licence`.`name` AS `oslicence_name`,`_virtualmachine`.`cpu` AS `cpu`,`_virtualmachine`.`ram` AS `ram`,`_virtualmachine`.`managementip` AS `managementip`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`VirtualHost_virtualhost_id_functionalci`.`name`,'')) as char charset utf8) AS `virtualhost_id_friendlyname`,`VirtualHost_virtualhost_id_functionalci`.`finalclass` AS `virtualhost_id_finalclass_recall`,cast(concat(coalesce(`OSFamily_osfamily_id_typology`.`name`,'')) as char charset utf8) AS `osfamily_id_friendlyname`,cast(concat(coalesce(`OSVersion_osversion_id_typology`.`name`,'')) as char charset utf8) AS `osversion_id_friendlyname`,cast(concat(coalesce(`OSLicence_oslicence_id_licence`.`name`,'')) as char charset utf8) AS `oslicence_id_friendlyname` from ((((((`virtualmachine` `_virtualmachine` join (`virtualhost` `VirtualHost_virtualhost_id_virtualhost` join `functionalci` `VirtualHost_virtualhost_id_functionalci` on((`VirtualHost_virtualhost_id_virtualhost`.`id` = `VirtualHost_virtualhost_id_functionalci`.`id`))) on((`_virtualmachine`.`virtualhost_id` = `VirtualHost_virtualhost_id_virtualhost`.`id`))) left join (`osfamily` `OSFamily_osfamily_id_osfamily` join `typology` `OSFamily_osfamily_id_typology` on((`OSFamily_osfamily_id_osfamily`.`id` = `OSFamily_osfamily_id_typology`.`id`))) on((`_virtualmachine`.`osfamily_id` = `OSFamily_osfamily_id_osfamily`.`id`))) left join (`osversion` `OSVersion_osversion_id_osversion` join `typology` `OSVersion_osversion_id_typology` on((`OSVersion_osversion_id_osversion`.`id` = `OSVersion_osversion_id_typology`.`id`))) on((`_virtualmachine`.`osversion_id` = `OSVersion_osversion_id_osversion`.`id`))) left join (`oslicence` `OSLicence_oslicence_id_oslicence` join `licence` `OSLicence_oslicence_id_licence` on((`OSLicence_oslicence_id_oslicence`.`id` = `OSLicence_oslicence_id_licence`.`id`))) on((`_virtualmachine`.`oslicence_id` = `OSLicence_oslicence_id_oslicence`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_virtualmachine`.`id` = `_functionalci`.`id`))) join `virtualdevice` `_virtualdevice` on((`_virtualmachine`.`id` = `_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_WebApplication`
--

/*!50001 DROP VIEW IF EXISTS `view_WebApplication`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_WebApplication` AS select distinct `_webapplication`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_webapplication`.`webserver_id` AS `webserver_id`,`WebServer_webserver_id_functionalci`.`name` AS `webserver_name`,`_webapplication`.`url` AS `url`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,cast(concat(coalesce(`WebServer_webserver_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `webserver_id_friendlyname` from ((`webapplication` `_webapplication` join ((`webserver` `WebServer_webserver_id_webserver` join `functionalci` `WebServer_webserver_id_functionalci` on((`WebServer_webserver_id_webserver`.`id` = `WebServer_webserver_id_functionalci`.`id`))) join (`softwareinstance` `WebServer_webserver_id_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`WebServer_webserver_id_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`WebServer_webserver_id_webserver`.`id` = `WebServer_webserver_id_softwareinstance`.`id`))) on((`_webapplication`.`webserver_id` = `WebServer_webserver_id_webserver`.`id`))) join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_webapplication`.`id` = `_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_WebServer`
--

/*!50001 DROP VIEW IF EXISTS `view_WebServer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_WebServer` AS select distinct `_webserver`.`id` AS `id`,`_functionalci`.`name` AS `name`,`_functionalci`.`description` AS `description`,`_functionalci`.`org_id` AS `org_id`,`Organization_org_id_organization`.`name` AS `organization_name`,`_functionalci`.`business_criticity` AS `business_criticity`,`_functionalci`.`move2production` AS `move2production`,`_softwareinstance`.`functionalci_id` AS `system_id`,`FunctionalCI_system_id_functionalci`.`name` AS `system_name`,`_softwareinstance`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_softwareinstance`.`softwarelicence_id` AS `softwarelicence_id`,`SoftwareLicence_softwarelicence_id_licence`.`name` AS `softwarelicence_name`,`_softwareinstance`.`path` AS `path`,`_softwareinstance`.`status` AS `status`,`_functionalci`.`finalclass` AS `finalclass`,cast(concat(coalesce(`_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Organization_org_id_organization`.`name`,'')) as char charset utf8) AS `org_id_friendlyname`,if((`FunctionalCI_system_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id1_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8)) AS `system_id_friendlyname`,`FunctionalCI_system_id_functionalci`.`finalclass` AS `system_id_finalclass_recall`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,cast(concat(coalesce(`SoftwareLicence_softwarelicence_id_licence`.`name`,'')) as char charset utf8) AS `softwarelicence_id_friendlyname` from ((`webserver` `_webserver` join (`functionalci` `_functionalci` join `organization` `Organization_org_id_organization` on((`_functionalci`.`org_id` = `Organization_org_id_organization`.`id`))) on((`_webserver`.`id` = `_functionalci`.`id`))) join (((`softwareinstance` `_softwareinstance` join (`functionalci` `FunctionalCI_system_id_functionalci` left join (`softwareinstance` `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id1_functionalci` on((`FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id1_functionalci`.`id`))) on((`FunctionalCI_system_id_functionalci`.`id` = `FunctionalCI_system_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) left join `software` `Software_software_id_software` on((`_softwareinstance`.`software_id` = `Software_software_id_software`.`id`))) left join (`softwarelicence` `SoftwareLicence_softwarelicence_id_softwarelicence` join `licence` `SoftwareLicence_softwarelicence_id_licence` on((`SoftwareLicence_softwarelicence_id_softwarelicence`.`id` = `SoftwareLicence_softwarelicence_id_licence`.`id`))) on((`_softwareinstance`.`softwarelicence_id` = `SoftwareLicence_softwarelicence_id_softwarelicence`.`id`))) on((`_webserver`.`id` = `_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_WorkOrder`
--

/*!50001 DROP VIEW IF EXISTS `view_WorkOrder`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_WorkOrder` AS select distinct `_workorder`.`id` AS `id`,`_workorder`.`name` AS `name`,`_workorder`.`status` AS `status`,`_workorder`.`description` AS `description`,`_workorder`.`ticket_id` AS `ticket_id`,`Ticket_ticket_id_ticket`.`ref` AS `ticket_ref`,`_workorder`.`team_id` AS `team_id`,`Team_team_id_contact`.`email` AS `team_name`,`_workorder`.`owner_id` AS `agent_id`,`Person_agent_id_contact`.`email` AS `agent_email`,`_workorder`.`start_date` AS `start_date`,`_workorder`.`end_date` AS `end_date`,`_workorder`.`log` AS `log`,`_workorder`.`log_index` AS `log_index`,cast(concat(coalesce(`_workorder`.`name`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Ticket_ticket_id_ticket`.`ref`,'')) as char charset utf8) AS `ticket_id_friendlyname`,`Ticket_ticket_id_ticket`.`finalclass` AS `ticket_id_finalclass_recall`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_agent_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_agent_id_contact`.`name`,'')) as char charset utf8) AS `agent_id_friendlyname` from (((`workorder` `_workorder` join `ticket` `Ticket_ticket_id_ticket` on((`_workorder`.`ticket_id` = `Ticket_ticket_id_ticket`.`id`))) join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_workorder`.`team_id` = `Team_team_id_team`.`id`))) left join (`person` `Person_agent_id_person` join `contact` `Person_agent_id_contact` on((`Person_agent_id_person`.`id` = `Person_agent_id_contact`.`id`))) on((`_workorder`.`owner_id` = `Person_agent_id_person`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkApplicationSolutionToBusinessProcess`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkApplicationSolutionToBusinessProcess`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkApplicationSolutionToBusinessProcess` AS select distinct `_lnkapplicationsolutiontobusinessprocess`.`id` AS `id`,`_lnkapplicationsolutiontobusinessprocess`.`businessprocess_id` AS `businessprocess_id`,`BusinessProcess_businessprocess_id_functionalci`.`name` AS `businessprocess_name`,`_lnkapplicationsolutiontobusinessprocess`.`applicationsolution_id` AS `applicationsolution_id`,`ApplicationSolution_applicationsolution_id_functionalci`.`name` AS `applicationsolution_name`,cast(concat(coalesce(`_lnkapplicationsolutiontobusinessprocess`.`businessprocess_id`,''),coalesce(' ',''),coalesce(`_lnkapplicationsolutiontobusinessprocess`.`applicationsolution_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`BusinessProcess_businessprocess_id_functionalci`.`name`,'')) as char charset utf8) AS `businessprocess_id_friendlyname`,cast(concat(coalesce(`ApplicationSolution_applicationsolution_id_functionalci`.`name`,'')) as char charset utf8) AS `applicationsolution_id_friendlyname` from ((`lnkapplicationsolutiontobusinessprocess` `_lnkapplicationsolutiontobusinessprocess` join (`businessprocess` `BusinessProcess_businessprocess_id_businessprocess` join `functionalci` `BusinessProcess_businessprocess_id_functionalci` on((`BusinessProcess_businessprocess_id_businessprocess`.`id` = `BusinessProcess_businessprocess_id_functionalci`.`id`))) on((`_lnkapplicationsolutiontobusinessprocess`.`businessprocess_id` = `BusinessProcess_businessprocess_id_businessprocess`.`id`))) join (`applicationsolution` `ApplicationSolution_applicationsolution_id_applicationsolution` join `functionalci` `ApplicationSolution_applicationsolution_id_functionalci` on((`ApplicationSolution_applicationsolution_id_applicationsolution`.`id` = `ApplicationSolution_applicationsolution_id_functionalci`.`id`))) on((`_lnkapplicationsolutiontobusinessprocess`.`applicationsolution_id` = `ApplicationSolution_applicationsolution_id_applicationsolution`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkApplicationSolutionToFunctionalCI`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkApplicationSolutionToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkApplicationSolutionToFunctionalCI` AS select distinct `_lnkapplicationsolutiontofunctionalci`.`id` AS `id`,`_lnkapplicationsolutiontofunctionalci`.`applicationsolution_id` AS `applicationsolution_id`,`ApplicationSolution_applicationsolution_id_functionalci`.`name` AS `applicationsolution_name`,`_lnkapplicationsolutiontofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,cast(concat(coalesce(`_lnkapplicationsolutiontofunctionalci`.`applicationsolution_id`,''),coalesce(' ',''),coalesce(`_lnkapplicationsolutiontofunctionalci`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`ApplicationSolution_applicationsolution_id_functionalci`.`name`,'')) as char charset utf8) AS `applicationsolution_id_friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkapplicationsolutiontofunctionalci` `_lnkapplicationsolutiontofunctionalci` join (`applicationsolution` `ApplicationSolution_applicationsolution_id_applicationsolution` join `functionalci` `ApplicationSolution_applicationsolution_id_functionalci` on((`ApplicationSolution_applicationsolution_id_applicationsolution`.`id` = `ApplicationSolution_applicationsolution_id_functionalci`.`id`))) on((`_lnkapplicationsolutiontofunctionalci`.`applicationsolution_id` = `ApplicationSolution_applicationsolution_id_applicationsolution`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkapplicationsolutiontofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkConnectableCIToNetworkDevice`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkConnectableCIToNetworkDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkConnectableCIToNetworkDevice` AS select distinct `_lnkconnectablecitonetworkdevice`.`id` AS `id`,`_lnkconnectablecitonetworkdevice`.`networkdevice_id` AS `networkdevice_id`,`NetworkDevice_networkdevice_id_functionalci`.`name` AS `networkdevice_name`,`_lnkconnectablecitonetworkdevice`.`connectableci_id` AS `connectableci_id`,`ConnectableCI_connectableci_id_functionalci`.`name` AS `connectableci_name`,`_lnkconnectablecitonetworkdevice`.`network_port` AS `network_port`,`_lnkconnectablecitonetworkdevice`.`device_port` AS `device_port`,`_lnkconnectablecitonetworkdevice`.`type` AS `connection_type`,cast(concat(coalesce(`_lnkconnectablecitonetworkdevice`.`networkdevice_id`,''),coalesce(' ',''),coalesce(`_lnkconnectablecitonetworkdevice`.`connectableci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`NetworkDevice_networkdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `networkdevice_id_friendlyname`,cast(concat(coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `connectableci_id_friendlyname`,`ConnectableCI_connectableci_id_functionalci`.`finalclass` AS `connectableci_id_finalclass_recall` from ((`lnkconnectablecitonetworkdevice` `_lnkconnectablecitonetworkdevice` join (`networkdevice` `NetworkDevice_networkdevice_id_networkdevice` join `functionalci` `NetworkDevice_networkdevice_id_functionalci` on((`NetworkDevice_networkdevice_id_networkdevice`.`id` = `NetworkDevice_networkdevice_id_functionalci`.`id`))) on((`_lnkconnectablecitonetworkdevice`.`networkdevice_id` = `NetworkDevice_networkdevice_id_networkdevice`.`id`))) join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`_lnkconnectablecitonetworkdevice`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToContract`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkContactToContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToContract` AS select distinct `_lnkcontacttocontract`.`id` AS `id`,`_lnkcontacttocontract`.`contract_id` AS `contract_id`,`Contract_contract_id_contract`.`name` AS `contract_name`,`_lnkcontacttocontract`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,cast(concat(coalesce(`_lnkcontacttocontract`.`contract_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttocontract`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Contract_contract_id_contract`.`name`,'')) as char charset utf8) AS `contract_id_friendlyname`,`Contract_contract_id_contract`.`finalclass` AS `contract_id_finalclass_recall`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttocontract` `_lnkcontacttocontract` join `contract` `Contract_contract_id_contract` on((`_lnkcontacttocontract`.`contract_id` = `Contract_contract_id_contract`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttocontract`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToFunctionalCI`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkContactToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToFunctionalCI` AS select distinct `_lnkcontacttofunctionalci`.`id` AS `id`,`_lnkcontacttofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,`_lnkcontacttofunctionalci`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,cast(concat(coalesce(`_lnkcontacttofunctionalci`.`functionalci_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttofunctionalci`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttofunctionalci` `_lnkcontacttofunctionalci` join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkcontacttofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttofunctionalci`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToService`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkContactToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToService` AS select distinct `_lnkcontacttoservice`.`id` AS `id`,`_lnkcontacttoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkcontacttoservice`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,cast(concat(coalesce(`_lnkcontacttoservice`.`service_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttoservice`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttoservice` `_lnkcontacttoservice` join `service` `Service_service_id_service` on((`_lnkcontacttoservice`.`service_id` = `Service_service_id_service`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttoservice`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContactToTicket`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkContactToTicket`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContactToTicket` AS select distinct `_lnkcontacttoticket`.`id` AS `id`,`_lnkcontacttoticket`.`ticket_id` AS `ticket_id`,`Ticket_ticket_id_ticket`.`ref` AS `ticket_ref`,`_lnkcontacttoticket`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`email` AS `contact_email`,`_lnkcontacttoticket`.`role` AS `role`,cast(concat(coalesce(`_lnkcontacttoticket`.`ticket_id`,''),coalesce(' ',''),coalesce(`_lnkcontacttoticket`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Ticket_ticket_id_ticket`.`ref`,'')) as char charset utf8) AS `ticket_id_friendlyname`,`Ticket_ticket_id_ticket`.`finalclass` AS `ticket_id_finalclass_recall`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall` from ((`lnkcontacttoticket` `_lnkcontacttoticket` join `ticket` `Ticket_ticket_id_ticket` on((`_lnkcontacttoticket`.`ticket_id` = `Ticket_ticket_id_ticket`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkcontacttoticket`.`contact_id` = `Contact_contact_id_contact`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkContractToDocument`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkContractToDocument`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkContractToDocument` AS select distinct `_lnkcontracttodocument`.`id` AS `id`,`_lnkcontracttodocument`.`contract_id` AS `contract_id`,`Contract_contract_id_contract`.`name` AS `contract_name`,`_lnkcontracttodocument`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkcontracttodocument`.`contract_id`,''),coalesce(' ',''),coalesce(`_lnkcontracttodocument`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Contract_contract_id_contract`.`name`,'')) as char charset utf8) AS `contract_id_friendlyname`,`Contract_contract_id_contract`.`finalclass` AS `contract_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkcontracttodocument` `_lnkcontracttodocument` join `contract` `Contract_contract_id_contract` on((`_lnkcontracttodocument`.`contract_id` = `Contract_contract_id_contract`.`id`))) join `document` `Document_document_id_document` on((`_lnkcontracttodocument`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkCustomerContractToFunctionalCI`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkCustomerContractToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkCustomerContractToFunctionalCI` AS select distinct `_lnkcustomercontracttofunctionalci`.`id` AS `id`,`_lnkcustomercontracttofunctionalci`.`customercontract_id` AS `customercontract_id`,`CustomerContract_customercontract_id_contract`.`name` AS `customercontract_name`,`_lnkcustomercontracttofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,cast(concat(coalesce(`_lnkcustomercontracttofunctionalci`.`customercontract_id`,''),coalesce(' ',''),coalesce(`_lnkcustomercontracttofunctionalci`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`CustomerContract_customercontract_id_contract`.`name`,'')) as char charset utf8) AS `customercontract_id_friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkcustomercontracttofunctionalci` `_lnkcustomercontracttofunctionalci` join (`customercontract` `CustomerContract_customercontract_id_customercontract` join `contract` `CustomerContract_customercontract_id_contract` on((`CustomerContract_customercontract_id_customercontract`.`id` = `CustomerContract_customercontract_id_contract`.`id`))) on((`_lnkcustomercontracttofunctionalci`.`customercontract_id` = `CustomerContract_customercontract_id_customercontract`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkcustomercontracttofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkCustomerContractToProviderContract`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkCustomerContractToProviderContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkCustomerContractToProviderContract` AS select distinct `_lnkcustomercontracttoprovidercontract`.`id` AS `id`,`_lnkcustomercontracttoprovidercontract`.`customercontract_id` AS `customercontract_id`,`CustomerContract_customercontract_id_contract`.`name` AS `customercontract_name`,`_lnkcustomercontracttoprovidercontract`.`providercontract_id` AS `providercontract_id`,`ProviderContract_providercontract_id_contract`.`name` AS `providercontract_name`,cast(concat(coalesce(`_lnkcustomercontracttoprovidercontract`.`customercontract_id`,''),coalesce(' ',''),coalesce(`_lnkcustomercontracttoprovidercontract`.`providercontract_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`CustomerContract_customercontract_id_contract`.`name`,'')) as char charset utf8) AS `customercontract_id_friendlyname`,cast(concat(coalesce(`ProviderContract_providercontract_id_contract`.`name`,'')) as char charset utf8) AS `providercontract_id_friendlyname` from ((`lnkcustomercontracttoprovidercontract` `_lnkcustomercontracttoprovidercontract` join (`customercontract` `CustomerContract_customercontract_id_customercontract` join `contract` `CustomerContract_customercontract_id_contract` on((`CustomerContract_customercontract_id_customercontract`.`id` = `CustomerContract_customercontract_id_contract`.`id`))) on((`_lnkcustomercontracttoprovidercontract`.`customercontract_id` = `CustomerContract_customercontract_id_customercontract`.`id`))) join (`providercontract` `ProviderContract_providercontract_id_providercontract` join `contract` `ProviderContract_providercontract_id_contract` on((`ProviderContract_providercontract_id_providercontract`.`id` = `ProviderContract_providercontract_id_contract`.`id`))) on((`_lnkcustomercontracttoprovidercontract`.`providercontract_id` = `ProviderContract_providercontract_id_providercontract`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkCustomerContractToService`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkCustomerContractToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkCustomerContractToService` AS select distinct `_lnkcustomercontracttoservice`.`id` AS `id`,`_lnkcustomercontracttoservice`.`customercontract_id` AS `customercontract_id`,`CustomerContract_customercontract_id_contract`.`name` AS `customercontract_name`,`_lnkcustomercontracttoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkcustomercontracttoservice`.`sla_id` AS `sla_id`,`SLA_sla_id_sla`.`name` AS `sla_name`,cast(concat(coalesce(`_lnkcustomercontracttoservice`.`customercontract_id`,''),coalesce(' ',''),coalesce(`_lnkcustomercontracttoservice`.`service_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`CustomerContract_customercontract_id_contract`.`name`,'')) as char charset utf8) AS `customercontract_id_friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,cast(concat(coalesce(`SLA_sla_id_sla`.`name`,'')) as char charset utf8) AS `sla_id_friendlyname` from (((`lnkcustomercontracttoservice` `_lnkcustomercontracttoservice` join (`customercontract` `CustomerContract_customercontract_id_customercontract` join `contract` `CustomerContract_customercontract_id_contract` on((`CustomerContract_customercontract_id_customercontract`.`id` = `CustomerContract_customercontract_id_contract`.`id`))) on((`_lnkcustomercontracttoservice`.`customercontract_id` = `CustomerContract_customercontract_id_customercontract`.`id`))) join `service` `Service_service_id_service` on((`_lnkcustomercontracttoservice`.`service_id` = `Service_service_id_service`.`id`))) left join `sla` `SLA_sla_id_sla` on((`_lnkcustomercontracttoservice`.`sla_id` = `SLA_sla_id_sla`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDeliveryModelToContact`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDeliveryModelToContact`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDeliveryModelToContact` AS select distinct `_lnkdeliverymodeltocontact`.`id` AS `id`,`_lnkdeliverymodeltocontact`.`deliverymodel_id` AS `deliverymodel_id`,`DeliveryModel_deliverymodel_id_deliverymodel`.`name` AS `deliverymodel_name`,`_lnkdeliverymodeltocontact`.`contact_id` AS `contact_id`,`Contact_contact_id_contact`.`name` AS `contact_name`,`_lnkdeliverymodeltocontact`.`role_id` AS `role_id`,`ContactType_role_id_typology`.`name` AS `role_name`,cast(concat(coalesce(`_lnkdeliverymodeltocontact`.`deliverymodel_id`,''),coalesce(' ',''),coalesce(`_lnkdeliverymodeltocontact`.`contact_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`DeliveryModel_deliverymodel_id_deliverymodel`.`name`,'')) as char charset utf8) AS `deliverymodel_id_friendlyname`,if((`Contact_contact_id_contact`.`finalclass` in ('Team','Contact')),cast(concat(coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8),cast(concat(coalesce(`Contact_contact_id_fn_Person_person`.`first_name`,''),coalesce(' ',''),coalesce(`Contact_contact_id_contact`.`name`,'')) as char charset utf8)) AS `contact_id_friendlyname`,`Contact_contact_id_contact`.`finalclass` AS `contact_id_finalclass_recall`,cast(concat(coalesce(`ContactType_role_id_typology`.`name`,'')) as char charset utf8) AS `role_id_friendlyname` from (((`lnkdeliverymodeltocontact` `_lnkdeliverymodeltocontact` join `deliverymodel` `DeliveryModel_deliverymodel_id_deliverymodel` on((`_lnkdeliverymodeltocontact`.`deliverymodel_id` = `DeliveryModel_deliverymodel_id_deliverymodel`.`id`))) join (`contact` `Contact_contact_id_contact` left join `person` `Contact_contact_id_fn_Person_person` on((`Contact_contact_id_contact`.`id` = `Contact_contact_id_fn_Person_person`.`id`))) on((`_lnkdeliverymodeltocontact`.`contact_id` = `Contact_contact_id_contact`.`id`))) left join (`contacttype` `ContactType_role_id_contacttype` join `typology` `ContactType_role_id_typology` on((`ContactType_role_id_contacttype`.`id` = `ContactType_role_id_typology`.`id`))) on((`_lnkdeliverymodeltocontact`.`role_id` = `ContactType_role_id_contacttype`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToError`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToError`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToError` AS select distinct `_lnkdocumenttoerror`.`link_id` AS `id`,`_lnkdocumenttoerror`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,`_lnkdocumenttoerror`.`error_id` AS `error_id`,`KnownError_error_id_knownerror`.`name` AS `error_name`,`_lnkdocumenttoerror`.`link_type` AS `link_type`,cast(concat(coalesce(`_lnkdocumenttoerror`.`link_type`,'')) as char charset utf8) AS `friendlyname`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall`,cast(concat(coalesce(`KnownError_error_id_knownerror`.`name`,'')) as char charset utf8) AS `error_id_friendlyname` from ((`lnkdocumenttoerror` `_lnkdocumenttoerror` join `document` `Document_document_id_document` on((`_lnkdocumenttoerror`.`document_id` = `Document_document_id_document`.`id`))) join `knownerror` `KnownError_error_id_knownerror` on((`_lnkdocumenttoerror`.`error_id` = `KnownError_error_id_knownerror`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToFunctionalCI`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToFunctionalCI` AS select distinct `_lnkdocumenttofunctionalci`.`id` AS `id`,`_lnkdocumenttofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,`_lnkdocumenttofunctionalci`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttofunctionalci`.`functionalci_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttofunctionalci`.`document_id`,'')) as char charset utf8) AS `friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttofunctionalci` `_lnkdocumenttofunctionalci` join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkdocumenttofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttofunctionalci`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToLicence`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToLicence`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToLicence` AS select distinct `_lnkdocumenttolicence`.`id` AS `id`,`_lnkdocumenttolicence`.`licence_id` AS `licence_id`,`Licence_licence_id_licence`.`name` AS `licence_name`,`_lnkdocumenttolicence`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttolicence`.`licence_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttolicence`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Licence_licence_id_licence`.`name`,'')) as char charset utf8) AS `licence_id_friendlyname`,`Licence_licence_id_licence`.`finalclass` AS `licence_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttolicence` `_lnkdocumenttolicence` join `licence` `Licence_licence_id_licence` on((`_lnkdocumenttolicence`.`licence_id` = `Licence_licence_id_licence`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttolicence`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToPatch`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToPatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToPatch` AS select distinct `_lnkdocumenttopatch`.`id` AS `id`,`_lnkdocumenttopatch`.`patch_id` AS `patch_id`,`Patch_patch_id_patch`.`name` AS `patch_name`,`_lnkdocumenttopatch`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttopatch`.`patch_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttopatch`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Patch_patch_id_patch`.`name`,'')) as char charset utf8) AS `patch_id_friendlyname`,`Patch_patch_id_patch`.`finalclass` AS `patch_id_finalclass_recall`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttopatch` `_lnkdocumenttopatch` join `patch` `Patch_patch_id_patch` on((`_lnkdocumenttopatch`.`patch_id` = `Patch_patch_id_patch`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttopatch`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToService`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToService`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToService` AS select distinct `_lnkdocumenttoservice`.`id` AS `id`,`_lnkdocumenttoservice`.`service_id` AS `service_id`,`Service_service_id_service`.`name` AS `service_name`,`_lnkdocumenttoservice`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttoservice`.`service_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttoservice`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Service_service_id_service`.`name`,'')) as char charset utf8) AS `service_id_friendlyname`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttoservice` `_lnkdocumenttoservice` join `service` `Service_service_id_service` on((`_lnkdocumenttoservice`.`service_id` = `Service_service_id_service`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttoservice`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkDocumentToSoftware`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkDocumentToSoftware`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkDocumentToSoftware` AS select distinct `_lnkdocumenttosoftware`.`id` AS `id`,`_lnkdocumenttosoftware`.`software_id` AS `software_id`,`Software_software_id_software`.`name` AS `software_name`,`_lnkdocumenttosoftware`.`document_id` AS `document_id`,`Document_document_id_document`.`name` AS `document_name`,cast(concat(coalesce(`_lnkdocumenttosoftware`.`software_id`,''),coalesce(' ',''),coalesce(`_lnkdocumenttosoftware`.`document_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Software_software_id_software`.`name`,''),coalesce(' ',''),coalesce(`Software_software_id_software`.`version`,'')) as char charset utf8) AS `software_id_friendlyname`,if((`Document_document_id_document`.`finalclass` = 'Document'),cast(concat(coalesce('Document','')) as char charset utf8),cast(concat(coalesce(`Document_document_id_document`.`name`,'')) as char charset utf8)) AS `document_id_friendlyname`,`Document_document_id_document`.`finalclass` AS `document_id_finalclass_recall` from ((`lnkdocumenttosoftware` `_lnkdocumenttosoftware` join `software` `Software_software_id_software` on((`_lnkdocumenttosoftware`.`software_id` = `Software_software_id_software`.`id`))) join `document` `Document_document_id_document` on((`_lnkdocumenttosoftware`.`document_id` = `Document_document_id_document`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkErrorToFunctionalCI`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkErrorToFunctionalCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkErrorToFunctionalCI` AS select distinct `_lnkerrortofunctionalci`.`link_id` AS `id`,`_lnkerrortofunctionalci`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,`_lnkerrortofunctionalci`.`error_id` AS `error_id`,`KnownError_error_id_knownerror`.`name` AS `error_name`,`_lnkerrortofunctionalci`.`dummy` AS `reason`,cast(concat(coalesce('lnkErrorToFunctionalCI','')) as char charset utf8) AS `friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall`,cast(concat(coalesce(`KnownError_error_id_knownerror`.`name`,'')) as char charset utf8) AS `error_id_friendlyname` from ((`lnkerrortofunctionalci` `_lnkerrortofunctionalci` join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkerrortofunctionalci`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) join `knownerror` `KnownError_error_id_knownerror` on((`_lnkerrortofunctionalci`.`error_id` = `KnownError_error_id_knownerror`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkFunctionalCIToOSPatch`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToOSPatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkFunctionalCIToOSPatch` AS select distinct `_lnkfunctionalcitoospatch`.`id` AS `id`,`_lnkfunctionalcitoospatch`.`ospatch_id` AS `ospatch_id`,`OSPatch_ospatch_id_patch`.`name` AS `ospatch_name`,`_lnkfunctionalcitoospatch`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,cast(concat(coalesce(`_lnkfunctionalcitoospatch`.`ospatch_id`,''),coalesce(' ',''),coalesce(`_lnkfunctionalcitoospatch`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`OSPatch_ospatch_id_patch`.`name`,'')) as char charset utf8) AS `ospatch_id_friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkfunctionalcitoospatch` `_lnkfunctionalcitoospatch` join (`ospatch` `OSPatch_ospatch_id_ospatch` join `patch` `OSPatch_ospatch_id_patch` on((`OSPatch_ospatch_id_ospatch`.`id` = `OSPatch_ospatch_id_patch`.`id`))) on((`_lnkfunctionalcitoospatch`.`ospatch_id` = `OSPatch_ospatch_id_ospatch`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkfunctionalcitoospatch`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkFunctionalCIToProviderContract`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToProviderContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkFunctionalCIToProviderContract` AS select distinct `_lnkfunctionalcitoprovidercontract`.`id` AS `id`,`_lnkfunctionalcitoprovidercontract`.`providercontract_id` AS `providercontract_id`,`ProviderContract_providercontract_id_contract`.`name` AS `providercontract_name`,`_lnkfunctionalcitoprovidercontract`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,cast(concat(coalesce(`_lnkfunctionalcitoprovidercontract`.`providercontract_id`,''),coalesce(' ',''),coalesce(`_lnkfunctionalcitoprovidercontract`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`ProviderContract_providercontract_id_contract`.`name`,'')) as char charset utf8) AS `providercontract_id_friendlyname`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkfunctionalcitoprovidercontract` `_lnkfunctionalcitoprovidercontract` join (`providercontract` `ProviderContract_providercontract_id_providercontract` join `contract` `ProviderContract_providercontract_id_contract` on((`ProviderContract_providercontract_id_providercontract`.`id` = `ProviderContract_providercontract_id_contract`.`id`))) on((`_lnkfunctionalcitoprovidercontract`.`providercontract_id` = `ProviderContract_providercontract_id_providercontract`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkfunctionalcitoprovidercontract`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkFunctionalCIToTicket`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkFunctionalCIToTicket`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkFunctionalCIToTicket` AS select distinct `_lnkfunctionalcitoticket`.`id` AS `id`,`_lnkfunctionalcitoticket`.`ticket_id` AS `ticket_id`,`Ticket_ticket_id_ticket`.`ref` AS `ticket_ref`,`Ticket_ticket_id_ticket`.`title` AS `ticket_title`,`_lnkfunctionalcitoticket`.`functionalci_id` AS `functionalci_id`,`FunctionalCI_functionalci_id_functionalci`.`name` AS `functionalci_name`,`_lnkfunctionalcitoticket`.`impact` AS `impact`,cast(concat(coalesce(`_lnkfunctionalcitoticket`.`ticket_id`,''),coalesce(' ',''),coalesce(`_lnkfunctionalcitoticket`.`functionalci_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Ticket_ticket_id_ticket`.`ref`,'')) as char charset utf8) AS `ticket_id_friendlyname`,`Ticket_ticket_id_ticket`.`finalclass` AS `ticket_id_finalclass_recall`,if((`FunctionalCI_functionalci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_functionalci_id_functionalci`.`name`,'')) as char charset utf8)) AS `functionalci_id_friendlyname`,`FunctionalCI_functionalci_id_functionalci`.`finalclass` AS `functionalci_id_finalclass_recall` from ((`lnkfunctionalcitoticket` `_lnkfunctionalcitoticket` join `ticket` `Ticket_ticket_id_ticket` on((`_lnkfunctionalcitoticket`.`ticket_id` = `Ticket_ticket_id_ticket`.`id`))) join (`functionalci` `FunctionalCI_functionalci_id_functionalci` left join (`softwareinstance` `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_functionalci_id_functionalci`.`id` = `FunctionalCI_functionalci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkfunctionalcitoticket`.`functionalci_id` = `FunctionalCI_functionalci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkGroupToCI`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkGroupToCI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkGroupToCI` AS select distinct `_lnkgrouptoci`.`id` AS `id`,`_lnkgrouptoci`.`group_id` AS `group_id`,`Group_group_id_group`.`name` AS `group_name`,`_lnkgrouptoci`.`ci_id` AS `ci_id`,`FunctionalCI_ci_id_functionalci`.`name` AS `ci_name`,`_lnkgrouptoci`.`reason` AS `reason`,cast(concat(coalesce(`_lnkgrouptoci`.`group_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Group_group_id_group`.`name`,'')) as char charset utf8) AS `group_id_friendlyname`,if((`FunctionalCI_ci_id_functionalci`.`finalclass` in ('Middleware','DBServer','WebServer','PCSoftware','OtherSoftware')),cast(concat(coalesce(`FunctionalCI_ci_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8),cast(concat(coalesce(`FunctionalCI_ci_id_functionalci`.`name`,'')) as char charset utf8)) AS `ci_id_friendlyname`,`FunctionalCI_ci_id_functionalci`.`finalclass` AS `ci_id_finalclass_recall` from ((`lnkgrouptoci` `_lnkgrouptoci` join `group` `Group_group_id_group` on((`_lnkgrouptoci`.`group_id` = `Group_group_id_group`.`id`))) join (`functionalci` `FunctionalCI_ci_id_functionalci` left join (`softwareinstance` `FunctionalCI_ci_id_fn_SoftwareInstance_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`FunctionalCI_ci_id_fn_SoftwareInstance_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) on((`FunctionalCI_ci_id_functionalci`.`id` = `FunctionalCI_ci_id_fn_SoftwareInstance_softwareinstance`.`id`))) on((`_lnkgrouptoci`.`ci_id` = `FunctionalCI_ci_id_functionalci`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkPersonToTeam`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkPersonToTeam`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkPersonToTeam` AS select distinct `_lnkpersontoteam`.`id` AS `id`,`_lnkpersontoteam`.`team_id` AS `team_id`,`Team_team_id_contact`.`name` AS `team_name`,`_lnkpersontoteam`.`person_id` AS `person_id`,`Person_person_id_contact`.`name` AS `person_name`,`_lnkpersontoteam`.`role_id` AS `role_id`,`ContactType_role_id_typology`.`name` AS `role_name`,cast(concat(coalesce(`_lnkpersontoteam`.`team_id`,''),coalesce(' ',''),coalesce(`_lnkpersontoteam`.`person_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Team_team_id_contact`.`name`,'')) as char charset utf8) AS `team_id_friendlyname`,cast(concat(coalesce(`Person_person_id_person`.`first_name`,''),coalesce(' ',''),coalesce(`Person_person_id_contact`.`name`,'')) as char charset utf8) AS `person_id_friendlyname`,cast(concat(coalesce(`ContactType_role_id_typology`.`name`,'')) as char charset utf8) AS `role_id_friendlyname` from (((`lnkpersontoteam` `_lnkpersontoteam` join (`team` `Team_team_id_team` join `contact` `Team_team_id_contact` on((`Team_team_id_team`.`id` = `Team_team_id_contact`.`id`))) on((`_lnkpersontoteam`.`team_id` = `Team_team_id_team`.`id`))) join (`person` `Person_person_id_person` join `contact` `Person_person_id_contact` on((`Person_person_id_person`.`id` = `Person_person_id_contact`.`id`))) on((`_lnkpersontoteam`.`person_id` = `Person_person_id_person`.`id`))) left join (`contacttype` `ContactType_role_id_contacttype` join `typology` `ContactType_role_id_typology` on((`ContactType_role_id_contacttype`.`id` = `ContactType_role_id_typology`.`id`))) on((`_lnkpersontoteam`.`role_id` = `ContactType_role_id_contacttype`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkPhysicalInterfaceToVLAN`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkPhysicalInterfaceToVLAN`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkPhysicalInterfaceToVLAN` AS select distinct `_lnkphysicalinterfacetovlan`.`id` AS `id`,`_lnkphysicalinterfacetovlan`.`physicalinterface_id` AS `physicalinterface_id`,`PhysicalInterface_physicalinterface_id_networkinterface`.`name` AS `physicalinterface_name`,`PhysicalInterface_physicalinterface_id_physicalinterface`.`connectableci_id` AS `physicalinterface_device_id`,`ConnectableCI_connectableci_id_functionalci`.`name` AS `physicalinterface_device_name`,`_lnkphysicalinterfacetovlan`.`vlan_id` AS `vlan_id`,`VLAN_vlan_id_vlan`.`vlan_tag` AS `vlan_tag`,cast(concat(coalesce(`_lnkphysicalinterfacetovlan`.`physicalinterface_id`,''),coalesce(' ',''),coalesce(`_lnkphysicalinterfacetovlan`.`vlan_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`PhysicalInterface_physicalinterface_id_networkinterface`.`name`,''),coalesce(' ',''),coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `physicalinterface_id_friendlyname`,cast(concat(coalesce(`ConnectableCI_connectableci_id_functionalci`.`name`,'')) as char charset utf8) AS `physicalinterface_device_id_friendlyname`,cast(concat(coalesce(`VLAN_vlan_id_vlan`.`vlan_tag`,'')) as char charset utf8) AS `vlan_id_friendlyname` from ((`lnkphysicalinterfacetovlan` `_lnkphysicalinterfacetovlan` join ((`physicalinterface` `PhysicalInterface_physicalinterface_id_physicalinterface` join (`connectableci` `ConnectableCI_connectableci_id_connectableci` join `functionalci` `ConnectableCI_connectableci_id_functionalci` on((`ConnectableCI_connectableci_id_connectableci`.`id` = `ConnectableCI_connectableci_id_functionalci`.`id`))) on((`PhysicalInterface_physicalinterface_id_physicalinterface`.`connectableci_id` = `ConnectableCI_connectableci_id_connectableci`.`id`))) join `networkinterface` `PhysicalInterface_physicalinterface_id_networkinterface` on((`PhysicalInterface_physicalinterface_id_physicalinterface`.`id` = `PhysicalInterface_physicalinterface_id_networkinterface`.`id`))) on((`_lnkphysicalinterfacetovlan`.`physicalinterface_id` = `PhysicalInterface_physicalinterface_id_physicalinterface`.`id`))) join `vlan` `VLAN_vlan_id_vlan` on((`_lnkphysicalinterfacetovlan`.`vlan_id` = `VLAN_vlan_id_vlan`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkSLAToSLT`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkSLAToSLT`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkSLAToSLT` AS select distinct `_lnkslatoslt`.`id` AS `id`,`_lnkslatoslt`.`sla_id` AS `sla_id`,`SLA_sla_id_sla`.`name` AS `sla_name`,`_lnkslatoslt`.`slt_id` AS `slt_id`,`SLT_slt_id_slt`.`name` AS `slt_name`,`SLT_slt_id_slt`.`metric` AS `slt_metric`,`SLT_slt_id_slt`.`request_type` AS `slt_request_type`,`SLT_slt_id_slt`.`priority` AS `slt_ticket_priority`,`SLT_slt_id_slt`.`value` AS `slt_value`,`SLT_slt_id_slt`.`unit` AS `slt_value_unit`,cast(concat(coalesce(`_lnkslatoslt`.`sla_id`,''),coalesce(' ',''),coalesce(`_lnkslatoslt`.`slt_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`SLA_sla_id_sla`.`name`,'')) as char charset utf8) AS `sla_id_friendlyname`,cast(concat(coalesce(`SLT_slt_id_slt`.`name`,'')) as char charset utf8) AS `slt_id_friendlyname` from ((`lnkslatoslt` `_lnkslatoslt` join `sla` `SLA_sla_id_sla` on((`_lnkslatoslt`.`sla_id` = `SLA_sla_id_sla`.`id`))) join `slt` `SLT_slt_id_slt` on((`_lnkslatoslt`.`slt_id` = `SLT_slt_id_slt`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkSanToDatacenterDevice`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkSanToDatacenterDevice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkSanToDatacenterDevice` AS select distinct `_lnkdatacenterdevicetosan`.`id` AS `id`,`_lnkdatacenterdevicetosan`.`san_id` AS `san_id`,`SANSwitch_san_id_functionalci`.`name` AS `san_name`,`_lnkdatacenterdevicetosan`.`datacenterdevice_id` AS `datacenterdevice_id`,`DatacenterDevice_datacenterdevice_id_functionalci`.`name` AS `datacenterdevice_name`,`_lnkdatacenterdevicetosan`.`san_port` AS `san_port`,`_lnkdatacenterdevicetosan`.`datacenterdevice_port` AS `datacenterdevice_port`,cast(concat(coalesce(`_lnkdatacenterdevicetosan`.`san_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`SANSwitch_san_id_functionalci`.`name`,'')) as char charset utf8) AS `san_id_friendlyname`,cast(concat(coalesce(`DatacenterDevice_datacenterdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `datacenterdevice_id_friendlyname`,`DatacenterDevice_datacenterdevice_id_functionalci`.`finalclass` AS `datacenterdevice_id_finalclass_recall` from ((`lnkdatacenterdevicetosan` `_lnkdatacenterdevicetosan` join (`sanswitch` `SANSwitch_san_id_sanswitch` join `functionalci` `SANSwitch_san_id_functionalci` on((`SANSwitch_san_id_sanswitch`.`id` = `SANSwitch_san_id_functionalci`.`id`))) on((`_lnkdatacenterdevicetosan`.`san_id` = `SANSwitch_san_id_sanswitch`.`id`))) join (`datacenterdevice` `DatacenterDevice_datacenterdevice_id_datacenterdevice` join `functionalci` `DatacenterDevice_datacenterdevice_id_functionalci` on((`DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id` = `DatacenterDevice_datacenterdevice_id_functionalci`.`id`))) on((`_lnkdatacenterdevicetosan`.`datacenterdevice_id` = `DatacenterDevice_datacenterdevice_id_datacenterdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkServerToVolume`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkServerToVolume`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkServerToVolume` AS select distinct `_lnkservertovolume`.`id` AS `id`,`_lnkservertovolume`.`volume_id` AS `volume_id`,`LogicalVolume_volume_id_logicalvolume`.`name` AS `volume_name`,`_lnkservertovolume`.`server_id` AS `server_id`,`Server_server_id_functionalci`.`name` AS `server_name`,`_lnkservertovolume`.`size_used` AS `size_used`,cast(concat(coalesce(`_lnkservertovolume`.`volume_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`StorageSystem_storagesystem_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`LogicalVolume_volume_id_logicalvolume`.`name`,'')) as char charset utf8) AS `volume_id_friendlyname`,cast(concat(coalesce(`Server_server_id_functionalci`.`name`,'')) as char charset utf8) AS `server_id_friendlyname` from ((`lnkservertovolume` `_lnkservertovolume` join (`logicalvolume` `LogicalVolume_volume_id_logicalvolume` join (`storagesystem` `StorageSystem_storagesystem_id_storagesystem` join `functionalci` `StorageSystem_storagesystem_id_functionalci` on((`StorageSystem_storagesystem_id_storagesystem`.`id` = `StorageSystem_storagesystem_id_functionalci`.`id`))) on((`LogicalVolume_volume_id_logicalvolume`.`storagesystem_id` = `StorageSystem_storagesystem_id_storagesystem`.`id`))) on((`_lnkservertovolume`.`volume_id` = `LogicalVolume_volume_id_logicalvolume`.`id`))) join (`server` `Server_server_id_server` join `functionalci` `Server_server_id_functionalci` on((`Server_server_id_server`.`id` = `Server_server_id_functionalci`.`id`))) on((`_lnkservertovolume`.`server_id` = `Server_server_id_server`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkSoftwareInstanceToSoftwarePatch`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkSoftwareInstanceToSoftwarePatch`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkSoftwareInstanceToSoftwarePatch` AS select distinct `_lnksoftwareinstancetosoftwarepatch`.`id` AS `id`,`_lnksoftwareinstancetosoftwarepatch`.`softwarepatch_id` AS `softwarepatch_id`,`SoftwarePatch_softwarepatch_id_patch`.`name` AS `softwarepatch_name`,`_lnksoftwareinstancetosoftwarepatch`.`softwareinstance_id` AS `softwareinstance_id`,`SoftwareInstance_softwareinstance_id_functionalci`.`name` AS `softwareinstance_name`,cast(concat(coalesce(`_lnksoftwareinstancetosoftwarepatch`.`softwarepatch_id`,''),coalesce(' ',''),coalesce(`_lnksoftwareinstancetosoftwarepatch`.`softwareinstance_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`SoftwarePatch_softwarepatch_id_patch`.`name`,'')) as char charset utf8) AS `softwarepatch_id_friendlyname`,cast(concat(coalesce(`SoftwareInstance_softwareinstance_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`FunctionalCI_system_id_functionalci`.`name`,'')) as char charset utf8) AS `softwareinstance_id_friendlyname`,`SoftwareInstance_softwareinstance_id_functionalci`.`finalclass` AS `softwareinstance_id_finalclass_recall` from ((`lnksoftwareinstancetosoftwarepatch` `_lnksoftwareinstancetosoftwarepatch` join (`softwarepatch` `SoftwarePatch_softwarepatch_id_softwarepatch` join `patch` `SoftwarePatch_softwarepatch_id_patch` on((`SoftwarePatch_softwarepatch_id_softwarepatch`.`id` = `SoftwarePatch_softwarepatch_id_patch`.`id`))) on((`_lnksoftwareinstancetosoftwarepatch`.`softwarepatch_id` = `SoftwarePatch_softwarepatch_id_softwarepatch`.`id`))) join ((`softwareinstance` `SoftwareInstance_softwareinstance_id_softwareinstance` join `functionalci` `FunctionalCI_system_id_functionalci` on((`SoftwareInstance_softwareinstance_id_softwareinstance`.`functionalci_id` = `FunctionalCI_system_id_functionalci`.`id`))) join `functionalci` `SoftwareInstance_softwareinstance_id_functionalci` on((`SoftwareInstance_softwareinstance_id_softwareinstance`.`id` = `SoftwareInstance_softwareinstance_id_functionalci`.`id`))) on((`_lnksoftwareinstancetosoftwarepatch`.`softwareinstance_id` = `SoftwareInstance_softwareinstance_id_softwareinstance`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkSubnetToVLAN`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkSubnetToVLAN`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkSubnetToVLAN` AS select distinct `_lnksubnettovlan`.`id` AS `id`,`_lnksubnettovlan`.`subnet_id` AS `subnet_id`,`Subnet_subnet_id_subnet`.`ip` AS `subnet_ip`,`Subnet_subnet_id_subnet`.`subnet_name` AS `subnet_name`,`_lnksubnettovlan`.`vlan_id` AS `vlan_id`,`VLAN_vlan_id_vlan`.`vlan_tag` AS `vlan_tag`,cast(concat(coalesce(`_lnksubnettovlan`.`subnet_id`,''),coalesce(' ',''),coalesce(`_lnksubnettovlan`.`vlan_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Subnet_subnet_id_subnet`.`ip`,''),coalesce(' ',''),coalesce(`Subnet_subnet_id_subnet`.`ip_mask`,'')) as char charset utf8) AS `subnet_id_friendlyname`,cast(concat(coalesce(`VLAN_vlan_id_vlan`.`vlan_tag`,'')) as char charset utf8) AS `vlan_id_friendlyname` from ((`lnksubnettovlan` `_lnksubnettovlan` join `subnet` `Subnet_subnet_id_subnet` on((`_lnksubnettovlan`.`subnet_id` = `Subnet_subnet_id_subnet`.`id`))) join `vlan` `VLAN_vlan_id_vlan` on((`_lnksubnettovlan`.`vlan_id` = `VLAN_vlan_id_vlan`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkTriggerAction`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkTriggerAction`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkTriggerAction` AS select distinct `_priv_link_action_trigger`.`link_id` AS `id`,`_priv_link_action_trigger`.`action_id` AS `action_id`,`Action_action_id_priv_action`.`name` AS `action_name`,`_priv_link_action_trigger`.`trigger_id` AS `trigger_id`,`Trigger_trigger_id_priv_trigger`.`description` AS `trigger_name`,`_priv_link_action_trigger`.`order` AS `order`,cast(concat(coalesce('lnkTriggerAction','')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`Action_action_id_priv_action`.`name`,'')) as char charset utf8) AS `action_id_friendlyname`,`Action_action_id_priv_action`.`realclass` AS `action_id_finalclass_recall`,cast(concat(coalesce(`Trigger_trigger_id_priv_trigger`.`description`,'')) as char charset utf8) AS `trigger_id_friendlyname`,`Trigger_trigger_id_priv_trigger`.`realclass` AS `trigger_id_finalclass_recall` from ((`priv_link_action_trigger` `_priv_link_action_trigger` join `priv_action` `Action_action_id_priv_action` on((`_priv_link_action_trigger`.`action_id` = `Action_action_id_priv_action`.`id`))) join `priv_trigger` `Trigger_trigger_id_priv_trigger` on((`_priv_link_action_trigger`.`trigger_id` = `Trigger_trigger_id_priv_trigger`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_lnkVirtualDeviceToVolume`
--

/*!50001 DROP VIEW IF EXISTS `view_lnkVirtualDeviceToVolume`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`itop`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_lnkVirtualDeviceToVolume` AS select distinct `_lnkvirtualdevicetovolume`.`id` AS `id`,`_lnkvirtualdevicetovolume`.`volume_id` AS `volume_id`,`LogicalVolume_volume_id_logicalvolume`.`name` AS `volume_name`,`_lnkvirtualdevicetovolume`.`virtualdevice_id` AS `virtualdevice_id`,`VirtualDevice_virtualdevice_id_functionalci`.`name` AS `virtualdevice_name`,`_lnkvirtualdevicetovolume`.`size_used` AS `size_used`,cast(concat(coalesce(`_lnkvirtualdevicetovolume`.`volume_id`,'')) as char charset utf8) AS `friendlyname`,cast(concat(coalesce(`StorageSystem_storagesystem_id_functionalci`.`name`,''),coalesce(' ',''),coalesce(`LogicalVolume_volume_id_logicalvolume`.`name`,'')) as char charset utf8) AS `volume_id_friendlyname`,cast(concat(coalesce(`VirtualDevice_virtualdevice_id_functionalci`.`name`,'')) as char charset utf8) AS `virtualdevice_id_friendlyname`,`VirtualDevice_virtualdevice_id_functionalci`.`finalclass` AS `virtualdevice_id_finalclass_recall` from ((`lnkvirtualdevicetovolume` `_lnkvirtualdevicetovolume` join (`logicalvolume` `LogicalVolume_volume_id_logicalvolume` join (`storagesystem` `StorageSystem_storagesystem_id_storagesystem` join `functionalci` `StorageSystem_storagesystem_id_functionalci` on((`StorageSystem_storagesystem_id_storagesystem`.`id` = `StorageSystem_storagesystem_id_functionalci`.`id`))) on((`LogicalVolume_volume_id_logicalvolume`.`storagesystem_id` = `StorageSystem_storagesystem_id_storagesystem`.`id`))) on((`_lnkvirtualdevicetovolume`.`volume_id` = `LogicalVolume_volume_id_logicalvolume`.`id`))) join (`virtualdevice` `VirtualDevice_virtualdevice_id_virtualdevice` join `functionalci` `VirtualDevice_virtualdevice_id_functionalci` on((`VirtualDevice_virtualdevice_id_virtualdevice`.`id` = `VirtualDevice_virtualdevice_id_functionalci`.`id`))) on((`_lnkvirtualdevicetovolume`.`virtualdevice_id` = `VirtualDevice_virtualdevice_id_virtualdevice`.`id`))) where 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-31  8:56:35
